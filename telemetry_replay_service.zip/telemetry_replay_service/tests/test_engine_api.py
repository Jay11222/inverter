import json
import shutil
import socket
import time
from dataclasses import replace
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from replay_service.api import create_app
from replay_service.engine import ReplayManager, RunRejected, RunRequest
from replay_service.payload import DRY_RUN_DEVICE


def wait(run, states=("COMPLETED", "FAILED", "STOPPED", "HALTED_UNCONFIRMED"), timeout=10):
    t = time.time()
    while run.state not in states and time.time() - t < timeout:
        time.sleep(0.02)
    return run.state


@pytest.fixture
def no_network(monkeypatch):
    def deny(*a, **k):
        raise AssertionError("network access attempted in dry run")
    monkeypatch.setattr(socket.socket, "connect", deny)


def test_dry_run_battery_end_to_end_no_network(settings, no_network):
    m = ReplayManager(settings)
    run = m.create(RunRequest("battery", "4"))
    assert wait(run) == "COMPLETED" and run.counters == {"DRY_RUN": 3}
    p = run.prepared
    assert all(pl["source"]["id"] == DRY_RUN_DEVICE for pl in p.payloads)
    assert p.payloads[0]["BatteryTelemetry"] == {"Current": {"value": -2.0, "unit": "A"}, "Voltage": {"value": 4.0, "unit": "V"}}
    assert p.summary["timeline"]["policy"] == "shifted" and p.summary["timeline"]["intervals_equal_to_source"] is True
    assert (Path(settings.output_dir) / run.run_id / "preview.json").exists()
    assert (Path(settings.output_dir) / run.run_id / "ledger.jsonl").exists()


def test_payload_never_contains_reference_labels_or_ppm(settings, no_network):
    m = ReplayManager(settings)
    for req in (RunRequest("battery", "1"), RunRequest("transformer", "data_train/2_trans_1.csv", timestamp_policy="reconstructed")):
        run = m.create(req); wait(run)
        text = json.dumps(run.prepared.payloads)
        assert "RUL" not in text and "rul_label" not in text and "ppm" not in text.lower()


def test_transformer_gases_have_no_unit_and_are_reconstructed(settings, no_network):
    run = ReplayManager(settings).create(RunRequest("transformer", "data_train/2_trans_1.csv", timestamp_policy="reconstructed"))
    wait(run)
    pl = run.prepared.payloads
    assert len(pl) == 420
    assert set(pl[0]["TransformerDGA"]) == {"H2", "CO", "C2H4", "C2H2"}
    assert all("unit" not in v for v in pl[0]["TransformerDGA"].values())
    assert pl[0]["replayTrace"]["timeOrigin"] == "reconstructed"
    assert run.prepared.summary["timeline"]["reconstructed_interval_seconds"] == 43200.0
    assert run.prepared.summary["timeline"]["time_origin"] == "reconstructed"


def test_transformer_default_policy_shifted_is_refused_without_timestamps(settings):
    with pytest.raises(RunRejected) as e:
        ReplayManager(settings).create(RunRequest("transformer", "data_train/2_trans_1.csv"))
    assert "reconstructed" in str(e.value)


def test_interval_and_pace_are_independent(settings, no_network):
    s = replace(settings, pace_seconds=100.0, pace_mode="fixed_interval", max_requests_per_second=1000.0)
    run = ReplayManager(s).create(RunRequest("transformer", "data_train/2_trans_1.csv", timestamp_policy="reconstructed", limit=3))
    sm = run.prepared.summary
    assert sm["pacing"]["pace_seconds"] == 100.0 and sm["timeline"]["reconstructed_interval_seconds"] == 43200.0
    assert sm["partial_sequence"] is True
    run.stop_event.set()


def test_original_timestamp_kept_in_trace_and_time_not_send_time(settings, no_network):
    run = ReplayManager(settings).create(RunRequest("battery", "4")); wait(run)
    pl = run.prepared.payloads[0]
    assert pl["time"] == "2026-01-01T00:00:00.000Z"                         # shifted anchor, not wall-clock
    assert pl["replayTrace"]["sourceTime"] == "2008-04-02T15:00:00.500Z"    # original preserved


def test_flagged_rows_included_and_reported_by_default(settings, no_network):
    run = ReplayManager(settings).create(RunRequest("battery", "1")); wait(run)
    f = run.prepared.summary["flagged"]
    assert f["count"] == 1 and f["examples"][0]["values"]["Current"] == -4.030268
    assert run.prepared.payloads[0]["BatteryTelemetry"]["Current"]["value"] == -4.030268


def test_flagged_rows_policy_block(settings):
    with pytest.raises(RunRejected):
        ReplayManager(replace(settings, flagged_rows_policy="block")).create(RunRequest("battery", "1"))


def test_exclusions_visible_in_summary(settings, no_network):
    run = ReplayManager(settings).create(RunRequest("battery", "2")); wait(run)
    assert run.prepared.summary["exclusions"][0]["reason"] == "missing_voltage_or_current"


def test_invalid_sequence_rejected_with_reason(settings):
    with pytest.raises(RunRejected):
        ReplayManager(settings).create(RunRequest("battery", "3"))                         # impedance
    with pytest.raises(RunRejected):
        ReplayManager(settings).create(RunRequest("transformer", "data_test/2_trans_4.csv", timestamp_policy="reconstructed"))


def test_large_run_cap(settings):
    with pytest.raises(RunRejected) as e:
        ReplayManager(replace(settings, max_observations_per_run=100)).create(
            RunRequest("transformer", "data_train/2_trans_1.csv", timestamp_policy="reconstructed"))
    assert "MAX_OBSERVATIONS_PER_RUN" in str(e.value)


def test_stop_ends_a_paced_run(settings, no_network):
    s = replace(settings, pace_mode="fixed_interval", pace_seconds=5.0, max_requests_per_second=1000.0)
    m = ReplayManager(s)
    run = m.create(RunRequest("battery", "4", paced=True))
    time.sleep(0.2); m.stop(run.run_id)
    assert wait(run, timeout=3) == "STOPPED" and run.counters.get("DRY_RUN", 0) < 3


def test_concurrent_run_limit(settings, no_network):
    s = replace(settings, pace_mode="fixed_interval", pace_seconds=5.0)
    m = ReplayManager(s)
    first = m.create(RunRequest("battery", "4", paced=True))
    with pytest.raises(RunRejected):
        m.create(RunRequest("battery", "4"))
    m.stop(first.run_id); wait(first)


# ---- publish gates ----
def test_publish_blocked_by_default_with_reasons(settings):
    with pytest.raises(RunRejected) as e:
        ReplayManager(settings).create(RunRequest("battery", "4", mode="publish"))
    text = str(e.value)
    for needle in ("PUBLISH_ENABLED", "TARGET_APPROVED", "mapping status", "C8Y_BASEURL", "device ID", "approved selection manifest"):
        assert needle in text


def test_publish_partial_sequence_never_allowed(settings):
    with pytest.raises(RunRejected):
        ReplayManager(settings).create(RunRequest("battery", "4", mode="publish", limit=2))


@pytest.fixture
def publish_settings(settings, tmp_path, mock_c8y):
    m = json.loads(Path(settings.mapping_path).read_text()); m["status"] = "APPROVED"
    mp = tmp_path / "mapping.approved.json"; mp.write_text(json.dumps(m))
    sel = tmp_path / "sel.json"; sel.write_text(json.dumps({"approved_by": "test", "battery": [4], "transformer": []}))
    return replace(settings, mapping_path=str(mp), selection_manifest=str(sel), publish_enabled=True, target_approved=True,
                   c8y_base_url=mock_c8y.url, c8y_user="svc", c8y_password="s3cr3t-pw", c8y_device_id_battery="777",
                   http_backoff_seconds=0.0, http_read_timeout=0.3)


def test_publish_to_mock_tenant_end_to_end(publish_settings, mock_c8y):
    run = ReplayManager(publish_settings, sleep=lambda s: None).create(RunRequest("battery", "4", mode="publish"))
    assert wait(run) == "COMPLETED" and run.counters == {"DELIVERED": 3}
    assert [m["source"]["id"] for m in mock_c8y.stored] == ["777"] * 3
    assert mock_c8y.stored[0]["BatteryTelemetry"]["Voltage"] == {"value": 4.0, "unit": "V"}
    assert not [r for r in mock_c8y.requests if r[0] == "POST" and "/inventory" in r[1]]       # never creates devices
    assert all(a and a.startswith("Basic ") for a in mock_c8y.auth_seen)


def test_publish_preflight_fails_when_device_missing(publish_settings, mock_c8y):
    mock_c8y.device_status = 404
    run = ReplayManager(publish_settings).create(RunRequest("battery", "4", mode="publish"))
    assert wait(run) == "FAILED" and "preflight" in run.error and not mock_c8y.posts()


def test_publish_halts_on_unconfirmed(publish_settings, mock_c8y):
    mock_c8y.post_script = ["timeout_stored"]; mock_c8y.get_meas_status = 500
    run = ReplayManager(publish_settings).create(RunRequest("battery", "4", mode="publish"))
    assert wait(run) == "HALTED_UNCONFIRMED" and len(mock_c8y.posts()) == 1


def test_publish_halts_on_rejected(publish_settings, mock_c8y):
    mock_c8y.post_script = ["ok", "400"]
    run = ReplayManager(publish_settings).create(RunRequest("battery", "4", mode="publish"))
    assert wait(run) == "FAILED" and run.counters == {"DELIVERED": 1, "REJECTED": 1} and len(mock_c8y.posts()) == 2


# ---- API ----
def test_api_health_config_and_dry_run(settings, no_network):
    c = TestClient(create_app(settings))
    assert c.get("/health").json()["status"] == "UP"
    cfg = c.get("/config").json()
    assert cfg["publish_enabled"] is False and cfg["mapping_status"] == "PROPOSED" and cfg["publish_blockers"]["battery"]
    r = c.post("/replays", json={"asset": "battery", "sequence_id": "4"})
    assert r.status_code == 202
    rid = r.json()["run_id"]
    for _ in range(100):
        st = c.get(f"/replays/{rid}").json()
        if st["state"] == "COMPLETED": break
        time.sleep(0.02)
    assert st["state"] == "COMPLETED" and st["counters"] == {"DRY_RUN": 3}
    pv = c.get(f"/replays/{rid}/preview").json()
    assert len(pv["payloads"]) == 3 and pv["summary"]["mapping_status"] == "PROPOSED"
    assert c.get("/replays").json()[0]["run_id"] == rid
    assert c.get("/replays/nope").status_code == 404 and c.post("/replays/nope/stop").status_code == 404


def test_api_publish_refused_and_validation(settings):
    c = TestClient(create_app(settings))
    r = c.post("/replays", json={"asset": "battery", "sequence_id": "4", "mode": "publish"})
    assert r.status_code == 422 and any("PUBLISH_ENABLED" in x for x in r.json()["detail"]["rejected"])
    assert c.post("/replays", json={"asset": "pump", "sequence_id": "1"}).status_code == 422
    assert c.post("/replays", json={"asset": "battery", "sequence_id": "4", "pace_seconds": -1}).status_code == 422
    assert c.post("/replays", json={"asset": "battery", "sequence_id": "999"}).status_code == 409


def test_api_dataset_listing(settings):
    c = TestClient(create_app(settings))
    assert {s["cycle"] for s in c.get("/datasets/battery/sequences").json()} == {1, 2, 3, 4}
    assert len(c.get("/datasets/transformer/sequences").json()) == 4
