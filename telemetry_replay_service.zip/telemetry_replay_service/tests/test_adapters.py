import hashlib
import os
from datetime import datetime, timezone

import pytest

from replay_service.adapters.battery import BatteryAdapter, BatteryDataError, parse_source_datetime
from replay_service.adapters.transformer import GASES, TransformerAdapter, TransformerDataError


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


# ---------------- battery ----------------
def test_battery_preserves_values_order_and_flags(settings):
    seq = BatteryAdapter(settings).load_sequence(1)
    assert [o.values["Voltage"] for o in seq.observations] == [8.39, 4.000588, 4.012395, 4.0123951234567891]
    assert [o.values["Current"] for o in seq.observations] == [-4.030268, 1.512731, 1.509063, 1.5]   # sign untouched
    assert seq.observations[0].flags == ("charge_current_negative", "voltage_above_review_max")
    assert all(o.flags == () for o in seq.observations[1:])
    assert len(seq.observations) == 4          # nothing removed, nothing added


def test_battery_negative_discharge_current_is_not_flagged(settings):
    seq = BatteryAdapter(settings).load_sequence(4)
    assert all(o.flags == () for o in seq.observations) and all(o.values["Current"] < 0 for o in seq.observations)


def test_battery_missing_voltage_row_is_excluded_and_recorded(settings):
    seq = BatteryAdapter(settings).load_sequence(2)
    assert len(seq.observations) == 2
    ex = [e for e in seq.exclusions if e.reason == "missing_voltage_or_current"]
    assert ex and ex[0].count == 1 and ex[0].rows == [6]    # file data row 6 in the fixture


def test_battery_impedance_is_excluded_and_recorded(settings):
    seq = BatteryAdapter(settings).load_sequence(3)
    assert seq.observations == []
    assert seq.exclusions[0].reason == "impedance_rows_not_in_initial_adapter" and seq.exclusions[0].count == 2
    assert seq.validation_errors


def test_battery_source_time_is_datetime_plus_offset(settings):
    seq = BatteryAdapter(settings).load_sequence(1)
    base = parse_source_datetime("2008-04-02 13:08:17.921", "UTC")
    assert seq.observations[1].source_time == base.replace(microsecond=base.microsecond) + __import__("datetime").timedelta(seconds=2.532)


def test_battery_timezone_is_a_setting(settings):
    from dataclasses import replace
    s2 = replace(settings, battery_source_timezone="Asia/Riyadh")
    t_utc = BatteryAdapter(settings).load_sequence(1).observations[0].source_time
    t_riy = BatteryAdapter(s2).load_sequence(1).observations[0].source_time
    assert (t_utc - t_riy).total_seconds() == 3 * 3600


def test_battery_rul_is_reference_only(settings):
    seq = BatteryAdapter(settings).load_sequence(1)
    o = seq.observations[0]
    assert o.reference["RUL"] == 10 and o.reference["RUL_basis"] == "operation_index_as_supplied"
    assert "RUL" not in o.values


def test_battery_contract_and_window_warning(settings):
    seq = BatteryAdapter(settings).load_sequence(4)
    assert any("101" in w for w in seq.validation_warnings)    # only 3 readings: padding would be downstream
    assert not seq.validation_errors


def test_battery_unknown_cycle_and_missing_config(settings):
    with pytest.raises(BatteryDataError):
        BatteryAdapter(settings).load_sequence(99)
    from replay_service.config import Settings
    with pytest.raises(BatteryDataError):
        BatteryAdapter(Settings())


def test_battery_selection_status_comes_from_manifest(settings):
    assert BatteryAdapter(settings).load_sequence(4).selection_status == "NOT_MODEL_OWNER_APPROVED"
    assert BatteryAdapter(settings).load_sequence(4, {4}).selection_status == "MODEL_OWNER_APPROVED"


def test_battery_reading_does_not_modify_source(settings):
    before = sha(settings.battery_csv_path)
    BatteryAdapter(settings).list_sequences(); BatteryAdapter(settings).load_sequence(1)
    assert sha(settings.battery_csv_path) == before


def test_battery_list_sequences(settings):
    seqs = {s["cycle"]: s for s in BatteryAdapter(settings).list_sequences()}
    assert seqs[2]["rows"] == 3 and seqs[2]["usable_rows"] == 2 and seqs[3]["usable_rows"] == 0


# ---------------- transformer ----------------
def test_transformer_split_membership_and_gases_paired(settings):
    ad = TransformerAdapter(settings)
    mem = ad.members()
    assert mem["data_train/2_trans_1.csv"]["split"] == "data_train" and mem["data_test/2_trans_3.csv"]["split"] == "data_test"
    seq = ad.load_sequence("data_train/2_trans_1.csv")
    assert len(seq.observations) == 420 and not seq.validation_errors
    assert all(tuple(o.values) == GASES for o in seq.observations)
    assert seq.observations[0].values["H2"] == 0.002 and seq.observations[0].source_time is None
    assert seq.source_info["split"] == "data_train"


def test_transformer_bare_name_resolves_when_unique(settings):
    assert TransformerAdapter(settings).resolve("2_trans_3.csv") == "data_test/2_trans_3.csv"
    with pytest.raises(TransformerDataError):
        TransformerAdapter(settings).resolve("2_trans_999.csv")


def test_transformer_non_420_is_rejected_not_padded(settings):
    seq = TransformerAdapter(settings).load_sequence("data_test/2_trans_4.csv")
    assert len(seq.observations) == 10                  # no padding
    assert any("exactly 420" in e for e in seq.validation_errors)


def test_transformer_reference_labels_separate(settings):
    seq = TransformerAdapter(settings).load_sequence("data_train/2_trans_2.csv")
    assert seq.reference["rul_label"] == "861" and seq.reference["fdd_category"] == "2"
    assert all("rul_label" not in o.values for o in seq.observations)


def test_transformer_directory_source_equivalent(settings, tmp_path):
    import zipfile
    from dataclasses import replace
    d = tmp_path / "ex"
    zipfile.ZipFile(settings.transformer_source).extractall(d)
    s2 = replace(settings, transformer_source=str(d))
    a = TransformerAdapter(settings).load_sequence("data_train/2_trans_1.csv")
    b = TransformerAdapter(s2).load_sequence("data_train/2_trans_1.csv")
    assert [o.values for o in a.observations] == [o.values for o in b.observations]


def test_transformer_reading_does_not_modify_archive(settings):
    before = sha(settings.transformer_source)
    ad = TransformerAdapter(settings); ad.members(); ad.labels(); ad.load_sequence("data_train/2_trans_1.csv"); ad.close()
    assert sha(settings.transformer_source) == before


def test_transformer_bad_header_rejected(settings, tmp_path):
    import zipfile
    from dataclasses import replace
    p = tmp_path / "bad.zip"
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("data_train/2_trans_1.csv", "CO,H2,C2H4,C2H2\n1,2,3,4\n")
    seq = TransformerAdapter(replace(settings, transformer_source=str(p))).load_sequence("2_trans_1.csv")
    assert seq.validation_errors and not seq.observations
