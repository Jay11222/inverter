import csv
import io
import json
import threading
import time
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from replay_service.config import Settings

REPO = Path(__file__).resolve().parent.parent
MAPPING = str(REPO / "config" / "mapping.proposed.json")

BAT_HEADER = ["Cycle", "type", "Time", "Datetime", "Voltage_measured", "Current_measured", "Temperature_measured", "RUL", "Re"]


def _bat_rows():
    d1 = "2008-04-02 13:08:17.921"
    d2 = "2008-04-02 14:10:00.000"
    d4 = "2008-04-02 15:00:00.500"
    rows = [
        # cycle 1: charge, first sample has negative current and an unusual voltage (as in the real data)
        [1, "charge", 0.0, d1, 8.39, -4.030268, 24.6, 10, ""],
        [1, "charge", 2.532, d1, 4.000588, 1.512731, 24.6, 10, ""],
        [1, "charge", 5.5, d1, 4.012395, 1.509063, 24.7, 10, ""],
        [1, "charge", 8.344, d1, 4.0123951234567891, 1.5, 24.7, 10, ""],
        # cycle 2: discharge, one row with missing voltage
        [2, "discharge", 0.0, d2, 4.19, -2.01, 24.0, 9, ""],
        [2, "discharge", 16.781, d2, "", -2.01, 24.0, 9, ""],
        [2, "discharge", 35.703, d2, 4.1, -2.0112345678901234, 24.1, 9, ""],
        # cycle 3: impedance, no V/I
        [3, "impedance", 0.0, d2, "", "", "", 9, "0.05"],
        [3, "impedance", 1.0, d2, "", "", "", 9, "0.05"],
        # cycle 4: discharge
        [4, "discharge", 0.0, d4, 4.0, -2.0, 24.0, 8, ""],
        [4, "discharge", 10.0, d4, 3.9, -2.0, 24.0, 8, ""],
        [4, "discharge", 20.0, d4, 3.8, -2.0, 24.0, 8, ""],
    ]
    return rows


@pytest.fixture
def battery_csv(tmp_path):
    p = tmp_path / "bat.csv"
    with open(p, "w", newline="") as fh:
        w = csv.writer(fh); w.writerow(BAT_HEADER); w.writerows(_bat_rows())
    return str(p)


def _trans_csv(n, scale=1.0):
    out = io.StringIO(); w = csv.writer(out); w.writerow(["H2", "CO", "C2H4", "C2H2"])
    for i in range(n):
        w.writerow([0.002 * scale + i * 1e-6, 1e-5 + i * 1e-7, 0.006 + i * 1e-6, 7e-5])
    return out.getvalue()


@pytest.fixture
def transformer_zip(tmp_path):
    p = tmp_path / "archive.zip"
    with zipfile.ZipFile(p, "w") as z:
        z.writestr("data_train/2_trans_1.csv", _trans_csv(420))
        z.writestr("data_train/2_trans_2.csv", _trans_csv(420, 2.0))
        z.writestr("data_test/2_trans_3.csv", _trans_csv(420, 3.0))
        z.writestr("data_test/2_trans_4.csv", _trans_csv(10))   # short, non-conforming
        z.writestr("labels_rul_train.csv", "id,predicted\n2_trans_1.csv,550\n2_trans_2.csv,861\n")
        z.writestr("labels_fdd_train.csv", "id,category\n2_trans_1.csv,1\n2_trans_2.csv,2\n")
        z.writestr("labels_rul_test.csv", "id,predicted\n2_trans_3.csv,693\n2_trans_4.csv,5\n")
        z.writestr("labels_fdd_test.csv", "id,category\n2_trans_3.csv,1\n2_trans_4.csv,1\n")
    return str(p)


@pytest.fixture
def settings(tmp_path, battery_csv, transformer_zip):
    return Settings(battery_csv_path=battery_csv, transformer_source=transformer_zip,
                    output_dir=str(tmp_path / "runs"), mapping_path=MAPPING,
                    pace_mode="asap", max_requests_per_second=1000.0, anchor_time="2026-01-01T00:00:00Z")


class MockC8y:
    """Local stand-in for Cumulocity. Scripted POST behaviour; records every request."""

    def __init__(self):
        self.requests = []          # (method, path)
        self.auth_seen = []
        self.stored = []
        self.post_script = []       # actions consumed in order; default 'ok'
        self.get_meas_status = 200
        self.device_status = 200
        self.slow_seconds = 1.0
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def _json(self, code, obj):
                body = json.dumps(obj).encode()
                self.send_response(code); self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

            def do_GET(self):
                outer.requests.append(("GET", self.path)); outer.auth_seen.append(self.headers.get("Authorization"))
                if self.path.startswith("/inventory/managedObjects/"):
                    return self._json(outer.device_status, {"id": "1"} if outer.device_status == 200 else {"message": "nf"})
                if self.path.startswith("/measurement/measurements"):
                    if outer.get_meas_status != 200:
                        return self._json(outer.get_meas_status, {"message": "boom"})
                    return self._json(200, {"measurements": outer.stored})
                self._json(404, {})

            def do_POST(self):
                outer.requests.append(("POST", self.path)); outer.auth_seen.append(self.headers.get("Authorization"))
                n = int(self.headers.get("Content-Length", 0)); body = json.loads(self.rfile.read(n) or b"{}")
                action = outer.post_script.pop(0) if outer.post_script else "ok"
                if action == "ok":
                    outer.stored.append(body); return self._json(201, body)
                if action == "429":
                    return self._json(429, {"message": "slow down"})
                if action == "400":
                    return self._json(400, {"message": "bad payload"})
                if action == "503_not_stored":
                    return self._json(503, {"message": "unavailable"})
                if action == "503_stored":
                    outer.stored.append(body); return self._json(503, {"message": "unavailable"})
                if action == "timeout_stored":
                    outer.stored.append(body); time.sleep(outer.slow_seconds); return
                if action == "drop_not_stored":
                    self.connection.close(); return
                self._json(500, {})

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def posts(self):
        return [r for r in self.requests if r[0] == "POST"]

    def close(self):
        self.server.shutdown(); self.server.server_close()


@pytest.fixture
def mock_c8y():
    m = MockC8y()
    yield m
    m.close()
