import json

from replay_service import cli


def env(monkeypatch, settings):
    monkeypatch.setenv("BATTERY_CSV_PATH", settings.battery_csv_path)
    monkeypatch.setenv("TRANSFORMER_SOURCE", settings.transformer_source)
    monkeypatch.setenv("OUTPUT_DIR", settings.output_dir)
    monkeypatch.setenv("MAPPING_PATH", settings.mapping_path)
    monkeypatch.setenv("ANCHOR_TIME", "2026-01-01T00:00:00Z")


def test_cli_preview_battery(monkeypatch, settings, tmp_path, capsys):
    env(monkeypatch, settings)
    out = tmp_path / "p.json"
    assert cli.main(["preview", "--asset", "battery", "--sequence", "4", "--out", str(out)]) == 0
    doc = json.loads(out.read_text())
    assert len(doc["payloads"]) == 3 and doc["summary"]["mapping_status"] == "PROPOSED"


def test_cli_preview_transformer_needs_reconstructed(monkeypatch, settings, capsys):
    env(monkeypatch, settings)
    assert cli.main(["preview", "--asset", "transformer", "--sequence", "data_train/2_trans_1.csv"]) == 2
    assert cli.main(["preview", "--asset", "transformer", "--sequence", "data_train/2_trans_1.csv",
                     "--policy", "reconstructed", "--anchor-mode", "end", "--limit", "5"]) == 0
