import logging
from datetime import datetime, timedelta, timezone

import pytest

from replay_service.config import Settings, load_settings
from replay_service.logging_setup import JsonFormatter, redact
from replay_service.models import Observation
from replay_service.timeline import (TimelineError, check_monotonic, resolve_anchor, resolve_times, to_c8y_time)


def mk(i, t):
    return Observation(f"o{i}", "battery", "s", i, {"Current": 1.0}, t)


UTC = timezone.utc


# ---- config ----
def test_no_defaults_for_secrets_or_targets(monkeypatch):
    for k in ("C8Y_BASEURL", "C8Y_USER", "C8Y_PASSWORD", "C8Y_DEVICE_ID_BATTERY", "C8Y_DEVICE_ID_TRANSFORMER", "PUBLISH_ENABLED"):
        monkeypatch.delenv(k, raising=False)
    s = load_settings()
    assert s.c8y_base_url is None and s.c8y_user is None and s.c8y_password is None
    assert s.c8y_device_id_battery is None and s.c8y_device_id_transformer is None
    assert s.publish_enabled is False and s.target_approved is False


def test_secrets_not_in_repr():
    s = Settings(c8y_user="alice", c8y_password="s3cr3t-pw")
    assert "s3cr3t-pw" not in repr(s) and "s3cr3t-pw" not in str(s) and "alice" not in repr(s)


def test_publish_blockers_list_every_missing_gate():
    s = Settings()
    b = " | ".join(s.publish_blockers("battery", "PROPOSED"))
    for needle in ("PUBLISH_ENABLED", "TARGET_APPROVED", "mapping status", "C8Y_BASEURL", "C8Y_USER", "device ID", "SELECTION_MANIFEST"):
        assert needle in b


def test_publish_allowed_only_when_all_gates_set():
    s = Settings(publish_enabled=True, target_approved=True, c8y_base_url="http://x", c8y_user="u", c8y_password="p",
                 c8y_device_id_battery="1", selection_manifest="m.json")
    assert s.publish_blockers("battery", "APPROVED") == []
    assert s.publish_blockers("transformer", "APPROVED")  # no transformer device configured


# ---- logging ----
def test_redaction():
    assert "hunter2" not in redact('password=hunter2 token: abc123 Authorization: Basic dXNlcjpwYXNz')
    assert "dXNlcjpwYXNz" not in redact("Authorization: Basic dXNlcjpwYXNz")


def test_json_formatter_redacts_context():
    rec = logging.LogRecord("x", logging.INFO, "f", 1, "login password=zzz", None, None)
    rec.ctx = {"password": "zzz", "note": "ok"}
    out = JsonFormatter().format(rec)
    assert "zzz" not in out and "ok" in out


# ---- timeline ----
def test_shifted_preserves_original_intervals_exactly():
    src = datetime(2008, 4, 2, 13, 8, 17, 921000, tzinfo=UTC)
    offs = [0, 2.532, 5.5, 8.344, 100.0]
    obs = [mk(i, src + timedelta(seconds=o)) for i, o in enumerate(offs)]
    anchor = datetime(2026, 1, 1, tzinfo=UTC)
    res = resolve_times(obs, "shifted", anchor, "start")
    assert res[0].time == anchor and all(r.origin == "shifted" for r in res)
    assert [(res[i].time - res[i - 1].time) for i in range(1, 5)] == [(obs[i].source_time - obs[i - 1].source_time) for i in range(1, 5)]


def test_anchor_end_aligns_last_observation():
    src = datetime(2008, 1, 1, tzinfo=UTC)
    obs = [mk(i, src + timedelta(seconds=10 * i)) for i in range(4)]
    anchor = datetime(2026, 1, 1, tzinfo=UTC)
    assert resolve_times(obs, "shifted", anchor, "end")[-1].time == anchor


def test_source_policy_keeps_original_times():
    src = datetime(2008, 1, 1, tzinfo=UTC)
    obs = [mk(0, src), mk(1, src + timedelta(seconds=1))]
    r = resolve_times(obs, "source", datetime.now(UTC))
    assert [x.time for x in r] == [o.source_time for o in obs] and r[0].origin == "source"


def test_reconstructed_is_labelled_and_uses_interval():
    obs = [mk(i, None) for i in range(3)]
    anchor = datetime(2026, 1, 1, tzinfo=UTC)
    r = resolve_times(obs, "reconstructed", anchor, "start", 43200)
    assert [x.origin for x in r] == ["reconstructed"] * 3
    assert r[1].time - r[0].time == timedelta(hours=12)
    r_end = resolve_times(obs, "reconstructed", anchor, "end", 43200)
    assert r_end[-1].time == anchor


def test_source_or_shifted_without_timestamps_is_an_error():
    obs = [mk(i, None) for i in range(3)]
    for pol in ("source", "shifted"):
        with pytest.raises(TimelineError):
            resolve_times(obs, pol, datetime.now(UTC))


def test_unknown_policy_and_bad_interval():
    with pytest.raises(TimelineError):
        resolve_times([mk(0, None)], "send_time", datetime.now(UTC))
    with pytest.raises(TimelineError):
        resolve_times([mk(0, None)], "reconstructed", datetime.now(UTC), "start", 0)


def test_anchor_now_resolved_once_from_given_clock():
    fixed = datetime(2030, 5, 5, tzinfo=UTC)
    assert resolve_anchor("now", now=fixed) == fixed
    assert resolve_anchor("2026-01-01T00:00:00Z") == datetime(2026, 1, 1, tzinfo=UTC)


def test_to_c8y_time_millisecond_format():
    assert to_c8y_time(datetime(2008, 4, 2, 13, 8, 20, 453999, tzinfo=UTC)) == "2008-04-02T13:08:20.453Z"


def test_duplicate_timestamps_detected_at_ms_precision():
    base = datetime(2026, 1, 1, tzinfo=UTC)
    obs = [mk(0, base), mk(1, base + timedelta(microseconds=400))]
    issues = check_monotonic(resolve_times(obs, "source", base))
    assert issues and "duplicate" in issues[0]
