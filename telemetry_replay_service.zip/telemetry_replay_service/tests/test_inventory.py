import hashlib

from replay_service import inventory


def test_inventory_on_fixtures_is_read_only(battery_csv, transformer_zip):
    h = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
    b0, t0 = h(battery_csv), h(transformer_zip)
    r = inventory.run(battery_csv, transformer_zip)
    assert r["originals_unchanged"] is True and h(battery_csv) == b0 and h(transformer_zip) == t0
    assert r["transformer"]["splits"] == {"data_train": 2, "data_test": 2}
    assert r["transformer"]["sequence_lengths"] == {420: 3, 10: 1}
    assert r["transformer"]["label_coverage"]["data_train/rul"]["files_without_label"] == 0
    assert r["battery"]["by_operation_type"]["impedance"]["usable_rows"] == 0
    assert r["battery"]["flagged_readings"]["charge_current_negative"] == 1
