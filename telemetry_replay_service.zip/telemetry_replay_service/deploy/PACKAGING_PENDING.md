# Packaging: pending confirmation from the deployment team

The Dockerfile in the project root is generic. These points are deliberately **not** decided here:

- Isolation level (PER_TENANT or MULTI_TENANT) and how service credentials reach the container. The service reads `C8Y_BASEURL`, `C8Y_TENANT`, `C8Y_USER` and `C8Y_PASSWORD` from the environment and has no defaults for any of them. If the platform uses another mechanism, only `config.py` needs to change.
- Cumulocity manifest (`cumulocity.json`), required roles, health/readiness probes, listening port and memory limits. The service exposes `GET /health` on `PORT` (default 8080).
- Image format and upload bundle for the tenant.
- Where the datasets are mounted. They are never part of the image.

Required roles, as far as the code goes: create and read measurements, and read one existing device. The client never creates devices or alarms.
