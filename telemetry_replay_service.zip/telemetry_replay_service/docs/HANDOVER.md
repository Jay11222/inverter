# Handover notes for Software, Cloud and Security teams

## What this is
A service that replays Battery (Current, Voltage) and Transformer (H2, CO, C2H4, C2H2) dataset sequences into Cumulocity as measurements. It does not call the models; the orchestrator does that. See `README.md` for running it and `docs/OPEN_ITEMS.md` for what is still undecided.

## Your decisions
Mapping approval, target tenant and devices, packaging (isolation, manifest, probes, port, image format), ingestion limits, and who approves the sequence selection (`SELECTION_MANIFEST`). In the code and the API the label `MODEL_OWNER_APPROVED` simply means "listed in the approved selection manifest", whoever your team names as approver.

## Status
Tested locally (72 automated tests, dry runs on the real datasets, a mock tenant). **Not built as a Docker image. Never run against a real tenant.** Publishing is off by default.

## Security notes (for review)
- No credentials, tokens, tenant URLs or device IDs in the code, image or config. Everything comes from environment variables. Logs redact credentials.
- Outbound traffic goes only to the configured `C8Y_BASEURL`, and only when all publish gates are set. It never creates devices or alarms; it reads one existing device and posts measurements.
- Datasets are read-only inputs mounted at runtime. They are not in the source package, the git history or the image.
- The container runs as a non-root user (not yet verified by a build).
- The control API (`/replays`, `/config`) has no authentication of its own. It assumes the platform gateway protects it.
- Limits: `MAX_OBSERVATIONS_PER_RUN`, `MAX_REQUESTS_PER_SECOND`, one concurrent run, no bulk posting.
