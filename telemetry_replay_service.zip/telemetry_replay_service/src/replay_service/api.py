"""HTTP control API.

Endpoints:
  GET  /health
  GET  /config                     effective non-secret settings and publish gate status
  GET  /datasets/battery/sequences
  GET  /datasets/transformer/sequences
  POST /replays                    create a run (default mode dry_run)
  GET  /replays                    list runs
  GET  /replays/{run_id}           status and counters
  GET  /replays/{run_id}/preview   exact payloads and summary
  POST /replays/{run_id}/stop

The API has no authentication of its own; it is meant to sit behind the platform's gateway.
"""
from __future__ import annotations

import json
import os
from typing import Literal, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from . import __version__
from .adapters.battery import BatteryAdapter, BatteryDataError
from .adapters.transformer import TransformerAdapter, TransformerDataError
from .config import Settings
from .engine import ReplayManager, RunRejected, RunRequest
from .payload import load_mapping


class CreateReplay(BaseModel):
    asset: Literal["battery", "transformer"]
    sequence_id: str
    mode: Literal["dry_run", "publish"] = "dry_run"
    timestamp_policy: Optional[Literal["source", "shifted", "reconstructed"]] = None
    anchor_mode: Optional[Literal["start", "end"]] = None
    anchor_time: Optional[str] = None
    reconstruct_interval_seconds: Optional[float] = Field(None, gt=0)
    pace_mode: Optional[Literal["fixed_interval", "timeline_scaled", "asap"]] = None
    pace_seconds: Optional[float] = Field(None, ge=0)
    speed_factor: Optional[float] = Field(None, gt=0)
    max_requests_per_second: Optional[float] = Field(None, gt=0)
    limit: Optional[int] = Field(None, ge=1)
    paced: bool = False


def create_app(settings: Settings, manager: Optional[ReplayManager] = None) -> FastAPI:
    app = FastAPI(title="Telemetry Replay Service", version=__version__)
    mgr = manager or ReplayManager(settings)

    @app.get("/health")
    def health():
        return {"status": "UP", "version": __version__}

    @app.get("/config")
    def config():
        try:
            mstatus = load_mapping(settings.mapping_path).get("status")
        except Exception:
            mstatus = "UNREADABLE"
        return {
            "publish_enabled": settings.publish_enabled, "target_approved": settings.target_approved,
            "mapping_status": mstatus,
            "publish_blockers": {a: settings.publish_blockers(a, mstatus) for a in ("battery", "transformer")},
            "timestamp_policy": settings.timestamp_policy, "anchor_mode": settings.anchor_mode,
            "pace": {"mode": settings.pace_mode, "pace_seconds": settings.pace_seconds,
                     "speed_factor": settings.speed_factor, "max_requests_per_second": settings.max_requests_per_second},
            "max_observations_per_run": settings.max_observations_per_run,
            "transformer_source_interval_seconds": settings.transformer_source_interval_seconds,
            "battery_source_timezone_assumed": settings.battery_source_timezone,
        }

    @app.get("/datasets/battery/sequences")
    def battery_sequences():
        try:
            return BatteryAdapter(settings).list_sequences()
        except BatteryDataError as e:
            raise HTTPException(409, str(e))

    @app.get("/datasets/transformer/sequences")
    def transformer_sequences():
        try:
            ad = TransformerAdapter(settings)
            try:
                return [{"sequence_id": k, **v} for k, v in sorted(ad.members().items())]
            finally:
                ad.close()
        except TransformerDataError as e:
            raise HTTPException(409, str(e))

    @app.post("/replays", status_code=202)
    def create_replay(body: CreateReplay):
        try:
            run = mgr.create(RunRequest(**body.model_dump()))
        except RunRejected as e:
            raise HTTPException(422, {"rejected": e.reasons})
        except (BatteryDataError, TransformerDataError) as e:
            raise HTTPException(409, str(e))
        return run.status()

    @app.get("/replays")
    def list_replays():
        return [r.status() for r in mgr._runs.values()]

    @app.get("/replays/{run_id}")
    def get_replay(run_id: str):
        r = mgr.get(run_id)
        if not r:
            raise HTTPException(404, "unknown run_id")
        return r.status()

    @app.get("/replays/{run_id}/preview")
    def preview(run_id: str):
        r = mgr.get(run_id)
        if not r:
            raise HTTPException(404, "unknown run_id")
        return {"summary": r.prepared.summary, "payloads": r.prepared.payloads}

    @app.post("/replays/{run_id}/stop")
    def stop(run_id: str):
        r = mgr.stop(run_id)
        if not r:
            raise HTTPException(404, "unknown run_id")
        return r.status()

    return app
