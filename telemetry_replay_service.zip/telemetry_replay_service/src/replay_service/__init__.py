"""Telemetry replay service for Electrical Assets (Battery and Transformer)."""
__version__ = "0.1.0"
