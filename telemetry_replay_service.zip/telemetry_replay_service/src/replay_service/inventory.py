"""Read-only dataset inventory. Opens every input in read mode, records SHA-256 before and after."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import re
import statistics
import sys
import zipfile
from collections import Counter, defaultdict
from typing import Optional

GASES = ("H2", "CO", "C2H4", "C2H2")
_MEMBER = re.compile(r"(?:^|/)(data_[a-z]+)/([^/]+\.csv)$")
_LABEL = re.compile(r"(?:^|/)labels_(rul|fdd)_([a-z]+)\.csv$")


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def inventory_transformer(path: str) -> dict:
    out: dict = {"source": os.path.basename(path)}
    z = zipfile.ZipFile(path, "r")
    names = [i.filename for i in z.infolist() if not i.is_dir()]
    splits: dict[str, list] = defaultdict(list)
    lengths, headers = Counter(), Counter()
    nan_files, neg_files, bad_files = [], [], []
    hash_to_files: dict[str, list] = defaultdict(list)
    stats = {g: [float("inf"), float("-inf")] for g in GASES}
    for n in names:
        m = _MEMBER.search(n)
        if not m:
            continue
        split, fname = m.group(1), m.group(2)
        raw = z.read(n)
        hash_to_files[hashlib.sha256(raw).hexdigest()].append(n)
        rows = list(csv.reader(io.StringIO(raw.decode("utf-8"))))
        headers[tuple(rows[0])] += 1
        body = rows[1:]
        lengths[len(body)] += 1
        splits[split].append(fname)
        try:
            vals = [[float(x) for x in r] for r in body]
        except ValueError:
            bad_files.append(n); continue
        flat_nan = any(v != v for r in vals for v in r)
        if flat_nan: nan_files.append(n)
        if any(v < 0 for r in vals for v in r): neg_files.append(n)
        for r in vals:
            for g, v in zip(GASES, r):
                stats[g][0] = min(stats[g][0], v); stats[g][1] = max(stats[g][1], v)
    out["splits"] = {k: len(v) for k, v in splits.items()}
    out["sequence_lengths"] = dict(lengths)
    out["headers"] = {",".join(k): v for k, v in headers.items()}
    out["files_with_nan"] = len(nan_files)
    out["files_with_negative_values"] = len(neg_files)
    out["unparseable_files"] = len(bad_files)
    out["value_ranges"] = {g: {"min": a, "max": b} for g, (a, b) in stats.items()}
    dups = [v for v in hash_to_files.values() if len(v) > 1]
    out["identical_content_groups"] = len(dups)
    out["identical_content_across_splits"] = sum(
        1 for grp in dups if len({_MEMBER.search(x).group(1) for x in grp}) > 1)
    # labels
    labels = {}
    for n in names:
        m = _LABEL.search(n)
        if m:
            rows = list(csv.DictReader(io.StringIO(z.read(n).decode("utf-8"))))
            labels[os.path.basename(n)] = {"rows": len(rows), "columns": list(rows[0].keys()) if rows else [],
                                           "ids": {r["id"] for r in rows}}
    out["label_files"] = {k: {"rows": v["rows"], "columns": v["columns"]} for k, v in labels.items()}
    membership = {}
    for split, files in splits.items():
        sfx = split.replace("data_", "")
        s_files = set(files)
        for kind in ("rul", "fdd"):
            lf = labels.get(f"labels_{kind}_{sfx}.csv")
            ids = lf["ids"] if lf else set()
            membership[f"{split}/{kind}"] = {"files": len(s_files), "label_ids": len(ids),
                                             "files_without_label": len(s_files - ids), "labels_without_file": len(ids - s_files)}
    out["label_coverage"] = membership
    both = set(splits.get("data_train", [])) & set(splits.get("data_test", []))
    out["file_names_in_both_splits"] = len(both)
    z.close()
    return out


def inventory_battery(path: str, v_min: float = 2.4, v_max: float = 4.25) -> dict:
    ops: dict[int, dict] = {}
    total = 0
    flags = Counter()
    with open(path, "r", newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            total += 1
            c = int(float(r["Cycle"]))
            e = ops.setdefault(c, {"type": r["type"], "rows": 0, "usable": 0})
            e["rows"] += 1
            try:
                v, i = float(r["Voltage_measured"]), float(r["Current_measured"])
            except ValueError:
                continue
            if v != v or i != i:
                continue
            e["usable"] += 1
            if r["type"] == "charge" and i < 0: flags["charge_current_negative"] += 1
            if v > v_max: flags["voltage_above_review_max"] += 1
            if v < v_min: flags["voltage_below_review_min"] += 1
    by_type = defaultdict(list)
    for c, e in ops.items():
        by_type[e["type"]].append(e)
    summary = {}
    for t, es in by_type.items():
        summary[t] = {"cycles": len(es), "rows": sum(e["rows"] for e in es), "usable_rows": sum(e["usable"] for e in es),
                      "rows_per_cycle": {"min": min(e["rows"] for e in es), "median": statistics.median(e["rows"] for e in es),
                                         "max": max(e["rows"] for e in es)}}
    return {"source": os.path.basename(path), "rows": total, "cycles": len(ops), "by_operation_type": summary,
            "flagged_readings": dict(flags), "review_thresholds": {"voltage_min": v_min, "voltage_max": v_max, "note": "heuristics, not physical limits"},
            "candidate_complete_sequences_ge_101_usable": sum(1 for e in ops.values() if e["type"] != "impedance" and e["usable"] >= 101)}


def run(battery_csv: Optional[str], transformer_zip: Optional[str], reference_csv: Optional[str] = None) -> dict:
    inputs = [p for p in (battery_csv, transformer_zip, reference_csv) if p]
    before = {os.path.basename(p): sha256_file(p) for p in inputs}
    res: dict = {"inputs_sha256_before": before}
    if transformer_zip: res["transformer"] = inventory_transformer(transformer_zip)
    if battery_csv: res["battery"] = inventory_battery(battery_csv)
    after = {os.path.basename(p): sha256_file(p) for p in inputs}
    res["inputs_sha256_after"] = after
    res["originals_unchanged"] = before == after
    return res


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Read-only dataset inventory")
    ap.add_argument("--battery-csv"); ap.add_argument("--transformer-zip"); ap.add_argument("--reference-csv")
    ap.add_argument("--out")
    a = ap.parse_args()
    r = run(a.battery_csv, a.transformer_zip, a.reference_csv)
    text = json.dumps(r, indent=2, default=list)
    if a.out:
        with open(a.out, "w") as fh: fh.write(text)
    print(text)
