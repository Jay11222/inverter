import uvicorn

from .api import create_app
from .config import load_settings
from .logging_setup import setup_logging


def build():
    s = load_settings()
    setup_logging(s.log_level)
    return s, create_app(s)


def main():
    s, app = build()
    uvicorn.run(app, host="0.0.0.0", port=s.port, log_level="warning")


if __name__ == "__main__":
    main()
