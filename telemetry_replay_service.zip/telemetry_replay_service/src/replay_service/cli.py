"""Offline helper: build a dry-run preview without starting the HTTP service.

  python -m replay_service.cli preview --asset battery --sequence 2 [--policy shifted] [--out preview.json]
Reads data paths and settings from the same environment variables as the service. Never publishes.
"""
from __future__ import annotations

import argparse
import json
import sys

from .config import load_settings
from .engine import ReplayManager, RunRejected, RunRequest


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="replay_service.cli")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("preview", help="dry-run preview (never publishes)")
    p.add_argument("--asset", required=True, choices=["battery", "transformer"])
    p.add_argument("--sequence", required=True)
    p.add_argument("--policy", choices=["source", "shifted", "reconstructed"])
    p.add_argument("--anchor-mode", choices=["start", "end"])
    p.add_argument("--anchor-time")
    p.add_argument("--limit", type=int)
    p.add_argument("--out")
    a = ap.parse_args(argv)
    mgr = ReplayManager(load_settings())
    try:
        prep = mgr.prepare(RunRequest(a.asset, a.sequence, mode="dry_run", timestamp_policy=a.policy,
                                      anchor_mode=a.anchor_mode, anchor_time=a.anchor_time, limit=a.limit))
    except RunRejected as e:
        print(json.dumps({"rejected": e.reasons}, indent=2)); return 2
    doc = {"summary": prep.summary, "payloads": prep.payloads}
    text = json.dumps(doc, indent=1, default=str)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as fh: fh.write(text)
        print(json.dumps(prep.summary, indent=1, default=str))
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
