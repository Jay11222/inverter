"""Build Cumulocity measurement payloads from the (proposed) mapping."""
from __future__ import annotations

import json
from typing import Any, Optional

from .models import Observation
from .timeline import ResolvedTime, to_c8y_time

DRY_RUN_DEVICE = "DRY_RUN_NO_DEVICE"


def load_mapping(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        m = json.load(fh)
    for asset in ("battery", "transformer"):
        if asset not in m.get("assets", {}):
            raise ValueError(f"mapping {path} has no entry for {asset}")
    return m


def build_measurement(mapping: dict, obs: Observation, rt: ResolvedTime, run_id: str,
                      device_id: Optional[str]) -> dict[str, Any]:
    a = mapping["assets"][obs.asset]
    body: dict[str, Any] = {
        "source": {"id": str(device_id) if device_id else DRY_RUN_DEVICE},
        "time": to_c8y_time(rt.time),
        "type": a["measurement_type"],
    }
    series: dict[str, Any] = {}
    for name, spec in a["series"].items():
        if name not in obs.values:
            raise ValueError(f"observation {obs.observation_id} has no value for mapped series {name}")
        entry: dict[str, Any] = {"value": obs.values[name]}   # original value, untouched
        if spec.get("unit"):
            entry["unit"] = spec["unit"]
        series[name] = entry
    body[a["fragment"]] = series

    tf = mapping.get("trace_fragment", {})
    if tf.get("enabled"):
        trace = {
            "runId": run_id,
            "observationId": obs.observation_id,
            "sequenceId": obs.sequence_id,
            "index": obs.index,
            "timeOrigin": rt.origin,
            "sourceTime": to_c8y_time(obs.source_time) if obs.source_time else None,
            "reviewFlags": ",".join(obs.flags) if obs.flags else "",
        }
        body[tf["name"]] = trace
    return body
