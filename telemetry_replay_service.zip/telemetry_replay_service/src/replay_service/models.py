from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional


@dataclass(frozen=True)
class Observation:
    observation_id: str
    asset: str                       # battery | transformer
    sequence_id: str
    index: int                       # 0-based position within the replayed sequence
    values: dict[str, float]         # series name -> original value (never altered)
    source_time: Optional[datetime]  # original timestamp when the dataset has one (tz-aware UTC)
    flags: tuple[str, ...] = ()
    reference: dict[str, Any] = field(default_factory=dict)   # reference labels: NEVER sent as model input
    source_ref: dict[str, Any] = field(default_factory=dict)  # file, row, cycle, ... for traceability


@dataclass
class Exclusion:
    reason: str
    count: int
    detail: dict[str, Any] = field(default_factory=dict)
    rows: list[int] = field(default_factory=list)   # source row numbers (capped)


@dataclass
class Sequence:
    asset: str
    sequence_id: str
    observations: list[Observation]
    exclusions: list[Exclusion] = field(default_factory=list)
    reference: dict[str, Any] = field(default_factory=dict)    # sequence-level reference labels
    validation_errors: list[str] = field(default_factory=list)
    validation_warnings: list[str] = field(default_factory=list)
    selection_status: str = "NOT_MODEL_OWNER_APPROVED"
    source_info: dict[str, Any] = field(default_factory=dict)
