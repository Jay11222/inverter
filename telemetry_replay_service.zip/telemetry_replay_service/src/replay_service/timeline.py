"""Timestamp policies.

source        Use original timestamps (Battery only; Transformer files carry none).
shifted       Original timestamps moved by ONE constant offset, so original intervals are preserved exactly.
reconstructed Timestamps generated from a configured interval; always labelled 'reconstructed'.

Measurement time is never replaced by send time. The anchor "now" is resolved ONCE per run,
and recorded, so every observation keeps its own fixed timestamp.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from .models import Observation

POLICIES = ("source", "shifted", "reconstructed")
ANCHOR_MODES = ("start", "end")


class TimelineError(ValueError):
    pass


@dataclass(frozen=True)
class ResolvedTime:
    time: datetime
    origin: str  # source | shifted | reconstructed


def parse_utc(text: str) -> datetime:
    t = text.strip()
    if t.endswith("Z"):
        t = t[:-1] + "+00:00"
    dt = datetime.fromisoformat(t)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def resolve_anchor(anchor_time: str, now: Optional[datetime] = None) -> datetime:
    if anchor_time.strip().lower() == "now":
        return (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    return parse_utc(anchor_time)


def resolve_times(
    observations: list[Observation],
    policy: str,
    anchor: datetime,
    anchor_mode: str = "start",
    reconstruct_interval_seconds: Optional[float] = None,
) -> list[ResolvedTime]:
    if policy not in POLICIES:
        raise TimelineError(f"unknown timestamp policy {policy!r}; expected one of {POLICIES}")
    if anchor_mode not in ANCHOR_MODES:
        raise TimelineError(f"unknown anchor mode {anchor_mode!r}; expected one of {ANCHOR_MODES}")
    n = len(observations)
    if n == 0:
        return []

    if policy == "reconstructed":
        if not reconstruct_interval_seconds or reconstruct_interval_seconds <= 0:
            raise TimelineError("reconstructed policy needs a positive interval in seconds")
        step = timedelta(seconds=reconstruct_interval_seconds)
        start = anchor if anchor_mode == "start" else anchor - step * (n - 1)
        return [ResolvedTime(start + step * i, "reconstructed") for i in range(n)]

    missing = [o.observation_id for o in observations if o.source_time is None]
    if missing:
        raise TimelineError(
            f"policy {policy!r} needs source timestamps but {len(missing)} observation(s) have none "
            f"(first: {missing[0]}). Use policy 'reconstructed' for datasets without timestamps."
        )

    if policy == "source":
        return [ResolvedTime(o.source_time, "source") for o in observations]

    # shifted: one constant offset
    ref = observations[0].source_time if anchor_mode == "start" else observations[-1].source_time
    offset = anchor - ref
    return [ResolvedTime(o.source_time + offset, "shifted") for o in observations]


def check_monotonic(times: list[ResolvedTime]) -> list[str]:
    """Checks the timestamps as they will be sent (millisecond precision)."""
    issues = []
    for i in range(1, len(times)):
        prev, cur = to_c8y_time(times[i - 1].time), to_c8y_time(times[i].time)
        if times[i].time < times[i - 1].time:
            issues.append(f"timestamp goes backwards at index {i}")
        elif cur == prev:
            issues.append(f"duplicate timestamp at millisecond precision at index {i}")
        if len(issues) >= 10:
            break
    return issues


def to_c8y_time(dt: datetime) -> str:
    """ISO-8601 UTC with millisecond precision, the format used by the existing Cumulocity code."""
    dt = dt.astimezone(timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"
