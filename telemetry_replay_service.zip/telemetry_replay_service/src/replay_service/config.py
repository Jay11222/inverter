"""Settings loaded from environment variables only.

Design rules:
  * No credential, token, tenant URL or device ID has a default value.
  * Publishing is OFF unless every gate in `publish_blockers` is satisfied.
  * Secrets are excluded from repr/str so they cannot leak into logs.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, fields
from typing import Optional


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    v = os.environ.get(name)
    if v is None or v.strip() == "":
        return default
    return v.strip()


def _bool(name: str, default: bool = False) -> bool:
    v = _env(name)
    if v is None:
        return default
    return v.lower() in ("1", "true", "yes", "on")


def _float(name: str, default: float) -> float:
    v = _env(name)
    return default if v is None else float(v)


def _int(name: str, default: int) -> int:
    v = _env(name)
    return default if v is None else int(v)


def _opt_float(name: str) -> Optional[float]:
    v = _env(name)
    return None if v is None else float(v)


@dataclass(frozen=True)
class Settings:
    # ---- Data locations (read-only inputs, mounted at runtime, never baked into the image)
    battery_csv_path: Optional[str] = None
    battery_dataset_id: str = "B0005"
    transformer_source: Optional[str] = None       # directory or .zip
    transformer_labels_dir: Optional[str] = None   # defaults to the source root when None
    selection_manifest: Optional[str] = None       # JSON approved by the model owner
    output_dir: str = "runs"                       # run ledgers and previews

    # ---- Timestamp policy (items 2 and 6). Interval and pace are SEPARATE settings.
    timestamp_policy: str = "shifted"              # source | shifted | reconstructed
    anchor_mode: str = "start"                     # start | end
    anchor_time: str = "now"                       # ISO-8601 UTC or "now" (resolved once per run)
    battery_source_timezone: str = "UTC"           # source Datetime has no zone; UNCONFIRMED
    transformer_source_interval_seconds: float = 43200.0  # historical spacing (12 h), RECONSTRUCTED
    battery_interval_seconds_fallback: Optional[float] = None

    # ---- Replay pacing (item 7). Never derived from the historical interval.
    pace_mode: str = "fixed_interval"              # fixed_interval | timeline_scaled | asap
    pace_seconds: float = 5.0
    speed_factor: float = 1.0
    max_requests_per_second: float = 1.0
    max_observations_per_run: int = 1000
    max_concurrent_runs: int = 1

    # ---- Battery review heuristics (flag only, never alter values). NOT physical limits.
    battery_voltage_review_min: Optional[float] = 2.4
    battery_voltage_review_max: Optional[float] = 4.25
    flagged_rows_policy: str = "include"           # include | block

    # ---- Contract limits (item 10). Verify against the deployed OpenAPI.
    battery_contract_min: int = 1
    battery_contract_max: int = 20000
    battery_full_window: int = 101
    transformer_required_length: int = 420

    # ---- Cumulocity target (item 9). No defaults.
    c8y_base_url: Optional[str] = None
    c8y_tenant: Optional[str] = None
    c8y_user: Optional[str] = field(default=None, repr=False)
    c8y_password: Optional[str] = field(default=None, repr=False)
    c8y_device_id_battery: Optional[str] = None
    c8y_device_id_transformer: Optional[str] = None
    mapping_path: str = "config/mapping.proposed.json"

    # ---- Publish gates (all must be explicitly set)
    publish_enabled: bool = False
    target_approved: bool = False

    # ---- HTTP client behaviour
    http_connect_timeout: float = 5.0
    http_read_timeout: float = 15.0
    http_max_attempts: int = 3
    http_backoff_seconds: float = 1.0
    on_unconfirmed: str = "halt"                   # halt | continue

    port: int = 8080
    log_level: str = "INFO"

    def __repr__(self) -> str:  # never print secrets
        parts = []
        for f in fields(self):
            v = getattr(self, f.name)
            if f.name in ("c8y_user", "c8y_password"):
                v = "<set>" if v else None
            parts.append(f"{f.name}={v!r}")
        return "Settings(" + ", ".join(parts) + ")"

    __str__ = __repr__

    def publish_blockers(self, asset: str, mapping_status: Optional[str]) -> list[str]:
        """Return the reasons publishing is not allowed. Empty list means allowed."""
        b: list[str] = []
        if not self.publish_enabled:
            b.append("PUBLISH_ENABLED is not true")
        if not self.target_approved:
            b.append("TARGET_APPROVED is not true (designated dev/test tenant not confirmed)")
        if (mapping_status or "").upper() != "APPROVED":
            b.append(f"mapping status is {mapping_status!r}, not APPROVED")
        if not self.c8y_base_url:
            b.append("C8Y_BASEURL is not set")
        if not (self.c8y_user and self.c8y_password):
            b.append("C8Y_USER / C8Y_PASSWORD are not set")
        dev = self.c8y_device_id_battery if asset == "battery" else self.c8y_device_id_transformer
        if not dev:
            b.append(f"no approved existing device ID configured for {asset}")
        if not self.selection_manifest:
            b.append("SELECTION_MANIFEST (model-owner approved subset) is not configured")
        return b

    def device_id_for(self, asset: str) -> Optional[str]:
        return self.c8y_device_id_battery if asset == "battery" else self.c8y_device_id_transformer


def load_settings() -> Settings:
    return Settings(
        battery_csv_path=_env("BATTERY_CSV_PATH"),
        battery_dataset_id=_env("BATTERY_DATASET_ID", "B0005"),
        transformer_source=_env("TRANSFORMER_SOURCE"),
        transformer_labels_dir=_env("TRANSFORMER_LABELS_DIR"),
        selection_manifest=_env("SELECTION_MANIFEST"),
        output_dir=_env("OUTPUT_DIR", "runs"),
        timestamp_policy=_env("TIMESTAMP_POLICY", "shifted"),
        anchor_mode=_env("ANCHOR_MODE", "start"),
        anchor_time=_env("ANCHOR_TIME", "now"),
        battery_source_timezone=_env("BATTERY_SOURCE_TIMEZONE", "UTC"),
        transformer_source_interval_seconds=_float("TRANSFORMER_SOURCE_INTERVAL_SECONDS", 43200.0),
        pace_mode=_env("PACE_MODE", "fixed_interval"),
        pace_seconds=_float("PACE_SECONDS", 5.0),
        speed_factor=_float("SPEED_FACTOR", 1.0),
        max_requests_per_second=_float("MAX_REQUESTS_PER_SECOND", 1.0),
        max_observations_per_run=_int("MAX_OBSERVATIONS_PER_RUN", 1000),
        max_concurrent_runs=_int("MAX_CONCURRENT_RUNS", 1),
        battery_voltage_review_min=_opt_float("BATTERY_VOLTAGE_REVIEW_MIN") if _env("BATTERY_VOLTAGE_REVIEW_MIN") else 2.4,
        battery_voltage_review_max=_opt_float("BATTERY_VOLTAGE_REVIEW_MAX") if _env("BATTERY_VOLTAGE_REVIEW_MAX") else 4.25,
        flagged_rows_policy=_env("FLAGGED_ROWS_POLICY", "include"),
        battery_contract_min=_int("BATTERY_CONTRACT_MIN", 1),
        battery_contract_max=_int("BATTERY_CONTRACT_MAX", 20000),
        battery_full_window=_int("BATTERY_FULL_WINDOW", 101),
        transformer_required_length=_int("TRANSFORMER_REQUIRED_LENGTH", 420),
        c8y_base_url=_env("C8Y_BASEURL"),
        c8y_tenant=_env("C8Y_TENANT"),
        c8y_user=_env("C8Y_USER"),
        c8y_password=_env("C8Y_PASSWORD"),
        c8y_device_id_battery=_env("C8Y_DEVICE_ID_BATTERY"),
        c8y_device_id_transformer=_env("C8Y_DEVICE_ID_TRANSFORMER"),
        mapping_path=_env("MAPPING_PATH", "config/mapping.proposed.json"),
        publish_enabled=_bool("PUBLISH_ENABLED", False),
        target_approved=_bool("TARGET_APPROVED", False),
        http_connect_timeout=_float("HTTP_CONNECT_TIMEOUT", 5.0),
        http_read_timeout=_float("HTTP_READ_TIMEOUT", 15.0),
        http_max_attempts=_int("HTTP_MAX_ATTEMPTS", 3),
        http_backoff_seconds=_float("HTTP_BACKOFF_SECONDS", 1.0),
        on_unconfirmed=_env("ON_UNCONFIRMED", "halt"),
        port=_int("PORT", 8080),
        log_level=_env("LOG_LEVEL", "INFO"),
    )
