"""Structured JSON logging with credential redaction."""
from __future__ import annotations

import json
import logging
import re
import sys
from datetime import datetime, timezone

_REDACT = re.compile(r"(?i)(authorization|password|passwd|token|secret|api[-_]?key)(\"?\s*[:=]\s*\"?)([^\s,\"}]+)")
_BASIC = re.compile(r"(?i)basic\s+[A-Za-z0-9+/=]{6,}")


def redact(text: str) -> str:
    text = _BASIC.sub("Basic <redacted>", text)
    return _REDACT.sub(lambda m: f"{m.group(1)}{m.group(2)}<redacted>", text)


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.fromtimestamp(record.created, timezone.utc).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "msg": redact(record.getMessage()),
        }
        extra = getattr(record, "ctx", None)
        if isinstance(extra, dict):
            payload["ctx"] = json.loads(redact(json.dumps(extra, default=str)))
        if record.exc_info:
            payload["exc"] = redact(self.formatException(record.exc_info))
        return json.dumps(payload, default=str)


def setup_logging(level: str = "INFO") -> None:
    root = logging.getLogger()
    root.handlers.clear()
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(JsonFormatter())
    root.addHandler(h)
    root.setLevel(level.upper())
    # urllib3 debug logs can include request details; keep quiet.
    logging.getLogger("urllib3").setLevel(logging.WARNING)
