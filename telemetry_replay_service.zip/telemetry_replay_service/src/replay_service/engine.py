"""Replay engine: prepare (validate, resolve timeline, build payloads) then run (dry-run or publish)."""
from __future__ import annotations

import json
import logging
import os
import statistics
import threading
import time
import uuid
from dataclasses import dataclass, field, replace
from datetime import datetime, timezone
from typing import Any, Callable, Optional, Protocol

from . import c8y_client as c8y
from .adapters.battery import BatteryAdapter
from .adapters.transformer import TransformerAdapter
from .config import Settings
from .models import Observation, Sequence
from .payload import build_measurement, load_mapping
from .selection import load_manifest
from .timeline import (ResolvedTime, check_monotonic, resolve_anchor, resolve_times, to_c8y_time)

log = logging.getLogger("replay.engine")

MODES = ("dry_run", "publish")
PACE_MODES = ("fixed_interval", "timeline_scaled", "asap")


class RunRejected(ValueError):
    """The request cannot become a run. `reasons` lists why."""
    def __init__(self, reasons: list[str]):
        super().__init__("; ".join(reasons))
        self.reasons = reasons


@dataclass
class RunRequest:
    asset: str
    sequence_id: str
    mode: str = "dry_run"
    timestamp_policy: Optional[str] = None
    anchor_mode: Optional[str] = None
    anchor_time: Optional[str] = None
    pace_mode: Optional[str] = None
    pace_seconds: Optional[float] = None
    speed_factor: Optional[float] = None
    max_requests_per_second: Optional[float] = None
    reconstruct_interval_seconds: Optional[float] = None
    limit: Optional[int] = None        # first N observations; dry-run only
    paced: bool = False                # dry-run honours pacing only when asked


class Sink(Protocol):
    def send(self, payload: dict, obs: Observation) -> c8y.SendResult: ...


class DryRunSink:
    def send(self, payload: dict, obs: Observation) -> c8y.SendResult:
        return c8y.SendResult("DRY_RUN", None, 0, "not sent")


class C8ySink:
    def __init__(self, client: c8y.C8yClient, trace_name: Optional[str]):
        self.client, self.trace_name = client, trace_name

    def send(self, payload: dict, obs: Observation) -> c8y.SendResult:
        return self.client.post_measurement(payload, self.trace_name)


@dataclass
class Prepared:
    run_id: str
    request: RunRequest
    settings: Settings
    sequence: Sequence
    times: list[ResolvedTime]
    payloads: list[dict]
    anchor_resolved: datetime
    mapping_status: str
    blockers: list[str]
    summary: dict


@dataclass
class Run:
    prepared: Prepared
    state: str = "CREATED"
    counters: dict[str, int] = field(default_factory=dict)
    error: Optional[str] = None
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    stop_event: threading.Event = field(default_factory=threading.Event)
    thread: Optional[threading.Thread] = None
    ledger_path: Optional[str] = None

    @property
    def run_id(self) -> str:
        return self.prepared.run_id

    def status(self) -> dict:
        return {"run_id": self.run_id, "state": self.state, "mode": self.prepared.request.mode,
                "asset": self.prepared.request.asset, "sequence_id": self.prepared.sequence.sequence_id,
                "total": len(self.prepared.payloads), "counters": dict(self.counters), "error": self.error,
                "started_at": self.started_at, "finished_at": self.finished_at, "ledger": self.ledger_path}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class ReplayManager:
    def __init__(self, settings: Settings, client_factory: Optional[Callable[[Settings], c8y.C8yClient]] = None,
                 sleep: Callable[[float], None] = time.sleep):
        self.s = settings
        self._runs: dict[str, Run] = {}
        self._lock = threading.Lock()
        self._client_factory = client_factory or self._default_client
        self._sleep = sleep

    # ---------------- prepare ----------------
    def _default_client(self, s: Settings) -> c8y.C8yClient:
        return c8y.C8yClient(s.c8y_base_url, s.c8y_user, s.c8y_password, s.c8y_tenant,
                             s.http_connect_timeout, s.http_read_timeout, s.http_max_attempts, s.http_backoff_seconds)

    def prepare(self, req: RunRequest) -> Prepared:
        s = self.s
        if req.mode not in MODES:
            raise RunRejected([f"mode must be one of {MODES}"])
        if req.asset not in ("battery", "transformer"):
            raise RunRejected(["asset must be 'battery' or 'transformer'"])
        pol = req.timestamp_policy or s.timestamp_policy
        a_mode = req.anchor_mode or s.anchor_mode
        a_time = req.anchor_time or s.anchor_time
        p_mode = req.pace_mode or s.pace_mode
        p_sec = req.pace_seconds if req.pace_seconds is not None else s.pace_seconds
        speed = req.speed_factor if req.speed_factor is not None else s.speed_factor
        rps = req.max_requests_per_second if req.max_requests_per_second is not None else s.max_requests_per_second
        interval = req.reconstruct_interval_seconds or s.transformer_source_interval_seconds
        if p_mode not in PACE_MODES:
            raise RunRejected([f"pace_mode must be one of {PACE_MODES}"])
        if rps <= 0 or p_sec < 0 or speed <= 0:
            raise RunRejected(["pace_seconds must be >= 0, speed_factor > 0 and max_requests_per_second > 0"])

        manifest = load_manifest(s.selection_manifest)
        if req.asset == "battery":
            try:
                cycle = int(req.sequence_id.split("-")[-1])
            except ValueError:
                raise RunRejected(["battery sequence_id must be a Cycle number, e.g. '123'"])
            seq = BatteryAdapter(s).load_sequence(cycle, manifest["battery"])
        else:
            ad = TransformerAdapter(s)
            try:
                seq = ad.load_sequence(req.sequence_id, manifest["transformer"])
            finally:
                ad.close()

        errors = list(seq.validation_errors)
        if errors:
            raise RunRejected(errors)

        observations = seq.observations
        partial = False
        if req.limit is not None:
            if req.mode != "dry_run":
                raise RunRejected(["'limit' (partial sequence) is only allowed in dry_run mode"])
            if req.limit < 1:
                raise RunRejected(["limit must be >= 1"])
            observations = observations[: req.limit]
            partial = len(observations) < len(seq.observations)
        if len(observations) > s.max_observations_per_run:
            raise RunRejected([f"{len(observations)} observations exceeds MAX_OBSERVATIONS_PER_RUN={s.max_observations_per_run}; "
                               "large runs wait for integration team confirmation of tenant limits"])
        flagged = [o for o in observations if o.flags]
        if flagged and s.flagged_rows_policy == "block":
            raise RunRejected([f"{len(flagged)} flagged observation(s) and FLAGGED_ROWS_POLICY=block"])

        anchor = resolve_anchor(a_time)
        try:
            times = resolve_times(observations, pol, anchor, a_mode, interval)
        except ValueError as e:
            raise RunRejected([str(e)])
        t_issues = check_monotonic(times)
        if t_issues:
            raise RunRejected(t_issues)

        mapping = load_mapping(s.mapping_path)
        mapping_status = str(mapping.get("status", "UNKNOWN"))
        run_id = uuid.uuid4().hex[:12]
        device = s.device_id_for(req.asset) if req.mode == "publish" else None
        payloads = [build_measurement(mapping, o, t, run_id, device) for o, t in zip(observations, times)]

        blockers = s.publish_blockers(req.asset, mapping_status)
        if seq.selection_status != "MODEL_OWNER_APPROVED":
            blockers.append("sequence is not in the model-owner approved selection manifest")
        if req.mode == "publish" and blockers:
            raise RunRejected(["publish blocked: " + b for b in blockers])

        summary = self._summarize(seq, observations, times, payloads, flagged, anchor, a_mode, pol, interval,
                                  p_mode, p_sec, speed, rps, partial, mapping_status, blockers)
        return Prepared(run_id, replace(req, timestamp_policy=pol, anchor_mode=a_mode, anchor_time=a_time, pace_mode=p_mode,
                                        pace_seconds=p_sec, speed_factor=speed, max_requests_per_second=rps,
                                        reconstruct_interval_seconds=interval),
                        s, seq, times, payloads, anchor, mapping_status, blockers, summary)

    def _summarize(self, seq, obs, times, payloads, flagged, anchor, a_mode, pol, interval, p_mode, p_sec, speed, rps,
                   partial, mapping_status, blockers) -> dict:
        deltas = [(times[i].time - times[i - 1].time).total_seconds() for i in range(1, len(times))]
        src_deltas = [(obs[i].source_time - obs[i - 1].source_time).total_seconds()
                      for i in range(1, len(obs)) if obs[i].source_time and obs[i - 1].source_time]
        gap = max(p_sec, 1.0 / rps)
        if p_mode == "asap":
            est = len(obs) / rps
        elif p_mode == "timeline_scaled":
            est = sum(max(d / speed, 1.0 / rps) for d in deltas)
        else:
            est = max(0, len(obs) - 1) * gap
        return {
            "asset": seq.asset, "sequence_id": seq.sequence_id, "selection_status": seq.selection_status,
            "partial_sequence": partial, "observations": len(obs), "source_observations": len(seq.observations),
            "source_info": seq.source_info,
            "timeline": {
                "policy": pol, "anchor_mode": a_mode, "anchor_resolved_utc": to_c8y_time(anchor),
                "time_origin": times[0].origin if times else None,
                "reconstructed_interval_seconds": interval if pol == "reconstructed" else None,
                "first": to_c8y_time(times[0].time) if times else None,
                "last": to_c8y_time(times[-1].time) if times else None,
                "interval_seconds": ({"min": min(deltas), "median": statistics.median(deltas), "max": max(deltas)} if deltas else None),
                "intervals_equal_to_source": (bool(src_deltas) and all(abs(a - b) < 1e-6 for a, b in zip(deltas, src_deltas))
                                              if pol == "shifted" else None),
                "future_timestamps": bool(times and times[-1].time > datetime.now(timezone.utc)),
            },
            "pacing": {"mode": p_mode, "pace_seconds": p_sec, "speed_factor": speed, "max_requests_per_second": rps,
                       "estimated_duration_seconds": round(est, 1), "note": "pace is independent of the historical sampling interval"},
            "flagged": {"count": len(flagged),
                        "examples": [{"observation_id": o.observation_id, "flags": list(o.flags), "values": o.values} for o in flagged[:10]],
                        "policy": self.s.flagged_rows_policy},
            "exclusions": [{"reason": e.reason, "count": e.count, "detail": e.detail, "rows_listed": e.rows} for e in seq.exclusions],
            "reference_labels": seq.reference,
            "warnings": seq.validation_warnings,
            "mapping_status": mapping_status,
            "publish_blockers": blockers,
            "payload_preview": {"first": payloads[0] if payloads else None, "last": payloads[-1] if payloads else None},
        }

    # ---------------- run lifecycle ----------------
    def create(self, req: RunRequest) -> Run:
        prep = self.prepare(req)
        with self._lock:
            active = [r for r in self._runs.values() if r.state in ("CREATED", "RUNNING")]
            if len(active) >= self.s.max_concurrent_runs:
                raise RunRejected([f"MAX_CONCURRENT_RUNS={self.s.max_concurrent_runs} reached"])
            run = Run(prep, counters={})
            self._runs[run.run_id] = run
        self._write_preview(run)
        run.thread = threading.Thread(target=self._execute, args=(run,), name=f"run-{run.run_id}", daemon=True)
        run.state = "RUNNING"
        run.started_at = _now_iso()
        run.thread.start()
        return run

    def get(self, run_id: str) -> Optional[Run]:
        return self._runs.get(run_id)

    def stop(self, run_id: str) -> Optional[Run]:
        r = self._runs.get(run_id)
        if r:
            r.stop_event.set()
        return r

    def _run_dir(self, run: Run) -> str:
        d = os.path.join(self.s.output_dir, run.run_id)
        os.makedirs(d, exist_ok=True)
        return d

    def _write_preview(self, run: Run) -> None:
        d = self._run_dir(run)
        with open(os.path.join(d, "preview.json"), "w", encoding="utf-8") as fh:
            json.dump({"summary": run.prepared.summary, "payloads": run.prepared.payloads}, fh, indent=1, default=str)
        run.ledger_path = os.path.join(d, "ledger.jsonl")

    def _delay_before(self, prep: Prepared, i: int) -> float:
        if i == 0:
            return 0.0
        r = prep.request
        min_gap = 1.0 / r.max_requests_per_second
        if r.pace_mode == "asap":
            return min_gap
        if r.pace_mode == "timeline_scaled":
            d = (prep.times[i].time - prep.times[i - 1].time).total_seconds() / r.speed_factor
            return max(d, min_gap)
        return max(r.pace_seconds, min_gap)

    def _execute(self, run: Run) -> None:
        prep = run.prepared
        req = prep.request
        counters = run.counters
        try:
            if req.mode == "publish":
                client = self._client_factory(self.s)
                ok, detail = client.check_device(self.s.device_id_for(req.asset))
                if not ok:
                    run.state, run.error = "FAILED", f"preflight: {detail}"
                    return
                mapping = load_mapping(self.s.mapping_path)
                tf = mapping.get("trace_fragment", {})
                sink: Sink = C8ySink(client, tf.get("name") if tf.get("enabled") else None)
            else:
                sink = DryRunSink()
            honour_pacing = req.mode == "publish" or req.paced
            with open(run.ledger_path, "a", encoding="utf-8") as ledger:
                for i, payload in enumerate(prep.payloads):
                    if run.stop_event.is_set():
                        run.state = "STOPPED"; return
                    if honour_pacing:
                        d = self._delay_before(prep, i)
                        if d and run.stop_event.wait(d):
                            run.state = "STOPPED"; return
                    obs = prep.sequence.observations[i]
                    res = sink.send(payload, obs)
                    counters[res.status] = counters.get(res.status, 0) + 1
                    ledger.write(json.dumps({"ts": _now_iso(), "run_id": run.run_id, "observation_id": obs.observation_id,
                                             "time": payload["time"], "status": res.status, "http_status": res.http_status,
                                             "attempts": res.attempts, "detail": res.detail}) + "\n")
                    ledger.flush()
                    if res.status == c8y.REJECTED or res.status == c8y.FAILED:
                        run.state, run.error = "FAILED", f"{res.status} at {obs.observation_id}: {res.detail}"; return
                    if res.status == c8y.UNCONFIRMED and self.s.on_unconfirmed == "halt":
                        run.state, run.error = "HALTED_UNCONFIRMED", f"delivery of {obs.observation_id} could not be confirmed"; return
            run.state = "COMPLETED"
        except Exception as e:  # keep the service alive; record the failure
            run.state, run.error = "FAILED", f"{type(e).__name__}: {e}"
            log.exception("run failed", extra={"ctx": {"run_id": run.run_id}})
        finally:
            run.finished_at = _now_iso()
            log.info("run finished", extra={"ctx": {"run_id": run.run_id, "state": run.state, "counters": counters}})
