"""Battery adapter (initial scope: Current_measured and Voltage_measured only).

Rules from the approved baseline:
  * Original values are preserved: no clipping, removal or sign reversal.
  * Unusual voltage and negative charge current are FLAGGED for review only.
  * Impedance rows are excluded from this adapter and the exclusion is recorded.
  * RUL is carried as a reference label (basis: existing operation index), never as an input.
  * A "sequence" is one Cycle value of the source file (one operation: charge or discharge).
"""
from __future__ import annotations

import csv
from datetime import datetime, timedelta, timezone
from typing import Iterator, Optional
from zoneinfo import ZoneInfo

from ..config import Settings
from ..models import Exclusion, Observation, Sequence

REQUIRED_COLUMNS = ("Cycle", "type", "Time", "Datetime", "Voltage_measured", "Current_measured", "RUL")
MAX_EXCLUDED_ROWS_LISTED = 50
SUPPORTED_TYPES = ("charge", "discharge")


class BatteryDataError(ValueError):
    pass


def _parse_float(text: str) -> Optional[float]:
    t = (text or "").strip()
    if t == "":
        return None
    try:
        v = float(t)
    except ValueError:
        return None
    return None if v != v else v  # NaN -> None


def parse_source_datetime(text: str, tz_name: str) -> datetime:
    """Source Datetime has no timezone. The zone is a CONFIGURED assumption (default UTC)."""
    t = text.strip().replace("T", " ")
    fmt = "%Y-%m-%d %H:%M:%S.%f" if "." in t else "%Y-%m-%d %H:%M:%S"
    naive = datetime.strptime(t, fmt)
    return naive.replace(tzinfo=ZoneInfo(tz_name)).astimezone(timezone.utc)


class BatteryAdapter:
    def __init__(self, settings: Settings):
        if not settings.battery_csv_path:
            raise BatteryDataError("BATTERY_CSV_PATH is not configured")
        self.s = settings
        self.path = settings.battery_csv_path

    # -------- reading (read-only) --------
    def _rows(self) -> Iterator[tuple[int, dict]]:
        with open(self.path, "r", newline="", encoding="utf-8") as fh:  # read-only
            reader = csv.DictReader(fh)
            missing = [c for c in REQUIRED_COLUMNS if c not in (reader.fieldnames or [])]
            if missing:
                raise BatteryDataError(f"{self.path} is missing required columns: {missing}")
            for n, row in enumerate(reader, start=1):  # n = 1-based data row number
                yield n, row

    def list_sequences(self) -> list[dict]:
        """One entry per Cycle: type, row count, usable (non-missing V and I) row count."""
        info: dict[int, dict] = {}
        for n, r in self._rows():
            c = int(float(r["Cycle"]))
            e = info.setdefault(c, {"cycle": c, "type": r["type"], "rows": 0, "usable_rows": 0, "first_row": n})
            e["rows"] += 1
            if _parse_float(r["Voltage_measured"]) is not None and _parse_float(r["Current_measured"]) is not None:
                e["usable_rows"] += 1
        return [info[k] for k in sorted(info)]

    def load_sequence(self, cycle: int, approved_cycles: Optional[set[int]] = None) -> Sequence:
        s = self.s
        rows = [(n, r) for n, r in self._rows() if int(float(r["Cycle"])) == int(cycle)]
        if not rows:
            raise BatteryDataError(f"cycle {cycle} not found in {self.path}")
        types = {r["type"] for _, r in rows}
        if len(types) != 1:
            raise BatteryDataError(f"cycle {cycle} has mixed operation types {sorted(types)}; refusing to mix")
        op_type = next(iter(types))
        seq_id = f"{s.battery_dataset_id}-cycle-{int(cycle)}"
        seq = Sequence(asset="battery", sequence_id=seq_id, observations=[],
                       source_info={"file": self.path.split("/")[-1], "cycle": int(cycle), "operation_type": op_type,
                                    "dataset": s.battery_dataset_id})

        if op_type not in SUPPORTED_TYPES:
            seq.exclusions.append(Exclusion(
                reason="impedance_rows_not_in_initial_adapter" if op_type == "impedance" else f"unsupported_type_{op_type}",
                count=len(rows),
                detail={"cycle": int(cycle), "type": op_type,
                        "note": "Impedance mapping requires separate preprocessing confirmation."},
                rows=[n for n, _ in rows[:MAX_EXCLUDED_ROWS_LISTED]]))
            seq.validation_errors.append(f"cycle {cycle} is an '{op_type}' operation; nothing to replay in the Current/Voltage adapter")
            return seq

        missing_rows: list[int] = []
        prev_t: Optional[float] = None
        idx = 0
        for n, r in rows:
            v = _parse_float(r["Voltage_measured"])
            i = _parse_float(r["Current_measured"])
            t_off = _parse_float(r["Time"])
            if v is None or i is None:
                missing_rows.append(n)
                continue
            if t_off is None:
                seq.validation_errors.append(f"row {n}: Time offset missing")
                continue
            if prev_t is not None and t_off <= prev_t:
                seq.validation_errors.append(f"row {n}: Time offset not strictly increasing ({prev_t} -> {t_off}); rows are not re-ordered")
            prev_t = t_off
            try:
                start = parse_source_datetime(r["Datetime"], s.battery_source_timezone)
            except ValueError:
                seq.validation_errors.append(f"row {n}: unparseable Datetime {r['Datetime']!r}")
                continue
            src_time = start + timedelta(seconds=t_off)

            flags: list[str] = []
            if op_type == "charge" and i < 0:
                flags.append("charge_current_negative")
            if s.battery_voltage_review_max is not None and v > s.battery_voltage_review_max:
                flags.append("voltage_above_review_max")
            if s.battery_voltage_review_min is not None and v < s.battery_voltage_review_min:
                flags.append("voltage_below_review_min")

            rul = _parse_float(r["RUL"])
            seq.observations.append(Observation(
                observation_id=f"{s.battery_dataset_id}-c{int(cycle):04d}-r{n}",
                asset="battery", sequence_id=seq_id, index=idx,
                values={"Current": i, "Voltage": v},
                source_time=src_time, flags=tuple(flags),
                reference={"RUL": rul, "RUL_basis": "operation_index_as_supplied"},
                source_ref={"file_row": n, "cycle": int(cycle), "operation_type": op_type,
                            "time_offset_seconds": t_off, "source_datetime": r["Datetime"],
                            "source_timezone_assumed": s.battery_source_timezone}))
            idx += 1

        if missing_rows:
            seq.exclusions.append(Exclusion(
                reason="missing_voltage_or_current", count=len(missing_rows),
                detail={"cycle": int(cycle)}, rows=missing_rows[:MAX_EXCLUDED_ROWS_LISTED]))
        seq.reference = {"RUL_first": seq.observations[0].reference["RUL"] if seq.observations else None,
                         "RUL_last": seq.observations[-1].reference["RUL"] if seq.observations else None,
                         "RUL_basis": "operation_index_as_supplied"}

        # contract checks (configurable; verify against the deployed OpenAPI)
        n_obs = len(seq.observations)
        if n_obs < s.battery_contract_min or n_obs > s.battery_contract_max:
            seq.validation_errors.append(
                f"{n_obs} observations is outside the Battery contract range {s.battery_contract_min}..{s.battery_contract_max}")
        if n_obs < s.battery_full_window:
            seq.validation_warnings.append(
                f"{n_obs} observations is below the {s.battery_full_window}-reading full window; "
                "padding would happen downstream and is not part of this service")
        flagged = sum(1 for o in seq.observations if o.flags)
        if flagged:
            seq.validation_warnings.append(f"{flagged} observation(s) flagged for review (values preserved)")
        seq.selection_status = "MODEL_OWNER_APPROVED" if approved_cycles and int(cycle) in approved_cycles else "NOT_MODEL_OWNER_APPROVED"
        return seq
