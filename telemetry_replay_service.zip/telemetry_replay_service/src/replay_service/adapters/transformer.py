"""Transformer adapter (H2, CO, C2H4, C2H2).

Rules from the approved baseline:
  * The archive is opened read-only and read in place; the original splits are never modified.
  * Split membership comes from the folder (data_train / data_test) and is reported, not changed.
  * Source files carry no timestamps. Any timestamp is RECONSTRUCTED from a configured interval and labelled.
  * No padding, no interpolation, gas readings of one row always stay together.
  * Gas units are undocumented: no unit is attached and no conversion is applied.
"""
from __future__ import annotations

import csv
import io
import os
import re
import zipfile
from typing import Optional

from ..config import Settings
from ..models import Exclusion, Observation, Sequence

GASES = ("H2", "CO", "C2H4", "C2H2")
_MEMBER = re.compile(r"(?:^|/)(data_[a-z]+)/([^/]+\.csv)$")
_LABEL = re.compile(r"(?:^|/)labels_(rul|fdd)_([a-z]+)\.csv$")


class TransformerDataError(ValueError):
    pass


class _Source:
    """Uniform read-only access to a directory or a zip archive."""

    def __init__(self, path: str):
        self.path = path
        self.is_zip = os.path.isfile(path) and path.lower().endswith(".zip")
        if not self.is_zip and not os.path.isdir(path):
            raise TransformerDataError(f"TRANSFORMER_SOURCE {path!r} is neither a directory nor a .zip")
        self._zip = zipfile.ZipFile(path, "r") if self.is_zip else None

    def names(self) -> list[str]:
        if self._zip:
            return [i.filename for i in self._zip.infolist() if not i.is_dir()]
        out = []
        for root, _, files in os.walk(self.path):
            for f in files:
                out.append(os.path.relpath(os.path.join(root, f), self.path).replace(os.sep, "/"))
        return out

    def read(self, name: str) -> bytes:
        if self._zip:
            return self._zip.read(name)
        with open(os.path.join(self.path, name), "rb") as fh:  # read-only
            return fh.read()

    def close(self):
        if self._zip:
            self._zip.close()


class TransformerAdapter:
    def __init__(self, settings: Settings):
        if not settings.transformer_source:
            raise TransformerDataError("TRANSFORMER_SOURCE is not configured")
        self.s = settings
        self.src = _Source(settings.transformer_source)
        self._members: Optional[dict[str, dict]] = None
        self._labels: Optional[dict] = None

    def close(self):
        self.src.close()

    # -------- structure --------
    def members(self) -> dict[str, dict]:
        """Map 'data_train/2_trans_1.csv' -> {split, file}. Files outside data_* folders are ignored here."""
        if self._members is None:
            m = {}
            for name in self.src.names():
                mm = _MEMBER.search(name)
                if mm:
                    m[name] = {"split": mm.group(1), "file": mm.group(2)}
            self._members = m
        return self._members

    def labels(self) -> dict:
        if self._labels is None:
            lab: dict = {"rul": {}, "fdd": {}}
            for name in self.src.names():
                mm = _LABEL.search(name)
                if not mm:
                    continue
                kind, split = mm.group(1), mm.group(2)
                text = self.src.read(name).decode("utf-8")
                for row in csv.DictReader(io.StringIO(text)):
                    key = (f"data_{split}", row["id"])
                    lab[kind][key] = row.get("predicted") if kind == "rul" else row.get("category")
            self._labels = lab
        return self._labels

    def resolve(self, sequence_id: str) -> str:
        """Accept 'data_test/2_trans_1.csv' or a bare file name when it is unambiguous."""
        mem = self.members()
        if sequence_id in mem:
            return sequence_id
        hits = [k for k, v in mem.items() if v["file"] == sequence_id]
        if len(hits) == 1:
            return hits[0]
        if len(hits) > 1:
            raise TransformerDataError(f"{sequence_id!r} exists in several splits {hits}; qualify it with the split folder")
        raise TransformerDataError(f"sequence {sequence_id!r} not found")

    # -------- loading --------
    def load_sequence(self, sequence_id: str, approved_ids: Optional[set[str]] = None) -> Sequence:
        s = self.s
        name = self.resolve(sequence_id)
        meta = self.members()[name]
        text = self.src.read(name).decode("utf-8")
        reader = csv.reader(io.StringIO(text))
        header = next(reader, None)
        seq = Sequence(asset="transformer", sequence_id=name, observations=[],
                       source_info={"file": meta["file"], "split": meta["split"], "archive": os.path.basename(s.transformer_source or "")})
        if header is None or tuple(h.strip() for h in header) != GASES:
            seq.validation_errors.append(f"unexpected columns {header!r}; expected {list(GASES)} in that order")
            return seq

        bad_rows: list[int] = []
        for n, row in enumerate(reader, start=1):
            try:
                vals = [float(x) for x in row]
            except ValueError:
                bad_rows.append(n); continue
            if len(vals) != len(GASES) or any(v != v for v in vals):
                bad_rows.append(n); continue
            flags = tuple(f"{g}_negative" for g, v in zip(GASES, vals) if v < 0)
            seq.observations.append(Observation(
                observation_id=f"{meta['split']}:{meta['file']}:r{n}",
                asset="transformer", sequence_id=name, index=len(seq.observations),
                values=dict(zip(GASES, vals)),   # four gases always travel together
                source_time=None, flags=flags,
                source_ref={"file_row": n, "file": meta["file"], "split": meta["split"], "time_origin": "none_in_source"}))
        if bad_rows:
            seq.exclusions.append(Exclusion("unparseable_or_incomplete_row", len(bad_rows), {}, bad_rows[:50]))
            seq.validation_errors.append(f"{len(bad_rows)} unparseable/incomplete row(s); sequence is not complete, nothing is padded or interpolated")

        n_obs = len(seq.observations)
        if n_obs != s.transformer_required_length:
            seq.validation_errors.append(
                f"sequence has {n_obs} observations; the Transformer contract requires exactly {s.transformer_required_length}")

        lab = self.labels()
        key = (meta["split"], meta["file"])
        seq.reference = {"rul_label": lab["rul"].get(key), "rul_label_source_column": "predicted",
                         "fdd_category": lab["fdd"].get(key),
                         "note": "Reference labels from the dataset; the 'predicted' column name is ambiguous and is NOT a model output."}
        seq.selection_status = "MODEL_OWNER_APPROVED" if approved_ids and name in approved_ids else "NOT_MODEL_OWNER_APPROVED"
        return seq
