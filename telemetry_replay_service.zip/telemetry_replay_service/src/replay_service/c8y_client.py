"""Minimal Cumulocity client for measurement publishing.

Safety properties:
  * No method creates or modifies devices. Only an existing device can be read (preflight).
  * Credentials come from the caller (environment) and are never logged.
  * A timeout or 5xx may mean the measurement WAS accepted. Before any retry the client looks the
    measurement up; it only retries when the lookup shows it is absent.
  * If the lookup itself fails the result is UNCONFIRMED and nothing more is sent for that observation.
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import timedelta
from typing import Any, Callable, Optional

import requests
from requests.auth import HTTPBasicAuth

from .timeline import parse_utc

log = logging.getLogger("replay.c8y")

MEAS_TYPE = "application/vnd.com.nsn.cumulocity.measurement+json"
MEAS_COLL = "application/vnd.com.nsn.cumulocity.measurementCollection+json"

DELIVERED = "DELIVERED"
DELIVERED_RECONCILED = "DELIVERED_RECONCILED"
REJECTED = "REJECTED"
UNCONFIRMED = "UNCONFIRMED"
FAILED = "FAILED"


@dataclass
class SendResult:
    status: str
    http_status: Optional[int] = None
    attempts: int = 0
    detail: str = ""


def _is_not_connected(exc: Exception) -> bool:
    """True when the connection was never established, so the request cannot have been processed."""
    inner = exc.args[0] if exc.args else None
    reason = getattr(inner, "reason", None)
    name = type(reason).__name__ if reason is not None else ""
    return name in ("NewConnectionError", "NameResolutionError")


class C8yClient:
    def __init__(self, base_url: str, user: str, password: str, tenant: Optional[str] = None,
                 connect_timeout: float = 5.0, read_timeout: float = 15.0,
                 max_attempts: int = 3, backoff_seconds: float = 1.0,
                 session: Optional[requests.Session] = None,
                 sleep: Callable[[float], None] = time.sleep):
        self.base = base_url.rstrip("/")
        self._auth = HTTPBasicAuth(f"{tenant}/{user}" if tenant else user, password)
        self.timeout = (connect_timeout, read_timeout)
        self.max_attempts = max(1, max_attempts)
        self.backoff = backoff_seconds
        self.session = session or requests.Session()
        self._sleep = sleep

    def __repr__(self) -> str:
        return f"C8yClient(base={self.base!r})"

    # ---- read-only preflight ----
    def check_device(self, device_id: str) -> tuple[bool, str]:
        try:
            r = self.session.get(f"{self.base}/inventory/managedObjects/{device_id}", auth=self._auth,
                                 headers={"Accept": "application/json"}, timeout=self.timeout)
        except requests.RequestException as e:
            return False, f"device lookup failed: {type(e).__name__}"
        if r.status_code == 200:
            return True, "device exists"
        return False, f"device lookup returned HTTP {r.status_code}"

    # ---- duplicate reconciliation ----
    def find_measurement(self, payload: dict, trace_name: Optional[str]) -> Optional[bool]:
        """True = present, False = absent, None = could not determine."""
        try:
            t = parse_utc(payload["time"])
            params = {
                "source": payload["source"]["id"], "type": payload["type"],
                "dateFrom": (t - timedelta(milliseconds=1)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
                "dateTo": (t + timedelta(milliseconds=1)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
                "pageSize": 10,
            }
            r = self.session.get(f"{self.base}/measurement/measurements", params=params, auth=self._auth,
                                 headers={"Accept": MEAS_COLL}, timeout=self.timeout)
            if r.status_code != 200:
                return None
            for m in r.json().get("measurements", []):
                if trace_name and trace_name in payload:
                    got = (m.get(trace_name) or {}).get("observationId")
                    if got == payload[trace_name].get("observationId"):
                        return True
                else:
                    if all(m.get(k) == v for k, v in payload.items() if k not in ("source", "time")):
                        return True
            return False
        except (requests.RequestException, ValueError, KeyError):
            return None

    # ---- publish ----
    def post_measurement(self, payload: dict[str, Any], trace_name: Optional[str] = None) -> SendResult:
        last = SendResult(FAILED, None, 0, "no attempt made")
        for attempt in range(1, self.max_attempts + 1):
            outcome, http_status, detail = self._post_once(payload)
            last = SendResult(FAILED, http_status, attempt, detail)
            if outcome == "ok":
                return SendResult(DELIVERED, http_status, attempt, "created")
            if outcome == "rejected":
                return SendResult(REJECTED, http_status, attempt, detail)
            if outcome == "ambiguous":
                found = self.find_measurement(payload, trace_name)
                if found is True:
                    return SendResult(DELIVERED_RECONCILED, http_status, attempt, "found after ambiguous response: not re-sent")
                if found is None:
                    return SendResult(UNCONFIRMED, http_status, attempt, f"{detail}; could not verify whether it was stored")
            # safe_retry, or ambiguous and confirmed absent
            if attempt < self.max_attempts:
                self._sleep(self.backoff * (2 ** (attempt - 1)))
        return last

    def _post_once(self, payload: dict) -> tuple[str, Optional[int], str]:
        try:
            r = self.session.post(f"{self.base}/measurement/measurements", json=payload, auth=self._auth,
                                  headers={"Content-Type": MEAS_TYPE, "Accept": MEAS_TYPE}, timeout=self.timeout)
        except requests.ConnectTimeout:
            return "safe_retry", None, "connect timeout (request not sent)"
        except requests.ReadTimeout:
            return "ambiguous", None, "read timeout (request may have been processed)"
        except requests.ConnectionError as e:
            if _is_not_connected(e):
                return "safe_retry", None, "could not connect (request not sent)"
            return "ambiguous", None, "connection dropped (request may have been processed)"
        except requests.RequestException as e:
            return "ambiguous", None, f"{type(e).__name__}"
        if r.status_code in (200, 201):
            return "ok", r.status_code, "created"
        if r.status_code == 429:
            retry_after = r.headers.get("Retry-After")
            try:
                self._sleep(min(float(retry_after), 30.0)) if retry_after else None
            except ValueError:
                pass
            return "safe_retry", 429, "rate limited"
        if 500 <= r.status_code < 600:
            return "ambiguous", r.status_code, f"server error {r.status_code}"
        snippet = ""
        try:
            snippet = str(r.json().get("message", ""))[:200]
        except ValueError:
            pass
        return "rejected", r.status_code, f"HTTP {r.status_code} {snippet}".strip()
