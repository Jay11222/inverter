"""Model-owner approved selection manifest (read-only).

Example file:
  {"approved_by": "<model owner>", "battery": [123], "transformer": ["data_test/2_trans_1.csv"]}
"""
from __future__ import annotations

import json
from typing import Optional


def load_manifest(path: Optional[str]) -> dict:
    if not path:
        return {"battery": set(), "transformer": set(), "configured": False}
    with open(path, "r", encoding="utf-8") as fh:
        raw = json.load(fh)
    return {
        "battery": {int(x) for x in raw.get("battery", [])},
        "transformer": {str(x) for x in raw.get("transformer", [])},
        "approved_by": raw.get("approved_by"),
        "configured": True,
    }
