# Telemetry Replay Service (Battery and Transformer)

Replays dataset sequences as Cumulocity measurements. It publishes telemetry only. Model invocation, prediction stride and predictions belong to the orchestrator.

**Status:** dry-run capable and tested locally. Publishing is switched off and cannot be enabled until the target, mapping and selection are confirmed (see `docs/OPEN_ITEMS.md`). Nothing has been sent to any Cumulocity tenant.

## What it does

- Reads the datasets read-only, in place: the Battery CSV (`B0005_complete_RUL.csv`) and the Transformer `archive.zip`.
- Battery: Current (A) and Voltage (V). One `Cycle` is one sequence. Impedance rows are excluded and the exclusion is recorded.
- Transformer: H2, CO, C2H4, C2H2 as one measurement per row, no unit, exactly 420 observations.
- Preserves original values. Unusual readings are flagged, never clipped, removed or sign-flipped.
- Keeps reference labels (`RUL`, `rul`, `fdd`) apart from telemetry. They are never sent.
- Builds the exact payloads first (dry-run preview) before anything can be published.

## Timestamps

| Policy | Meaning |
|---|---|
| `source` | Original timestamps (Battery only). |
| `shifted` | Original timestamps moved by one constant offset, so original intervals are preserved exactly. |
| `reconstructed` | Generated from `TRANSFORMER_SOURCE_INTERVAL_SECONDS` and labelled `reconstructed`. Needed for Transformer, whose files have none. |

`ANCHOR_MODE` (`start` or `end`) and `ANCHOR_TIME` (`now` is resolved once per run) place the timeline. Send time never replaces measurement time. The original timestamp is kept in the `replayTrace` fragment. Playback speed (`PACE_MODE`, `PACE_SECONDS`, `SPEED_FACTOR`, `MAX_REQUESTS_PER_SECOND`) is separate from the sampling interval.

## Publish gates (all required)

`PUBLISH_ENABLED=true`, `TARGET_APPROVED=true`, mapping `status` set to `APPROVED`, `C8Y_BASEURL`, `C8Y_USER`/`C8Y_PASSWORD`, an existing device ID for the asset, a `SELECTION_MANIFEST` that lists the sequence, and a complete (not partial) sequence. The service never creates devices. A timeout or 5xx triggers a lookup before any retry, so a measurement that was already stored is not sent twice. If the lookup fails the observation is `UNCONFIRMED` and the run halts.

## Run locally (dry run)

```bash
pip install -r requirements-dev.txt
export PYTHONPATH=src BATTERY_CSV_PATH=/path/B0005_complete_RUL.csv TRANSFORMER_SOURCE=/path/archive.zip
python -m replay_service.cli preview --asset battery --sequence 2 --out preview.json
python -m replay_service.cli preview --asset transformer --sequence data_test/2_trans_1.csv --policy reconstructed --anchor-mode end
python -m replay_service.inventory --battery-csv ... --transformer-zip ...      # read-only inventory
python -m replay_service.main                                                    # HTTP service on $PORT
pytest
```

## HTTP API

`GET /health`, `GET /config`, `GET /datasets/{battery|transformer}/sequences`, `POST /replays` (default `mode: dry_run`), `GET /replays`, `GET /replays/{run_id}`, `GET /replays/{run_id}/preview`, `POST /replays/{run_id}/stop`. Interactive docs at `/docs`.

## Layout

`src/replay_service/` code, `config/` proposed mapping and example manifest, `docs/` mapping proposal, dataset inventory and open items, `deploy/` pending packaging notes, `tests/` pytest suite using small synthetic fixtures and a local mock server. Datasets, run outputs and `.env` files are git-ignored and excluded from the image.
