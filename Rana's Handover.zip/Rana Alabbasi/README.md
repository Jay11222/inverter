# PMSM Inverter Fault Diagnosis API

`PMSMInverter`

FastAPI service that predicts the **operating state of an inverter-driven PMSM: normal operation (F0) or one of eight fault classes (F1–F8)**, from one record of 18 sensor and engineered features, using a trained XGBoost multi-class classification model.

This repository holds the deployable inference service, plus the training notebook and dataset kept for traceability (they are not part of the container image). It is being prepared for onboarding onto the IAIP dev environment, alongside the Electrical Assets battery and transformer RUL services.

<!-- Badges: add the Jenkins build-status badge here once the pipeline is created. -->

## Description

Given one measurement record of 18 numeric features, the service returns the predicted fault class, its plain-language description and the full probability distribution over all nine classes.

The 18 features are **received already calculated**; the service does not derive them from raw sensor data. Eight are sensor readings in physical units (phase currents, DC-bus voltage and current, three half-bridge temperatures, driver voltage). Ten are engineered from them (power, current imbalance, normalized currents, rate of change, moving averages, temperature spread).

Four of the engineered features need history from a continuous **10 Hz** stream: the two rate-of-change features need the previous sample, and the two moving averages need the last 10 samples (1.0 s). The upstream system that buffers the stream calculates them. The service itself is stateless: one record per request.

The only preprocessing inside the service is median imputation. `Current_Imbalance`, `Ia_Normalized` and `Ib_Normalized` may be sent as `null` when their denominator is exactly zero, and are filled with the training median, matching the training preprocessing exactly. Every other missing, NaN or infinite value is rejected.

| Class | Meaning |
|---|---|
| F0 | Normal operation |
| F1 | Open-circuit fault, switch S3 (high side) |
| F2 | Open-circuit fault, switch S6 (low side) |
| F3 | Short-circuit fault, switch S2 (low side) |
| F4 | Short-circuit fault, switch S3 (high side) |
| F5 | Short-circuit fault, switch S5 (high side) |
| F6 | Overheating, half-bridge 1 |
| F7 | Overheating, half-bridges 1 and 2 |
| F8 | Overheating, half-bridge 3 |

### What is not in the container image

The training notebook, the training dataset, the export and evaluation scripts, the test suite, local Python environments and caches are excluded from the image by an allow-list `.dockerignore`. Only the service code (`app/`), the exported model artifacts (`artifacts/`) and the runtime dependencies are in the image.

## Requirements

- Python 3.13
- Docker (for the containerized path)

### Tech stack

- FastAPI 0.141 + Uvicorn 0.54
- Pydantic v2 (2.13)
- XGBoost 3.4 (model), scikit-learn 1.9 (median imputer, label encoder), pandas 3.0 / numpy 2.5

All versions are pinned exactly in `requirements.txt`. The model artifacts must be loaded with these versions.

## Project structure

```
app/
  main.py                  FastAPI app (startup model loading, endpoints, logging)
  model.py                 Artifact loading, checksum verification, prediction
  schemas.py               Request/response schemas and validation rules
  feature_engineering.py   Reference calculation of the 18 features from raw ADC counts (not used at request time)
artifacts/
  pmsm_xgboost_model.joblib   Trained XGBoost classifier
  feature_imputer.joblib      Median imputer fitted on training data
  label_encoder.joblib        Mapping 0-8 -> F0-F8
  feature_schema.json         Ordered feature contract (units, formulas, history, null rules, ranges)
  model_metadata.json         Version, checksums, framework versions, dataset reference, metrics, limitations
samples/                   Valid/invalid sample requests, 11 reference cases with expected outputs, raw-ADC fixture
tests/                     pytest suite (38 tests)
training/
  export_artifacts.py      Reproduces the notebook's final model and writes artifacts/ (offline only)
  evaluate_via_api.py      Sends the full held-out test set to a running server and checks the metrics
notebooks/                 Training and evaluation notebook (traceability only; not the runtime)
processed_data/            Training dataset (not in the image)
Dockerfile
Jenkinsfile                CI/CD pipeline (not yet in the repository, see Roadmap)
requirements.txt
requirements-dev.txt       Test-only dependencies (pytest, httpx2)
```

The container is self-contained. It builds from this repository root with no external build context.

## Installation

### Clone

```bash
git clone https://github.com/raaalaw/PMSMInverter.git
cd PMSMInverter
```

### With Docker

```bash
docker build -t pmsm-inverter-fdd:local .
docker run --rm -p 8000:8000 pmsm-inverter-fdd:local
```

### Without Docker

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Either way, the service listens on `http://localhost:8000`. The port is set at run time (`-p` for Docker, `--port` for Uvicorn) and no environment variables are required, since the model artifacts ship inside the image. `PMSM_ARTIFACTS_DIR` is optional and only needed to load artifacts from a different folder.

The container runs as a non-root user and needs no internet access, mounted volumes or training data at run time. The model is loaded once at startup and is never retrained. If an artifact is missing or fails its checksum check, the service does not start.

## Usage

### API endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/health` | Health check + confirmation that the model artifacts loaded and were verified; usable as the platform readiness probe |
| GET | `/model-info` | Model metadata (version, ordered feature list, labels and label mapping, artifact checksums, framework versions, dataset reference, evaluation metrics, limitations) |
| POST | `/predict` | Predict the fault class (F0–F8) from one record of 18 features |
| GET | `/docs` | Auto-generated Swagger UI (FastAPI default) |

### Input features

| # | Feature | Unit | Type |
|---|---|---|---|
| 0 | `Ia_original` | A | Sensor |
| 1 | `Ib_original` | A | Sensor |
| 2 | `VDC` | V | Sensor |
| 3 | `IDC_original` | A | Sensor |
| 4 | `T1` | °C | Sensor |
| 5 | `T2` | °C | Sensor |
| 6 | `T3` | °C | Sensor |
| 7 | `VD` | V | Sensor |
| 8 | `Power_DC` | W | Engineered |
| 9 | `Power_AC` | W | Engineered |
| 10 | `Current_Imbalance` | ratio | Engineered (nullable) |
| 11 | `Ia_Normalized` | ratio | Engineered (nullable) |
| 12 | `Ib_Normalized` | ratio | Engineered (nullable) |
| 13 | `VDC_RateOfChange` | V/s | Engineered (needs previous sample) |
| 14 | `IDC_RateOfChange` | A/s | Engineered (needs previous sample) |
| 15 | `VDC_MovingAvg` | V | Engineered (needs last 10 samples) |
| 16 | `IDC_MovingAvg` | A | Engineered (needs last 10 samples) |
| 17 | `Temp_Diff_Max` | °C | Engineered |

Exact formulas, units, observed ranges, null rules and history requirements for every feature are in `artifacts/feature_schema.json`. The executable reference is `app/feature_engineering.py`.

### Example request

```bash
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "Ia_original": -3.592375366568916,
    "Ib_original": -1.9305962854349976,
    "VDC": -12.218963831867049,
    "IDC_original": -0.2199413489736068,
    "T1": 11.401304818190908,
    "T2": 12.063802076642958,
    "T3": 14.072288751798853,
    "VD": -7.331378299120228,
    "Power_DC": 4.521016617790807,
    "Power_AC": 61.847507331378246,
    "Current_Imbalance": -0.5964912280701754,
    "Ia_Normalized": 14.8,
    "Ib_Normalized": 8.0,
    "VDC_RateOfChange": 146.62756598240455,
    "IDC_RateOfChange": 0.7399999999999995,
    "VDC_MovingAvg": -21.01661779081132,
    "IDC_MovingAvg": -0.3995999999999999,
    "Temp_Diff_Max": 2.6709839336079426
  }'
```

All 18 keys are required and must be JSON numbers; key order does not matter. The same record is available as `samples/valid_request.json`:

```bash
curl -X POST http://localhost:8000/predict -H "Content-Type: application/json" -d @samples/valid_request.json
```

### Example response

```json
{
  "predicted_class": "F0",
  "predicted_class_description": "Normal operation (no fault)",
  "class_probabilities": {
    "F0": 0.6274804472923279, "F1": 0.08296232670545578, "F2": 0.08935420215129852,
    "F3": 0.03257238492369652, "F4": 0.032452329993247986, "F5": 0.03255513310432434,
    "F6": 0.0333830788731575, "F7": 0.03441251441836357, "F8": 0.03482760861515999
  },
  "imputed_features": [],
  "model_version": "1.0.0"
}
```

`class_probabilities` always holds all nine classes and sums to 1. `imputed_features` lists any nullable feature that was sent as `null` and filled with the training median.

### Invalid input

Invalid requests return **HTTP 422** with the failing field and the reason; no prediction is made. This covers a missing feature, a non-numeric value, `NaN` or infinity, `null` in a non-nullable feature, an unknown extra field, and an empty or malformed body. Submitted values are never echoed back or logged.

## Testing

```bash
pip install -r requirements-dev.txt
python -m pytest -q
```

Tests cover the health endpoint, artifact loading and checksum verification, a valid prediction, invalid-input handling, and 11 reference cases with locked expected classes and probabilities (`samples/expected_predictions.json`). The reference cases are real rows from the held-out test split.

To check a running server end to end against the full held-out test set (2,175 rows):

```bash
python training/evaluate_via_api.py --url http://localhost:8000
```

It exits non-zero unless the server reproduces the notebook's test metrics exactly.

## Model notes and limitations

The model artifacts are loaded at startup and used directly by the service. `GET /model-info` exposes the validation metrics and limitations recorded in `artifacts/model_metadata.json`.

| Metric (held-out test set, 2,175 rows) | Value |
|---|---|
| Macro F1 | 0.960095 |
| Accuracy | 0.9591 |
| Balanced accuracy | 0.9678 |

- **Validation scope:** trained and tested on one laboratory rig, with one continuous recording per fault class. Performance on other motors, inverters, sensors or sites is unknown.
- **F2 false alarms:** 71 of 290 F2 predictions on the test set were wrong, mostly true F0.
- **Probabilities are not calibrated:** the top probability never exceeds about 0.93. Use them to rank classes and watch trends, not as confidence percentages.
- **Closed set:** the model always returns one of F0–F8, including for conditions it has never seen.
- **Advisory use only:** act on a fault class only when it persists across several consecutive predictions. It must not be the sole basis for shutdown, safety or maintenance decisions.

The held-out test set was used once, for the final evaluation. The reference cases and sample requests in this repository are rows from that test set, so they must not be used for any future retraining or tuning.

## Visuals

No embedded screenshots or dashboard.

## Project status

Actively maintained. Model version 1.0.0.

Data Science has validated the container locally (build on linux/arm64 and linux/amd64, health check, model load, prediction, invalid-input handling, all 38 tests, and the full held-out test set through the running container). The service source is merged into `main`. AI Engineering hit a corporate certificate error during their first build and resolved it in their environment; their validation results are pending. The model is recommended for production by Data Science; lead approval is pending.

## Roadmap

- [x] Merge service source into `main`
- [ ] Complete AI Engineering validation
- [ ] Lead review and approval
- [ ] Confirm the upstream feature pipeline (platform calculates the 18 features from the 10 Hz stream)
- [ ] GitLab onboarding
- [ ] Jenkinsfile based on the approved platform pipeline template
- [ ] Branch strategy and CI/CD variables
- [ ] Container image registry target
- [ ] Jenkins build and automated image publish
- [ ] Deployment to IAIP dev (runtime target to be confirmed)
- [ ] Re-validation in IAIP dev, including data path verification and monitoring

## Contributing

1. Install dependencies: `pip install -r requirements-dev.txt`
2. Branch from `main` using a feature branch. Changes reach `main` through a pull/merge request, not direct pushes.
3. Run `python -m pytest -q` before opening a request.
4. Do not edit the files in `artifacts/` by hand. Regenerate them with `python training/export_artifacts.py` and bump the model version; the service refuses to start if a checksum does not match.
5. Do not change library versions in `requirements.txt` without re-exporting the artifacts.

Integration issues (container build, API contract, deployment) are handled in this repository. Model accuracy, retraining and feature engineering changes are raised with the Model / Data Science team instead.

## Support

For questions or issues, open an issue in this repository. For model questions, contact the Data Scientist. For integration and deployment, contact the AI Engineering team.

## Authors and acknowledgment

- **Model / Data Science team** - model development, feature engineering, training, validation, artifact export and inference service
- **AI Engineering team** - independent validation, CI/CD and IAIP onboarding

Model trained and validated on the publicly available PMSM-inverter-fault-diagnosis-3.0 dataset (Prof. Abdelkabir Bacha, ISEM, Hassan II University of Casablanca), https://zenodo.org/records/13974503.

## License

Internal project. The PMSM inverter fault dataset used to train and validate this model is publicly available under the Creative Commons Attribution 4.0 International license. No formal software license has been assigned to this codebase.
