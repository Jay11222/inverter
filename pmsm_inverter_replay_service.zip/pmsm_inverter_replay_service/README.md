# PMSM Inverter Telemetry Replay Service

Replays recorded rows of the PMSM inverter fault dataset into Cumulocity as measurements, so the PMSM inverter inference service (XGBoost, classes F0 to F8) can be tested on the IAIP dev environment. It is a standalone microservice with the same structure and safety rules as the Battery and Transformer telemetry replay service, which it does not change.

It publishes telemetry only. It does not call the model, build model requests or store predictions. The upstream feature pipeline and orchestrator (owned by others) turn the telemetry into model requests.

**Status:** dry-run capable and tested locally (97 automated tests, mutation check, real-data dry runs with the network disabled, HTTP service started from a clean environment). Publishing is off and cannot be enabled until the target, mapping, profile and selection are approved (see `docs/OPEN_ITEMS.md`). Nothing has been sent to any Cumulocity tenant. The Docker image has not been built.

## What it does

- Reads `processed_data/converted_dataset.csv` read-only, either directly or inside the Zenodo zip (record 14482932), in place. The file's SHA-256 is checked against the verified training copy (`EXPECTED_DATASET_SHA256`).
- Parses every value exactly from the file text and publishes it unchanged (full float64; `repr` reproduces the file text). No rounding, clipping, sign flips, smoothing, resampling, interpolation, padding or deduplication.
- One dataset row is one observation, sent as one measurement with all its series at one timestamp.
- Two telemetry profiles (the approved mapping selects one):
  - `sensor`: the 8 model sensor values plus the 3 raw ADC current counts `Ia_adc`, `Ib_adc`, `IDC_adc` (11 series). Represents the real device; upstream calculates the 10 engineered features.
  - `sensor_plus_features`: the 8 sensor values plus the 10 engineered features exactly as stored (18 series), so the inference path can be tested before the upstream pipeline exists.
- `FDD` is a reference label and `Timestamp` a relative index. Neither is ever a series. FDD is kept in the preview and the run report; the original Timestamp text goes into the `replayTrace` fragment.
- Non-finite values are never replaced. `NONFINITE_POLICY=omit` leaves that series out of that measurement and records it; `block` refuses the run.
- Flags for review (values kept): negative VDC or VD, repeated sensor combinations, values outside the ranges in the model contract, rows whose stored rolling features cross a class boundary, non-finite values.
- The preview reports class composition, selection kind, boundary-crossing rows, warm-up rows, model readiness, which rows need a `null`, the reproduced training/held-out partition of each row (with a warning when non-held-out rows are replayed), sample `/predict` bodies with reference labels, the pacing estimate and all publish blockers.

## Selections

A selection is a contiguous, inclusive row range of the processed file (`start_row`, `end_row`): a full class block, a window inside one block, or a window across a class transition. Proposed dry-run selections are in `config/selections.pending.json` (PENDING_APPROVAL; the service never reads it). Publishing needs an approved manifest (`SELECTION_MANIFEST`) that lists the exact range. Partial selections (`limit`) are dry-run only. A selection larger than `MAX_OBSERVATIONS_PER_RUN` is refused, never truncated.

## Timestamps and timing

| Setting | Meaning |
|---|---|
| `TIMESTAMP_POLICY=shifted` | anchor + (row Timestamp - Timestamp of the anchor row), in exact integer microseconds; keeps the 0.1 s spacing |
| `TIMESTAMP_POLICY=reconstructed` | anchor + i x `SOURCE_INTERVAL_SECONDS`, labelled `reconstructed` |
| `ANCHOR_MODE` / `ANCHOR_TIME` | `start` or `end`; ISO-8601 or `now` (resolved once per run). Generated times are UTC. |
| `SOURCE_INTERVAL_SECONDS=0.1` | spacing between measurement times (10 Hz) |
| `PACE_MODE`, `PACE_SECONDS`, `SPEED_FACTOR`, `MAX_REQUESTS_PER_SECOND` | send cadence only. Never changes measurement times. Default 1 request per second; real time would be 10 per second and needs integration team confirmation. |

Send time never replaces measurement time.

## Publish gates (all required)

`PUBLISH_ENABLED=true`, `TARGET_APPROVED=true`, mapping `status` `APPROVED` with `selected_profile` set and equal to the run profile, `C8Y_BASEURL`, `C8Y_USER`/`C8Y_PASSWORD`, an existing `C8Y_DEVICE_ID`, a `SELECTION_MANIFEST` listing the exact range, a complete selection, and the verified dataset hash. The service never creates devices or alarms. A timeout or 5xx triggers a lookup before any retry; if the lookup fails the observation is `UNCONFIRMED` and the run halts. 4xx is not retried.

## Run locally (dry run)

```bash
pip install -r requirements-dev.txt
export PYTHONPATH=src INVERTER_DATASET_PATH=/path/PMSM-inverter-fault-diagnosis-3.0.zip
python -m inverter_replay.cli dataset                                     # class blocks, partitions (no rows)
python -m inverter_replay.cli preview --start-row 6516 --end-row 6856 --profile sensor_plus_features --out preview.json
python tools/no_network.py -m inverter_replay.cli preview --start-row 4275 --end-row 4314   # network disabled
python -m inverter_replay.inventory --dataset /path/zip --model-repo /path/PMSMInverter     # read-only inventory
python -m inverter_replay.main                                            # HTTP service on $PORT (default 8080)
pytest
```

Offline tools (not in the image): `python -m inverter_replay.validation` (feature reproducibility, needs `requirements-validation.txt` and Python 3.12+), `tools/build_contract.py` (regenerates `config/model_contract.json` from the model repo), `tools/reference_case_bodies.py`, `tools/mutation_check.py`, `python -m inverter_replay.cli contract-check --openapi openapi.json` (compare with the deployed model API).

## HTTP API

`GET /health`, `GET /config`, `GET /dataset`, `POST /replays` (default `mode: dry_run`), `GET /replays`, `GET /replays/{run_id}`, `GET /replays/{run_id}/preview`, `POST /replays/{run_id}/stop`. Interactive docs at `/docs`. Example body: `{"start_row": 6516, "end_row": 6856, "profile": "sensor_plus_features"}`. Unknown fields are rejected.

## Layout

`src/inverter_replay/` code, `config/` proposed mapping, model contract, example and pending selections, `docs/` inspection report, mapping proposal, dataset inventory, feature reproducibility, open items, integration handoff, test report, samples, `deploy/` pending packaging notes, `tools/` offline tools, `tests/` pytest suite with synthetic fixtures and a local mock Cumulocity server. Datasets, run outputs and `.env` files are git-ignored and excluded from the image.

Dataset: PMSM-inverter-fault-diagnosis-3.0, Prof. Abdelkabir Bacha (ISEM, Hassan II University of Casablanca), Zenodo 14482932, CC BY 4.0. It is not included in this project.
