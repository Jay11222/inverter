# Packaging: pending confirmation from the deployment team

The Dockerfile in the project root is generic (python:3.11-slim, non-root user 10001, health check on `GET /health`, allow-list `.dockerignore`: only `src/`, `config/` and `requirements.txt` go into the image). It has **not been built** here because no Docker daemon was available. These points are deliberately not decided:

- Isolation level (PER_TENANT or MULTI_TENANT) and how service credentials reach the container. The service reads `C8Y_BASEURL`, `C8Y_TENANT`, `C8Y_USER`, `C8Y_PASSWORD` and `C8Y_DEVICE_ID` from the environment and has no defaults for any of them. If the platform uses another mechanism, only `config.py` needs to change.
- Cumulocity manifest (`cumulocity.json`), required roles, health and readiness probes, listening port (`PORT`, default 8080) and memory limits. The whole dataset is held in memory once loaded (about 10,900 rows).
- Image format and upload bundle for the tenant.
- Where the dataset is mounted (read-only). Point `INVERTER_DATASET_PATH` at the Zenodo zip or at `converted_dataset.csv`. It is never part of the image.
- Where run outputs go (`OUTPUT_DIR`, default `/tmp/runs` in the image). Previews contain dataset values; treat them as run data, not source.
- Authentication of the control API (`/replays`, `/config`). It has none of its own and assumes the platform gateway.

Required roles, as far as the code goes: create and read measurements, and read one existing device. The client never creates devices or alarms.

The offline tools (`inverter_replay.validation`, `tools/*`) are not part of the image.
