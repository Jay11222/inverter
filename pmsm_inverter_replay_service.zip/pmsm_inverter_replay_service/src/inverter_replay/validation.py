"""Feature reproducibility report (offline validation only; the replay never calculates or alters a published value).

Recomputes the engineered features with the model repository's reference implementation
(app/feature_engineering.py, imported read-only from its own location, never edited) and reports the
maximum absolute difference against the values stored in converted_dataset.csv.

  python -m inverter_replay.validation --dataset converted_dataset.csv \
      --reference-module /path/PMSMInverter/app/feature_engineering.py \
      [--raw-csv raw_data/dataset_CSV.csv] [--out report.json]

Modes
  processed  Uses only the processed file: Arduino-calibrated currents from the ADC columns Ia, Ib, IDC
             (ref.arduino_acs712_current), VDC, VD, T1..T3 as stored, then the reference's formulas and
             constants (SAMPLE_PERIOD_S, MOVING_AVG_WINDOW).
  raw        Runs ref.compute_features() unchanged on the raw 8-channel ADC stream (raw_data/dataset_CSV.csv).
Requires numpy and pandas (requirements-validation.txt, Python 3.12+). Not part of the service image.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys

ENGINEERED = ("Power_DC", "Power_AC", "Current_Imbalance", "Ia_Normalized", "Ib_Normalized",
              "VDC_RateOfChange", "IDC_RateOfChange", "VDC_MovingAvg", "IDC_MovingAvg", "Temp_Diff_Max")


def load_reference(path: str):
    sys.dont_write_bytecode = True          # never write __pycache__ next to the reference module
    spec = importlib.util.spec_from_file_location("pmsm_reference_feature_engineering", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def engineered_from_processed(ref, df):
    """Engineered features from the processed columns, with the reference calibration and constants."""
    import pandas as pd
    ia_a = ref.arduino_acs712_current(df["Ia"])
    ib_a = ref.arduino_acs712_current(df["Ib"])
    idc_a = ref.arduino_acs712_current(df["IDC"])
    vdc, vd = df["VDC"], df["VD"]
    temps = df[["T1", "T2", "T3"]]
    out = pd.DataFrame(index=df.index)
    out["Power_DC"] = vdc * idc_a
    out["Power_AC"] = vd * (ia_a + ib_a)
    out["Current_Imbalance"] = (ia_a - ib_a).abs() / ((ia_a + ib_a) / 2)
    out["Ia_Normalized"] = ia_a / idc_a
    out["Ib_Normalized"] = ib_a / idc_a
    out["VDC_RateOfChange"] = vdc.diff() / ref.SAMPLE_PERIOD_S
    out["IDC_RateOfChange"] = idc_a.diff() / ref.SAMPLE_PERIOD_S
    out["VDC_MovingAvg"] = vdc.rolling(window=ref.MOVING_AVG_WINDOW).mean()
    out["IDC_MovingAvg"] = idc_a.rolling(window=ref.MOVING_AVG_WINDOW).mean()
    out["Temp_Diff_Max"] = temps.max(axis=1) - temps.min(axis=1)
    return out


def compare(got, stored, names) -> dict:
    import numpy as np
    res = {}
    for f in names:
        a, b = got[f].to_numpy(dtype=float), stored[f].to_numpy(dtype=float)
        fa, fb = np.isfinite(a), np.isfinite(b)
        both = fa & fb
        res[f] = {
            "max_abs_diff": float(np.max(np.abs(a[both] - b[both]))) if both.any() else None,
            "rows_compared": int(both.sum()),
            "bitwise_equal_rows": int(np.sum(a[both] == b[both])),
            "nan_positions_equal": bool(np.array_equal(np.isnan(a), np.isnan(b))),
            "inf_positions_and_signs_equal": bool(np.array_equal(np.isinf(a), np.isinf(b))
                                                  and np.array_equal(np.sign(a[np.isinf(a)]), np.sign(b[np.isinf(b)]))),
        }
    return res


def run(dataset_csv: str, reference_module: str, raw_csv: str | None = None, tolerance: float = 1e-12) -> dict:
    import pandas as pd
    sha = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()
    inputs = [p for p in (dataset_csv, reference_module, raw_csv) if p]
    before = {p: sha(p) for p in inputs}
    ref = load_reference(reference_module)
    df = pd.read_csv(dataset_csv, float_precision="round_trip")     # exact parsing (default parser drifts by 1 ulp)
    report = {"dataset_sha256": before[dataset_csv], "reference_module_sha256": before[reference_module],
              "tolerance": tolerance, "modes": {}}
    report["modes"]["processed"] = compare(engineered_from_processed(ref, df), df, ENGINEERED)
    if raw_csv:
        raw = pd.read_csv(raw_csv, float_precision="round_trip")
        raw.columns = [c.strip() for c in raw.columns]
        got = ref.compute_features(raw[list(ref.RAW_ADC_COLUMNS)])
        report["raw_sha256"] = before[raw_csv]
        report["modes"]["raw"] = compare(got, df, list(ref.FEATURES))
    ok = True
    for mode in report["modes"].values():
        for v in mode.values():
            if v["max_abs_diff"] is None or v["max_abs_diff"] > tolerance or not v["nan_positions_equal"] \
                    or not v["inf_positions_and_signs_equal"]:
                ok = False
    report["reproduced_within_tolerance"] = ok
    after = {p: sha(p) for p in inputs}
    report["inputs_unchanged"] = before == after
    return report


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Feature reproducibility report (offline)")
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--reference-module", required=True)
    ap.add_argument("--raw-csv")
    ap.add_argument("--tolerance", type=float, default=1e-12)
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    r = run(a.dataset, a.reference_module, a.raw_csv, a.tolerance)
    text = json.dumps(r, indent=1)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as fh:
            fh.write(text)
    print(text)
    return 0 if r["reproduced_within_tolerance"] and r["inputs_unchanged"] else 1


if __name__ == "__main__":
    sys.exit(main())
