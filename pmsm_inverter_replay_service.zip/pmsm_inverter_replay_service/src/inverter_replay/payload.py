"""Cumulocity measurement payloads built from the (proposed) mapping.

One dataset row = one observation = one measurement with all its series at one timestamp.
Values are passed through untouched. A non-finite value is never replaced: under the 'omit'
policy that series is left out of that measurement and the omission is recorded.
"""
from __future__ import annotations

import json
import math
from typing import Any, Optional

from .contract import RATIO_UNITS
from .dataset import LABEL_COLUMN, REQUIRED_COLUMNS, SENSOR_FEATURES, TIME_COLUMN
from .models import Observation
from .timeline import ResolvedTime, to_c8y_time

DRY_RUN_DEVICE = "DRY_RUN_NO_DEVICE"
FORBIDDEN_SOURCES = {LABEL_COLUMN, TIME_COLUMN}
FORBIDDEN_NAMES = {"FDD", "fdd", "label", "Timestamp", "partition"}


class MappingError(ValueError):
    pass


def load_mapping(path: str, contract: dict) -> dict:
    with open(path, "r", encoding="utf-8") as fh:
        m = json.load(fh)
    errs = validate_mapping(m, contract)
    if errs:
        raise MappingError("; ".join(errs))
    return m


def validate_mapping(m: dict, contract: dict) -> list[str]:
    errs: list[str] = []
    for k in ("status", "measurement_type", "fragment", "profiles"):
        if not m.get(k):
            errs.append(f"mapping has no {k!r}")
    if errs:
        return errs
    units = {f["name"]: f["unit"] for f in contract["features"]}
    ratio_ok = bool(m.get("ratio_units_approved"))
    profiles = m["profiles"]
    for pname in ("sensor", "sensor_plus_features"):
        if pname not in profiles:
            errs.append(f"mapping has no profile {pname!r}")
    for pname, p in profiles.items():
        series = p.get("series") or {}
        if not series:
            errs.append(f"profile {pname!r} has no series")
        for name, spec in series.items():
            src = spec.get("source_column")
            if name in FORBIDDEN_NAMES or src in FORBIDDEN_SOURCES:
                errs.append(f"profile {pname!r} series {name!r}: FDD and Timestamp are never published")
            if src not in REQUIRED_COLUMNS:
                errs.append(f"profile {pname!r} series {name!r}: unknown source column {src!r}")
            if name in units:
                if src != name:
                    errs.append(f"profile {pname!r} series {name!r}: model feature must come from the column of the same name")
                cu = units[name]
                if cu in RATIO_UNITS:
                    if spec.get("unit") and not ratio_ok:
                        errs.append(f"profile {pname!r} series {name!r}: ratio feature must have no unit unless ratio_units_approved")
                elif spec.get("unit") != cu:
                    errs.append(f"profile {pname!r} series {name!r}: unit {spec.get('unit')!r} differs from contract unit {cu!r}")
    if "sensor_plus_features" in profiles:
        names = list((profiles["sensor_plus_features"].get("series") or {}).keys())
        if sorted(names) != sorted(contract["feature_order"]):
            errs.append("profile 'sensor_plus_features' must publish exactly the 18 model features")
    if "sensor" in profiles:
        names = set((profiles["sensor"].get("series") or {}).keys())
        if not set(SENSOR_FEATURES) <= names:
            errs.append("profile 'sensor' must publish the 8 model sensor values")
        if names & (set(contract["feature_order"]) - set(SENSOR_FEATURES)):
            errs.append("profile 'sensor' must not publish engineered features")
    sp = m.get("selected_profile")
    if sp is not None and sp not in profiles:
        errs.append(f"selected_profile {sp!r} is not a defined profile")
    return errs


def profile_series(mapping: dict, profile: str) -> dict[str, dict]:
    try:
        return mapping["profiles"][profile]["series"]
    except KeyError:
        raise MappingError(f"profile {profile!r} is not defined in the mapping")


def build_measurement(mapping: dict, obs: Observation, rt: ResolvedTime, run_id: str, profile: str,
                      device_id: Optional[str], dataset_sha256: str) -> dict[str, Any]:
    series_spec = profile_series(mapping, profile)
    body: dict[str, Any] = {
        "source": {"id": str(device_id) if device_id else DRY_RUN_DEVICE},
        "time": to_c8y_time(rt.time),
        "type": mapping["measurement_type"],
    }
    series: dict[str, Any] = {}
    for name, spec in series_spec.items():
        if name not in obs.values:      # omitted (non-finite) or absent; never substituted
            continue
        entry: dict[str, Any] = {"value": obs.values[name]}   # original value, untouched
        if spec.get("unit"):
            entry["unit"] = spec["unit"]
        series[name] = entry
    body[mapping["fragment"]] = series

    tf = mapping.get("trace_fragment", {})
    if tf.get("enabled"):
        body[tf["name"]] = {
            "runId": run_id,
            "observationId": obs.observation_id,
            "datasetSha256": dataset_sha256[:16],
            "rowIndex": obs.row,
            "selectionIndex": obs.index,
            "sourceTimestamp": obs.timestamp_text,
            "timeOrigin": rt.origin,
            "profile": profile,
            "omittedSeries": ",".join(f"{n}:{k}" for n, k in obs.omitted),
            "reviewFlags": ",".join(obs.flags),
        }
    # JSON numbers only: refuse NaN/Infinity tokens outright
    json.dumps(body, allow_nan=False)
    for v in series.values():
        if not math.isfinite(v["value"]):
            raise ValueError(f"non-finite value in payload for {obs.observation_id}")
    return body
