"""Replay engine: prepare (validate, resolve timeline, build payloads, preview) then run (dry run or publish).

Structure follows the Battery/Transformer telemetry replay service.
"""
from __future__ import annotations

import json
import logging
import math
import os
import threading
import time
import uuid
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta, timezone
from typing import Callable, Optional, Protocol

from . import c8y_client as c8y
from .config import NONFINITE_POLICIES, PACE_MODES, PROFILES, Settings
from .contract import body_from_measurement, load_contract, validate_predict_body
from .dataset import Dataset, DatasetError, get_dataset
from .models import Observation, Selection
from .payload import build_measurement, load_mapping, profile_series
from .selection import check_bounds, describe, load_manifest
from .timeline import (TimelineError, interval_us, resolve_anchor, resolve_times, spacing_issues, to_c8y_time)

log = logging.getLogger("replay.engine")

MODES = ("dry_run", "publish")


class RunRejected(ValueError):
    """The request cannot become a run. `reasons` lists why."""
    def __init__(self, reasons: list[str]):
        super().__init__("; ".join(reasons))
        self.reasons = reasons


@dataclass
class RunRequest:
    start_row: int
    end_row: int                         # inclusive
    mode: str = "dry_run"
    profile: Optional[str] = None
    timestamp_policy: Optional[str] = None
    anchor_mode: Optional[str] = None
    anchor_time: Optional[str] = None
    source_interval_seconds: Optional[float] = None
    pace_mode: Optional[str] = None
    pace_seconds: Optional[float] = None
    speed_factor: Optional[float] = None
    max_requests_per_second: Optional[float] = None
    limit: Optional[int] = None          # first N observations of the selection; dry run only
    paced: bool = False                  # dry run honours pacing only when asked


class Sink(Protocol):
    def send(self, payload: dict, obs: Observation) -> c8y.SendResult: ...


class DryRunSink:
    def send(self, payload: dict, obs: Observation) -> c8y.SendResult:
        return c8y.SendResult("DRY_RUN", None, 0, "not sent")


class C8ySink:
    def __init__(self, client: c8y.C8yClient, trace_name: Optional[str]):
        self.client, self.trace_name = client, trace_name

    def send(self, payload: dict, obs: Observation) -> c8y.SendResult:
        return self.client.post_measurement(payload, self.trace_name)


@dataclass
class Prepared:
    run_id: str
    request: RunRequest
    settings: Settings
    observations: list[Observation]
    times: list
    payloads: list[dict]
    anchor_resolved: datetime
    mapping: dict
    blockers: list[str]
    summary: dict
    reference_labels: list[dict]


@dataclass
class Run:
    prepared: Prepared
    state: str = "CREATED"
    counters: dict[str, int] = field(default_factory=dict)
    error: Optional[str] = None
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    stop_event: threading.Event = field(default_factory=threading.Event)
    thread: Optional[threading.Thread] = None
    ledger_path: Optional[str] = None
    delivery: dict[str, str] = field(default_factory=dict)

    @property
    def run_id(self) -> str:
        return self.prepared.run_id

    def status(self) -> dict:
        r = self.prepared.request
        return {"run_id": self.run_id, "state": self.state, "mode": r.mode, "profile": r.profile,
                "start_row": r.start_row, "end_row": r.end_row, "total": len(self.prepared.payloads),
                "counters": dict(self.counters), "error": self.error, "started_at": self.started_at,
                "finished_at": self.finished_at, "ledger": self.ledger_path}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class ReplayManager:
    def __init__(self, settings: Settings, client_factory: Optional[Callable[[Settings], c8y.C8yClient]] = None,
                 sleep: Callable[[float], None] = time.sleep, clock: Optional[Callable[[], datetime]] = None):
        self.s = settings
        self._runs: dict[str, Run] = {}
        self._lock = threading.Lock()
        self._client_factory = client_factory or self._default_client
        self._sleep = sleep
        self._clock = clock

    def _default_client(self, s: Settings) -> c8y.C8yClient:
        return c8y.C8yClient(s.c8y_base_url, s.c8y_user, s.c8y_password, s.c8y_tenant,
                             s.http_connect_timeout, s.http_read_timeout, s.http_max_attempts, s.http_backoff_seconds)

    def contract(self) -> dict:
        return load_contract(self.s.contract_path)

    def dataset(self) -> Dataset:
        s = self.s
        return get_dataset(s.dataset_path, self.contract(), test_frac=s.split_test_frac, n_folds=s.split_n_folds,
                           purge_gap=s.split_purge_gap, rolling_window=s.rolling_window)

    # ---------------- prepare ----------------
    def prepare(self, req: RunRequest) -> Prepared:
        s = self.s
        if req.mode not in MODES:
            raise RunRejected([f"mode must be one of {MODES}"])
        profile = req.profile or s.profile
        if profile not in PROFILES:
            raise RunRejected([f"profile must be one of {PROFILES}"])
        if s.nonfinite_policy not in NONFINITE_POLICIES:
            raise RunRejected([f"NONFINITE_POLICY must be one of {NONFINITE_POLICIES}"])
        pol = req.timestamp_policy or s.timestamp_policy
        a_mode = req.anchor_mode or s.anchor_mode
        a_time = req.anchor_time or s.anchor_time
        interval = req.source_interval_seconds if req.source_interval_seconds is not None else s.source_interval_seconds
        p_mode = req.pace_mode or s.pace_mode
        p_sec = req.pace_seconds if req.pace_seconds is not None else s.pace_seconds
        speed = req.speed_factor if req.speed_factor is not None else s.speed_factor
        rps = req.max_requests_per_second if req.max_requests_per_second is not None else s.max_requests_per_second
        if p_mode not in PACE_MODES:
            raise RunRejected([f"pace_mode must be one of {PACE_MODES}"])
        if rps <= 0 or p_sec < 0 or speed <= 0 or interval <= 0:
            raise RunRejected(["pace_seconds must be >= 0; speed_factor, max_requests_per_second and the source interval > 0"])

        contract = self.contract()
        ds = self.dataset()
        sel = Selection(int(req.start_row), int(req.end_row))
        try:
            check_bounds(ds, sel)
        except DatasetError as e:
            raise RunRejected([str(e)])
        manifest = load_manifest(s.selection_manifest)
        approved = manifest["selections"].get(sel.key())

        mapping = load_mapping(s.mapping_path, contract)
        series_spec = profile_series(mapping, profile)

        # ---- the selected rows; refuse rather than truncate
        rows = ds.rows[sel.start_row:sel.end_row + 1]
        partial = False
        if req.limit is not None:
            if req.mode != "dry_run":
                raise RunRejected(["'limit' (partial selection) is only allowed in dry_run mode"])
            if req.limit < 1:
                raise RunRejected(["limit must be >= 1"])
            partial = req.limit < len(rows)
            rows = rows[: req.limit]
        if len(rows) > s.max_observations_per_run:
            raise RunRejected([f"{len(rows)} observations exceeds MAX_OBSERVATIONS_PER_RUN={s.max_observations_per_run}; "
                               "the selection is refused, never truncated. Large runs wait for integration team "
                               "confirmation of tenant limits"])

        warm = max(0, s.rolling_window - 1)
        obs: list[Observation] = []
        omitted_all: list[dict] = []
        for k, r in enumerate(rows):
            values: dict[str, float] = {}
            omitted: list[tuple[str, str]] = []
            for name, spec in series_spec.items():
                v = r.values[spec["source_column"]]
                if math.isfinite(v):
                    values[name] = v                      # exactly as read
                else:
                    kind = "nan" if math.isnan(v) else ("+inf" if v > 0 else "-inf")
                    omitted.append((name, kind))
                    omitted_all.append({"row": r.index, "series": name, "kind": kind})
            obs.append(Observation(
                observation_id=f"pmsm-{ds.sha256[:12]}-r{r.index:05d}", row=r.index, index=k, values=values,
                omitted=tuple(omitted), timestamp_text=r.timestamp_text, offset_us=r.offset_us,
                flags=tuple(r.flags), warmup=k < warm,
                reference={"FDD": r.label, "partition": r.partition, "model_ready": r.model_ready,
                           "null_features": list(r.null_features)}))
        if omitted_all and s.nonfinite_policy == "block":
            raise RunRejected([f"{len(omitted_all)} non-finite value(s) in the published series and NONFINITE_POLICY=block "
                               f"(first at row {omitted_all[0]['row']}, {omitted_all[0]['series']})"])
        flagged = [o for o in obs if o.flags]
        if flagged and s.flagged_rows_policy == "block":
            raise RunRejected([f"{len(flagged)} flagged observation(s) and FLAGGED_ROWS_POLICY=block"])

        # ---- measurement times (source interval only; pacing never touches them)
        anchor = resolve_anchor(a_time, self._clock() if self._clock else None)
        try:
            times = resolve_times([o.offset_us for o in obs], pol, anchor, a_mode, interval)
        except TimelineError as e:
            raise RunRejected([str(e)])
        t_issues = spacing_issues(times, interval)
        if t_issues:
            raise RunRejected(t_issues)

        run_id = uuid.uuid4().hex[:12]
        device = s.c8y_device_id if req.mode == "publish" else None
        payloads = [build_measurement(mapping, o, t, run_id, profile, device, ds.sha256) for o, t in zip(obs, times)]

        blockers = s.publish_blockers(mapping.get("status"), mapping.get("selected_profile"), profile)
        if not approved:
            blockers.append("selection is not in the approved selection manifest (exact row range required)")
        if partial:
            blockers.append("partial selection ('limit') can never be published")
        if s.expected_dataset_sha256 and ds.sha256 != s.expected_dataset_sha256:
            blockers.append("dataset SHA-256 differs from EXPECTED_DATASET_SHA256 (not the verified training copy)")
        if req.mode == "publish" and blockers:
            raise RunRejected(["publish blocked: " + b for b in blockers])

        reference_labels = [{"observation_id": o.observation_id, "row": o.row, **o.reference} for o in obs]
        summary = self._summarize(ds, sel, contract, mapping, profile, obs, times, payloads, omitted_all, flagged, anchor,
                                  a_mode, pol, interval, p_mode, p_sec, speed, rps, partial, approved, manifest, blockers)
        req2 = replace(req, profile=profile, timestamp_policy=pol, anchor_mode=a_mode, anchor_time=a_time,
                       source_interval_seconds=interval, pace_mode=p_mode, pace_seconds=p_sec, speed_factor=speed,
                       max_requests_per_second=rps)
        return Prepared(run_id, req2, s, obs, times, payloads, anchor, mapping, blockers, summary, reference_labels)

    def _summarize(self, ds, sel, contract, mapping, profile, obs, times, payloads, omitted_all, flagged, anchor, a_mode,
                   pol, interval, p_mode, p_sec, speed, rps, partial, approved, manifest, blockers) -> dict:
        n = len(obs)
        deltas_us = sorted({(times[i].time - times[i - 1].time) // timedelta(microseconds=1) for i in range(1, n)})
        gap = max(p_sec, 1.0 / rps)
        if p_mode == "asap":
            est = n / rps
        elif p_mode == "timeline_scaled":
            est = sum(max((times[i].time - times[i - 1].time).total_seconds() / speed, 1.0 / rps) for i in range(1, n))
        else:
            est = max(0, n - 1) * gap
        realtime_rps = 1.0 / interval
        flag_counts: dict[str, int] = {}
        for o in obs:
            for f in o.flags:
                key = f.split(":")[0]
                flag_counts[key] = flag_counts.get(key, 0) + 1
        not_ready = [o.row for o in obs if not o.reference["model_ready"]]
        with_null = [{"row": o.row, "null_features": o.reference["null_features"]} for o in obs if o.reference["null_features"]]

        # contract checks: every observation (sensor_plus_features) must form a valid /predict body
        fragment = mapping["fragment"]
        contract_check = {"status": contract.get("status"), "applies": profile == "sensor_plus_features"}
        samples = []
        pick = self._sample_indexes(obs, self.s.sample_predict_bodies)
        if profile == "sensor_plus_features":
            invalid = []
            for o, p in zip(obs, payloads):
                errs = validate_predict_body(contract, body_from_measurement(contract, p[fragment]))
                if errs:
                    invalid.append({"row": o.row, "errors": errs[:3]})
            contract_check.update({"valid_bodies": n - len(invalid), "invalid_bodies": len(invalid),
                                   "invalid_examples": invalid[:10]})
            for i in pick:
                body = body_from_measurement(contract, payloads[i][fragment])
                samples.append({"observation_id": obs[i].observation_id, "row": obs[i].row,
                                "reference_label": obs[i].reference["FDD"], "partition": obs[i].reference["partition"],
                                "predict_body": body, "valid": not validate_predict_body(contract, body),
                                "null_features": [k for k, v in body.items() if v is None]})
        else:
            contract_check["note"] = ("sensor profile: the 10 engineered features are calculated upstream. Sample rows below "
                                      "show the dataset's stored 18 features as the expected /predict body for comparison.")
            row_by_index = {r.index: r for r in ds.rows}
            for i in pick:
                r = row_by_index[obs[i].row]
                body = {f: (r.values[f] if math.isfinite(r.values[f]) else None) for f in contract["feature_order"]}
                samples.append({"observation_id": obs[i].observation_id, "row": obs[i].row,
                                "reference_label": obs[i].reference["FDD"], "partition": obs[i].reference["partition"],
                                "published_series": payloads[i][fragment],
                                "expected_predict_body_from_dataset": body,
                                "expected_body_valid": not validate_predict_body(contract, body),
                                "warmup_row": obs[i].warmup})
        return {
            "service": "pmsm_inverter_replay",
            "dataset": {"source": os.path.basename(ds.source), "sha256": ds.sha256, "archive_sha256": ds.archive_sha256,
                        "matches_verified_training_copy": ds.sha256 == self.s.expected_dataset_sha256,
                        "parse_mode": "exact (float of the file text)"},
            "selection": {**describe(ds, sel, max(0, self.s.rolling_window - 1)), "partial": partial,
                          "observations": n, "approved": bool(approved),
                          "approved_entry": approved, "manifest_configured": manifest["configured"]},
            "profile": profile, "series": list(profile_series(mapping, profile)),
            "mapping_status": mapping.get("status"), "mapping_selected_profile": mapping.get("selected_profile"),
            "timeline": {"policy": pol, "time_origin": times[0].origin if times else None, "anchor_mode": a_mode,
                         "anchor_resolved_utc": to_c8y_time(anchor), "timezone": "UTC",
                         "source_interval_seconds": interval,
                         "first": to_c8y_time(times[0].time) if times else None,
                         "last": to_c8y_time(times[-1].time) if times else None,
                         "spacing_us_values": deltas_us,
                         "spacing_equals_source_interval": deltas_us in ([], [interval_us(interval)]),
                         "future_timestamps": bool(times and times[-1].time > datetime.now(timezone.utc)),
                         "note": "measurement times come from the source index; send time never replaces them"},
            "pacing": {"mode": p_mode, "pace_seconds": p_sec, "speed_factor": speed, "max_requests_per_second": rps,
                       "estimated_duration_seconds": round(est, 1),
                       "realtime_requests_per_second": realtime_rps,
                       "note": (f"real time would be {realtime_rps:g} requests per second and needs integration team "
                                "confirmation; pacing never changes measurement times")},
            "non_finite": {"policy": self.s.nonfinite_policy, "omitted_count": len(omitted_all),
                           "omitted": omitted_all[:200], "substitution": "none (never zero, median or previous value)"},
            "model_readiness": {"model_ready": n - len(not_ready), "not_model_ready_rows": not_ready,
                                "rows_needing_null": with_null,
                                "rule": "only Current_Imbalance, Ia_Normalized, Ib_Normalized may be null"},
            "flags": {"policy": self.s.flagged_rows_policy, "observations_flagged": len(flagged), "counts": flag_counts,
                      "examples": [{"observation_id": o.observation_id, "row": o.row, "flags": list(o.flags)} for o in flagged[:10]],
                      "note": "flags are for review only; values are published unchanged"},
            "contract_check": contract_check,
            "sample_predict_bodies": samples,
            "reference_labels_note": "FDD is a reference label: kept here and in the run report, never in a payload",
            "publish_blockers": blockers,
            "payload_preview": {"first": payloads[0] if payloads else None, "last": payloads[-1] if payloads else None},
        }

    @staticmethod
    def _sample_indexes(obs: list[Observation], k: int) -> list[int]:
        if not obs or k <= 0:
            return []
        picks: list[int] = []
        def add(i):
            if i is not None and i not in picks and len(picks) < k:
                picks.append(i)
        add(next((i for i, o in enumerate(obs) if o.reference["model_ready"] and not o.warmup), 0))
        add(next((i for i, o in enumerate(obs) if o.reference["null_features"]), None))
        seen = set()
        for i, o in enumerate(obs):                     # one per class in the selection
            if o.reference["FDD"] not in seen and o.reference["model_ready"]:
                seen.add(o.reference["FDD"]); add(i)
        add(len(obs) - 1)
        return sorted(picks)

    # ---------------- run lifecycle ----------------
    def create(self, req: RunRequest) -> Run:
        prep = self.prepare(req)
        with self._lock:
            active = [r for r in self._runs.values() if r.state in ("CREATED", "RUNNING")]
            if len(active) >= self.s.max_concurrent_runs:
                raise RunRejected([f"MAX_CONCURRENT_RUNS={self.s.max_concurrent_runs} reached"])
            run = Run(prep, counters={})
            self._runs[run.run_id] = run
        self._write_preview(run)
        run.thread = threading.Thread(target=self._execute, args=(run,), name=f"run-{run.run_id}", daemon=True)
        run.state = "RUNNING"
        run.started_at = _now_iso()
        run.thread.start()
        return run

    def runs(self) -> list[Run]:
        return list(self._runs.values())

    def get(self, run_id: str) -> Optional[Run]:
        return self._runs.get(run_id)

    def stop(self, run_id: str) -> Optional[Run]:
        r = self._runs.get(run_id)
        if r:
            r.stop_event.set()
        return r

    def _run_dir(self, run: Run) -> str:
        d = os.path.join(self.s.output_dir, run.run_id)
        os.makedirs(d, exist_ok=True)
        return d

    def _write_preview(self, run: Run) -> None:
        d = self._run_dir(run)
        p = run.prepared
        with open(os.path.join(d, "preview.json"), "w", encoding="utf-8") as fh:
            json.dump({"summary": p.summary, "reference_labels": p.reference_labels, "payloads": p.payloads},
                      fh, indent=1, default=str, allow_nan=False)
        run.ledger_path = os.path.join(d, "ledger.jsonl")

    def _write_report(self, run: Run) -> None:
        p = run.prepared
        report = {"run": run.status(), "dataset_sha256": p.summary["dataset"]["sha256"],
                  "selection": {k: p.summary["selection"][k] for k in ("start_row", "end_row", "kind", "class_composition",
                                                                        "partition_composition", "approved")},
                  "profile": p.request.profile,
                  "reference_labels": [{**x, "delivery": run.delivery.get(x["observation_id"], "NOT_SENT")}
                                       for x in p.reference_labels]}
        with open(os.path.join(self._run_dir(run), "report.json"), "w", encoding="utf-8") as fh:
            json.dump(report, fh, indent=1, default=str, allow_nan=False)

    def _delay_before(self, prep: Prepared, i: int) -> float:
        if i == 0:
            return 0.0
        r = prep.request
        min_gap = 1.0 / r.max_requests_per_second
        if r.pace_mode == "asap":
            return min_gap
        if r.pace_mode == "timeline_scaled":
            d = (prep.times[i].time - prep.times[i - 1].time).total_seconds() / r.speed_factor
            return max(d, min_gap)
        return max(r.pace_seconds, min_gap)

    def _execute(self, run: Run) -> None:
        prep = run.prepared
        req = prep.request
        counters = run.counters
        try:
            if req.mode == "publish":
                client = self._client_factory(self.s)
                ok, detail = client.check_device(self.s.c8y_device_id)
                if not ok:
                    run.state, run.error = "FAILED", f"preflight: {detail}"
                    return
                tf = prep.mapping.get("trace_fragment", {})
                sink: Sink = C8ySink(client, tf.get("name") if tf.get("enabled") else None)
            else:
                sink = DryRunSink()
            honour_pacing = req.mode == "publish" or req.paced
            with open(run.ledger_path, "a", encoding="utf-8") as ledger:
                for i, payload in enumerate(prep.payloads):
                    if run.stop_event.is_set():
                        run.state = "STOPPED"; return
                    if honour_pacing:
                        d = self._delay_before(prep, i)
                        if d and run.stop_event.wait(d):
                            run.state = "STOPPED"; return
                    obs = prep.observations[i]
                    res = sink.send(payload, obs)
                    counters[res.status] = counters.get(res.status, 0) + 1
                    run.delivery[obs.observation_id] = res.status
                    ledger.write(json.dumps({"ts": _now_iso(), "run_id": run.run_id, "observation_id": obs.observation_id,
                                             "row": obs.row, "time": payload["time"], "status": res.status,
                                             "http_status": res.http_status, "attempts": res.attempts,
                                             "detail": res.detail}) + "\n")
                    ledger.flush()
                    if res.status in (c8y.REJECTED, c8y.FAILED):
                        run.state, run.error = "FAILED", f"{res.status} at {obs.observation_id}: {res.detail}"; return
                    if res.status == c8y.UNCONFIRMED and self.s.on_unconfirmed == "halt":
                        run.state, run.error = "HALTED_UNCONFIRMED", f"delivery of {obs.observation_id} could not be confirmed"; return
            run.state = "COMPLETED"
        except Exception as e:  # keep the service alive; record the failure
            run.state, run.error = "FAILED", f"{type(e).__name__}: {e}"
            log.exception("run failed", extra={"ctx": {"run_id": run.run_id}})
        finally:
            run.finished_at = _now_iso()
            try:
                self._write_report(run)
            except Exception:
                log.exception("report write failed", extra={"ctx": {"run_id": run.run_id}})
            log.info("run finished", extra={"ctx": {"run_id": run.run_id, "state": run.state, "counters": counters}})
