"""Read-only dataset inventory. Records the SHA-256 of every input before and after; aggregates only, no rows.

  python -m inverter_replay.inventory --dataset /data/PMSM-inverter-fault-diagnosis-3.0.zip \
      [--model-repo /path/PMSMInverter] [--contract config/model_contract.json] [--out inventory.json]

--dataset may be the Zenodo zip, the extracted folder, or converted_dataset.csv itself.
--model-repo hashes the repository files this project reads (they are never modified).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import zipfile
from collections import Counter
from typing import Optional

from .contract import load_contract
from .dataset import ADC_COLUMNS, LABEL_COLUMN, load_dataset

REPO_FILES = ("artifacts/feature_schema.json", "artifacts/model_metadata.json", "app/schemas.py",
              "app/feature_engineering.py", "samples/expected_predictions.json", "processed_data/converted_dataset.csv",
              "training/export_artifacts.py")


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def hash_inputs(dataset: str, model_repo: Optional[str]) -> dict:
    out: dict = {}
    if os.path.isfile(dataset) and dataset.lower().endswith(".zip"):
        out[os.path.basename(dataset)] = sha256_file(dataset)
        with zipfile.ZipFile(dataset, "r") as z:
            for i in z.infolist():
                if not i.is_dir():
                    out[f"{os.path.basename(dataset)}::{i.filename}"] = sha256_bytes(z.read(i.filename))
    elif os.path.isdir(dataset):
        for root, _, files in os.walk(dataset):
            for f in files:
                p = os.path.join(root, f)
                out[os.path.relpath(p, os.path.dirname(dataset.rstrip("/")))] = sha256_file(p)
    else:
        out[os.path.basename(dataset)] = sha256_file(dataset)
    if model_repo:
        for rel in REPO_FILES:
            p = os.path.join(model_repo, rel)
            if os.path.isfile(p):
                out[f"model_repo::{rel}"] = sha256_file(p)
    return dict(sorted(out.items()))


def _csv_path(dataset: str) -> str:
    if os.path.isdir(dataset):
        for root, _, files in os.walk(dataset):
            if "converted_dataset.csv" in files and root.replace("\\", "/").endswith("processed_data"):
                return os.path.join(root, "converted_dataset.csv")
        raise FileNotFoundError("processed_data/converted_dataset.csv not found under the dataset folder")
    return dataset


def inventory(dataset: str, contract: dict) -> dict:
    ds = load_dataset(_csv_path(dataset), contract)
    cols = [c for c in ds.columns if c != LABEL_COLUMN]
    nonfinite = {}
    for c in cols:
        nan = sum(1 for r in ds.rows if math.isnan(r.values[c]))
        inf = sum(1 for r in ds.rows if math.isinf(r.values[c]))
        if nan or inf:
            nonfinite[c] = {"nan": nan, "inf": inf}
    adc = {}
    for c in ADC_COLUMNS:
        v = [r.values[c] for r in ds.rows]
        adc[c] = {"min": min(v), "max": max(v), "all_integer": all(x == int(x) for x in v),
                  "within_0_1023": min(v) >= 0 and max(v) <= 1023}
    offs = [r.offset_us for r in ds.rows]
    flags = Counter(f.split(":")[0] for r in ds.rows for f in r.flags)
    part = Counter(r.partition for r in ds.rows)
    s = ds.summary()
    return {
        "csv_sha256": ds.sha256, "rows": len(ds.rows), "columns": ds.columns,
        "class_blocks": s["class_blocks"],
        "timestamp": {"first_text": ds.rows[0].timestamp_text, "last_text": ds.rows[-1].timestamp_text,
                      "spacing_us": sorted({offs[i] - offs[i - 1] for i in range(1, len(offs))}),
                      "equals_row_index_x_0.1": all(o == i * 100_000 for i, o in enumerate(offs))},
        "adc_columns": adc, "non_finite_by_column": nonfinite,
        "rows_with_nan_or_inf_in_model_features": sum(1 for r in ds.rows if any(f.startswith("non_finite:") for f in r.flags)),
        "model_ready_rows": s["model_ready_rows"], "not_model_ready_rows": len(s["not_model_ready_rows"]),
        "rows_needing_null": sum(1 for r in ds.rows if r.null_features),
        "boundary_crossing_rows": s["boundary_crossing_rows"],
        "flag_counts": dict(flags), "partition_sizes": dict(part), "partition_note": ds.partition_note,
        "text_roundtrip_mismatches": ds.text_roundtrip_mismatches,
    }


def run(dataset: str, contract_path: str, model_repo: Optional[str] = None) -> dict:
    before = hash_inputs(dataset, model_repo)
    res: dict = {"inputs_sha256_before": before}
    res["inverter"] = inventory(dataset, load_contract(contract_path))
    after = hash_inputs(dataset, model_repo)
    res["inputs_sha256_after"] = after
    res["originals_unchanged"] = before == after
    return res


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Read-only inverter dataset inventory")
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--model-repo")
    ap.add_argument("--contract", default="config/model_contract.json")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    r = run(a.dataset, a.contract, a.model_repo)
    text = json.dumps(r, indent=1, allow_nan=False)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as fh:
            fh.write(text)
    print(text)
    return 0 if r["originals_unchanged"] else 1


if __name__ == "__main__":
    sys.exit(main())
