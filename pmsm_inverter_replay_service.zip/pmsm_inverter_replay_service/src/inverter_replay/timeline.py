"""Measurement-time policies for a dataset that only has a relative time index.

shifted        anchor + (Timestamp - Timestamp of the anchor row). The 0.1 s spacing of the source is
               kept exactly (integer microseconds from the Timestamp text, no float accumulation).
reconstructed  anchor + i * configured interval, always labelled 'reconstructed'.

Generated times are UTC. "now" is resolved once per run. Measurement time is never replaced by send
time, and the send cadence never changes these times.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional

from .config import ANCHOR_MODES, TIMESTAMP_POLICIES


class TimelineError(ValueError):
    pass


@dataclass(frozen=True)
class ResolvedTime:
    time: datetime
    origin: str  # shifted | reconstructed


def parse_utc(text: str) -> datetime:
    t = text.strip()
    if t.endswith("Z"):
        t = t[:-1] + "+00:00"
    dt = datetime.fromisoformat(t)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def resolve_anchor(anchor_time: str, now: Optional[datetime] = None) -> datetime:
    if anchor_time.strip().lower() == "now":
        return (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    return parse_utc(anchor_time)


def interval_us(seconds: float) -> int:
    us = round(seconds * 1_000_000)
    if us <= 0:
        raise TimelineError("the source interval must be positive")
    return us


def resolve_times(offsets_us: list[int], policy: str, anchor: datetime, anchor_mode: str = "start",
                  source_interval_seconds: float = 0.1) -> list[ResolvedTime]:
    if policy not in TIMESTAMP_POLICIES:
        raise TimelineError(f"unknown timestamp policy {policy!r}; expected one of {TIMESTAMP_POLICIES}")
    if anchor_mode not in ANCHOR_MODES:
        raise TimelineError(f"unknown anchor mode {anchor_mode!r}; expected one of {ANCHOR_MODES}")
    n = len(offsets_us)
    if n == 0:
        return []
    if policy == "reconstructed":
        step = interval_us(source_interval_seconds)
        first = anchor if anchor_mode == "start" else anchor - timedelta(microseconds=step * (n - 1))
        return [ResolvedTime(first + timedelta(microseconds=step * i), "reconstructed") for i in range(n)]
    ref = offsets_us[0] if anchor_mode == "start" else offsets_us[-1]
    return [ResolvedTime(anchor + timedelta(microseconds=o - ref), "shifted") for o in offsets_us]


def spacing_issues(times: list[ResolvedTime], expected_seconds: float) -> list[str]:
    """Every consecutive pair must be exactly the expected interval apart, also at millisecond precision."""
    step = interval_us(expected_seconds)
    issues = []
    for i in range(1, len(times)):
        d = times[i].time - times[i - 1].time
        if d != timedelta(microseconds=step):
            issues.append(f"spacing at selection index {i} is {d.total_seconds()} s, expected {expected_seconds} s")
        elif to_c8y_time(times[i].time) == to_c8y_time(times[i - 1].time):
            issues.append(f"duplicate timestamp at millisecond precision at selection index {i}")
        if len(issues) >= 10:
            break
    return issues


def to_c8y_time(dt: datetime) -> str:
    """ISO-8601 UTC with millisecond precision."""
    dt = dt.astimezone(timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"
