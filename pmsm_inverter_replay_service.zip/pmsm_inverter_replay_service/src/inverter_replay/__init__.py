"""PMSM inverter telemetry replay service (publishes recorded dataset rows as Cumulocity measurements)."""
__version__ = "0.1.0"
