"""Selections: contiguous row ranges of converted_dataset.csv, and the approved-selection manifest.

Manifest file (read-only), approved by the person the Data Science team and Mudhawi name:
  {"approved_by": "<name>", "selections": [{"id": "f4_block", "start_row": 6516, "end_row": 6856, "note": "..."}]}
Publishing requires the requested range to match one approved entry exactly (complete, not partial).
"""
from __future__ import annotations

import json
from typing import Optional

from .dataset import Dataset, DatasetError
from .models import Selection

SPLICE_NOTE = ("Class boundaries in converted_dataset.csv join separate recordings made minutes apart and not in "
               "F0..F8 order (docs/INSPECTION_REPORT.md section 11). A window across a boundary tests a label change "
               "in the stream, not a recorded physical fault onset.")


def load_manifest(path: Optional[str]) -> dict:
    if not path:
        return {"configured": False, "approved_by": None, "selections": {}}
    with open(path, "r", encoding="utf-8") as fh:
        raw = json.load(fh)
    sel = {}
    for e in raw.get("selections", []):
        s, t = int(e["start_row"]), int(e["end_row"])
        sel[(s, t)] = {"id": e.get("id"), "note": e.get("note")}
    return {"configured": True, "approved_by": raw.get("approved_by"), "selections": sel}


def check_bounds(ds: Dataset, sel: Selection) -> None:
    n = len(ds.rows)
    if sel.start_row < 0 or sel.end_row < sel.start_row or sel.end_row >= n:
        raise DatasetError(f"selection {sel.start_row}..{sel.end_row} is not a valid range inside 0..{n - 1}")


def describe(ds: Dataset, sel: Selection, warmup_rows: int) -> dict:
    """Class composition, selection kind, transitions, boundary-crossing and warm-up rows, partitions."""
    rows = ds.rows[sel.start_row:sel.end_row + 1]
    comp: dict[str, int] = {}
    for r in rows:
        comp[r.label] = comp.get(r.label, 0) + 1
    labels = list(comp)
    transitions = [{"after_row": rows[i - 1].index, "from": rows[i - 1].label, "to": rows[i].label}
                   for i in range(1, len(rows)) if rows[i].label != rows[i - 1].label]
    if len(labels) == 1:
        b = ds.block_of(sel.start_row)
        kind = "full_class_block" if (b.start, b.end) == sel.key() else "window_in_class_block"
    else:
        kind = "across_class_transition"
    part: dict[str, int] = {}
    for r in rows:
        part[r.partition] = part.get(r.partition, 0) + 1
    non_test = sum(v for k, v in part.items() if k != "held_out_test")
    warnings = []
    if non_test:
        warnings.append(f"{non_test} of {len(rows)} rows are not in the held-out test partition. Replaying rows the model "
                        "was trained, tuned or validated on overstates model accuracy.")
    if not ds.partition_reproduced:
        warnings.append("training/test partition could not be reproduced: " + ds.partition_note)
    if kind == "across_class_transition":
        warnings.append(SPLICE_NOTE)
    return {
        "start_row": sel.start_row, "end_row": sel.end_row, "rows": sel.rows, "kind": kind,
        "class_composition": comp, "transitions": transitions,
        "boundary_crossing_rows": [r.index for r in rows if r.boundary_crossing],
        "boundary_note": "stored rolling features of these rows mix the previous class (computed across the whole file)",
        "warmup_rows": [r.index for r in rows[:warmup_rows]],
        "warmup_note": (f"first {warmup_rows} rows of the selection: an upstream pipeline that starts with this selection has "
                        "no history for the moving averages (and the first row none for rates of change)"),
        "partition_composition": part, "partition_note": ds.partition_note, "warnings": warnings,
    }
