"""Settings loaded from environment variables only.

Design rules (same as the Battery/Transformer replay service):
  * No credential, token, tenant URL or device ID has a default value.
  * Publishing is OFF unless every gate in `publish_blockers` is satisfied.
  * Secrets are excluded from repr/str so they cannot leak into logs.
  * The source sampling interval (where measurement times are placed) and the send cadence
    (how fast observations are posted) are separate settings. Neither is derived from the other.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field, fields
from typing import Optional

# SHA-256 of processed_data/converted_dataset.csv in Zenodo record 14482932, verified to be
# byte-identical to the training copy (PMSMInverter repo, model_metadata.json). Not a secret.
VERIFIED_DATASET_SHA256 = "134d1e0abbcdbabcaf2fc7c02f95b4bf8d90bb8c3d1b7f97f66b7c807318288f"

PROFILES = ("sensor", "sensor_plus_features")
NONFINITE_POLICIES = ("omit", "block")
TIMESTAMP_POLICIES = ("shifted", "reconstructed")
ANCHOR_MODES = ("start", "end")
PACE_MODES = ("fixed_interval", "timeline_scaled", "asap")


def _env(name: str, default: Optional[str] = None) -> Optional[str]:
    v = os.environ.get(name)
    if v is None or v.strip() == "":
        return default
    return v.strip()


def _bool(name: str, default: bool = False) -> bool:
    v = _env(name)
    if v is None:
        return default
    return v.lower() in ("1", "true", "yes", "on")


def _float(name: str, default: float) -> float:
    v = _env(name)
    return default if v is None else float(v)


def _int(name: str, default: int) -> int:
    v = _env(name)
    return default if v is None else int(v)


@dataclass(frozen=True)
class Settings:
    # ---- Data (read-only input, mounted at runtime, never baked into the image)
    dataset_path: Optional[str] = None             # converted_dataset.csv, or the Zenodo .zip that contains it
    expected_dataset_sha256: str = VERIFIED_DATASET_SHA256
    selection_manifest: Optional[str] = None       # approved row ranges (JSON)
    output_dir: str = "runs"                       # previews, ledgers, run reports
    mapping_path: str = "config/mapping.proposed.json"
    contract_path: str = "config/model_contract.json"

    # ---- Telemetry
    profile: str = "sensor"                        # dry-run default; publish must match the approved mapping
    nonfinite_policy: str = "omit"                 # omit (record the omission) | block (refuse the run)
    flagged_rows_policy: str = "include"           # include | block

    # ---- Timestamps (placement of measurement times)
    timestamp_policy: str = "shifted"              # shifted | reconstructed
    anchor_mode: str = "start"                     # start | end
    anchor_time: str = "now"                       # ISO-8601 UTC or "now" (resolved once per run)
    source_interval_seconds: float = 0.1           # 10 Hz; spacing between measurement times

    # ---- Send cadence (never derived from the source interval)
    pace_mode: str = "fixed_interval"              # fixed_interval | timeline_scaled | asap
    pace_seconds: float = 1.0
    speed_factor: float = 1.0
    max_requests_per_second: float = 1.0
    max_observations_per_run: int = 1000
    max_concurrent_runs: int = 1

    # ---- Reproduction of the training notebook split (for preview labels only)
    split_test_frac: float = 0.20
    split_n_folds: int = 3
    split_purge_gap: int = 10
    rolling_window: int = 10                       # moving-average window of the upstream features
    sample_predict_bodies: int = 5

    # ---- Cumulocity target. No defaults.
    c8y_base_url: Optional[str] = None
    c8y_tenant: Optional[str] = None
    c8y_user: Optional[str] = field(default=None, repr=False)
    c8y_password: Optional[str] = field(default=None, repr=False)
    c8y_device_id: Optional[str] = None

    # ---- Publish gates (all must be explicitly set)
    publish_enabled: bool = False
    target_approved: bool = False

    # ---- HTTP client behaviour
    http_connect_timeout: float = 5.0
    http_read_timeout: float = 15.0
    http_max_attempts: int = 3
    http_backoff_seconds: float = 1.0
    on_unconfirmed: str = "halt"                   # halt | continue

    port: int = 8080
    log_level: str = "INFO"

    def __repr__(self) -> str:  # never print secrets
        parts = []
        for f in fields(self):
            v = getattr(self, f.name)
            if f.name in ("c8y_user", "c8y_password"):
                v = "<set>" if v else None
            parts.append(f"{f.name}={v!r}")
        return "Settings(" + ", ".join(parts) + ")"

    __str__ = __repr__

    def public_view(self) -> dict:
        """Non-secret settings for /config. Credentials are reported only as set / not set."""
        out = {}
        for f in fields(self):
            if f.name in ("c8y_user", "c8y_password"):
                continue
            out[f.name] = getattr(self, f.name)
        out["credentials_configured"] = bool(self.c8y_user and self.c8y_password)
        return out

    def publish_blockers(self, mapping_status: Optional[str], mapping_profile: Optional[str],
                         run_profile: Optional[str]) -> list[str]:
        """Reasons publishing is not allowed. Empty list means the configuration gates pass.

        The engine adds the run-specific gates (approved selection, complete selection, dataset hash).
        """
        b: list[str] = []
        if not self.publish_enabled:
            b.append("PUBLISH_ENABLED is not true")
        if not self.target_approved:
            b.append("TARGET_APPROVED is not true (designated dev/test tenant not confirmed)")
        if (mapping_status or "").upper() != "APPROVED":
            b.append(f"mapping status is {mapping_status!r}, not APPROVED")
        if not mapping_profile:
            b.append("the mapping does not select a telemetry profile (selected_profile is empty)")
        elif run_profile and run_profile != mapping_profile:
            b.append(f"profile {run_profile!r} differs from the approved mapping profile {mapping_profile!r}")
        if not self.c8y_base_url:
            b.append("C8Y_BASEURL is not set")
        if not (self.c8y_user and self.c8y_password):
            b.append("C8Y_USER / C8Y_PASSWORD are not set")
        if not self.c8y_device_id:
            b.append("C8Y_DEVICE_ID (approved existing device) is not set")
        if not self.selection_manifest:
            b.append("SELECTION_MANIFEST (approved row ranges) is not configured")
        return b


def load_settings() -> Settings:
    return Settings(
        dataset_path=_env("INVERTER_DATASET_PATH"),
        expected_dataset_sha256=_env("EXPECTED_DATASET_SHA256", VERIFIED_DATASET_SHA256),
        selection_manifest=_env("SELECTION_MANIFEST"),
        output_dir=_env("OUTPUT_DIR", "runs"),
        mapping_path=_env("MAPPING_PATH", "config/mapping.proposed.json"),
        contract_path=_env("MODEL_CONTRACT_PATH", "config/model_contract.json"),
        profile=_env("TELEMETRY_PROFILE", "sensor"),
        nonfinite_policy=_env("NONFINITE_POLICY", "omit"),
        flagged_rows_policy=_env("FLAGGED_ROWS_POLICY", "include"),
        timestamp_policy=_env("TIMESTAMP_POLICY", "shifted"),
        anchor_mode=_env("ANCHOR_MODE", "start"),
        anchor_time=_env("ANCHOR_TIME", "now"),
        source_interval_seconds=_float("SOURCE_INTERVAL_SECONDS", 0.1),
        pace_mode=_env("PACE_MODE", "fixed_interval"),
        pace_seconds=_float("PACE_SECONDS", 1.0),
        speed_factor=_float("SPEED_FACTOR", 1.0),
        max_requests_per_second=_float("MAX_REQUESTS_PER_SECOND", 1.0),
        max_observations_per_run=_int("MAX_OBSERVATIONS_PER_RUN", 1000),
        max_concurrent_runs=_int("MAX_CONCURRENT_RUNS", 1),
        split_test_frac=_float("SPLIT_TEST_FRAC", 0.20),
        split_n_folds=_int("SPLIT_N_FOLDS", 3),
        split_purge_gap=_int("SPLIT_PURGE_GAP", 10),
        rolling_window=_int("ROLLING_WINDOW", 10),
        sample_predict_bodies=_int("SAMPLE_PREDICT_BODIES", 5),
        c8y_base_url=_env("C8Y_BASEURL"),
        c8y_tenant=_env("C8Y_TENANT"),
        c8y_user=_env("C8Y_USER"),
        c8y_password=_env("C8Y_PASSWORD"),
        c8y_device_id=_env("C8Y_DEVICE_ID"),
        publish_enabled=_bool("PUBLISH_ENABLED", False),
        target_approved=_bool("TARGET_APPROVED", False),
        http_connect_timeout=_float("HTTP_CONNECT_TIMEOUT", 5.0),
        http_read_timeout=_float("HTTP_READ_TIMEOUT", 15.0),
        http_max_attempts=_int("HTTP_MAX_ATTEMPTS", 3),
        http_backoff_seconds=_float("HTTP_BACKOFF_SECONDS", 1.0),
        on_unconfirmed=_env("ON_UNCONFIRMED", "halt"),
        port=_int("PORT", 8080),
        log_level=_env("LOG_LEVEL", "INFO"),
    )
