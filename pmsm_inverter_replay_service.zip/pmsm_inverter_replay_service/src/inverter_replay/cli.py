"""Offline helper. Never publishes.

  python -m inverter_replay.cli preview --start-row 6516 --end-row 6856 [--profile sensor_plus_features] [--out p.json]
  python -m inverter_replay.cli dataset                      # class blocks, partitions, readiness (no rows)
  python -m inverter_replay.cli contract-check --openapi openapi.json
Reads data paths and settings from the same environment variables as the service.
"""
from __future__ import annotations

import argparse
import json
import sys

from .config import load_settings
from .contract import compare_with_openapi, load_contract
from .engine import ReplayManager, RunRejected, RunRequest


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="inverter_replay.cli")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("preview", help="dry-run preview (never publishes)")
    p.add_argument("--start-row", type=int, required=True)
    p.add_argument("--end-row", type=int, required=True)
    p.add_argument("--profile", choices=["sensor", "sensor_plus_features"])
    p.add_argument("--policy", choices=["shifted", "reconstructed"])
    p.add_argument("--anchor-mode", choices=["start", "end"])
    p.add_argument("--anchor-time")
    p.add_argument("--limit", type=int)
    p.add_argument("--out")
    sub.add_parser("dataset", help="dataset summary (aggregates only)")
    c = sub.add_parser("contract-check", help="compare the contract with a deployed /openapi.json")
    c.add_argument("--openapi", required=True)
    a = ap.parse_args(argv)
    s = load_settings()
    mgr = ReplayManager(s)
    if a.cmd == "dataset":
        print(json.dumps(mgr.dataset().summary(), indent=1)); return 0
    if a.cmd == "contract-check":
        with open(a.openapi, "r", encoding="utf-8") as fh:
            res = compare_with_openapi(load_contract(s.contract_path), json.load(fh))
        print(json.dumps(res, indent=1)); return 0 if res["match"] else 1
    try:
        prep = mgr.prepare(RunRequest(a.start_row, a.end_row, mode="dry_run", profile=a.profile, timestamp_policy=a.policy,
                                      anchor_mode=a.anchor_mode, anchor_time=a.anchor_time, limit=a.limit))
    except RunRejected as e:
        print(json.dumps({"rejected": e.reasons}, indent=2)); return 2
    doc = {"summary": prep.summary, "reference_labels": prep.reference_labels, "payloads": prep.payloads}
    text = json.dumps(doc, indent=1, default=str, allow_nan=False)
    if a.out:
        with open(a.out, "w", encoding="utf-8") as fh:
            fh.write(text)
        print(json.dumps({k: prep.summary[k] for k in ("selection", "profile", "timeline", "pacing", "publish_blockers")},
                         indent=1, default=str))
    else:
        print(text)
    return 0


if __name__ == "__main__":
    sys.exit(main())
