from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Observation:
    """One dataset row prepared for publishing. `values` holds only what is published (original values)."""
    observation_id: str               # stable: dataset hash + row index
    row: int                          # 0-based data row index in the file
    index: int                        # 0-based position inside the selection
    values: dict[str, float]          # series name -> original value (never altered)
    omitted: tuple[tuple[str, str], ...] = ()   # (series, nan|+inf|-inf) left out under the omit policy
    timestamp_text: str = ""          # original relative Timestamp text (trace only)
    offset_us: int = 0                # Timestamp in integer microseconds
    flags: tuple[str, ...] = ()       # review flags; values are kept as they are
    warmup: bool = False              # first rows of the selection without full rolling history
    reference: dict[str, Any] = field(default_factory=dict)   # FDD, partition: NEVER sent


@dataclass(frozen=True)
class Selection:
    start_row: int
    end_row: int                      # inclusive

    @property
    def rows(self) -> int:
        return self.end_row - self.start_row + 1

    def key(self) -> tuple[int, int]:
        return (self.start_row, self.end_row)
