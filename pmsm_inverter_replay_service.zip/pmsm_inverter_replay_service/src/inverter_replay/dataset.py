"""Read-only access to processed_data/converted_dataset.csv (PMSM-inverter-fault-diagnosis-3.0).

Rules:
  * Values are parsed EXACTLY from the file text with float(); repr(value) reproduces the text.
    pandas' default CSV parser is not used because it changes about 57,000 cells of this file
    by one unit in the last place (see docs/INSPECTION_REPORT.md section 10).
  * Nothing is rounded, clipped, sign-flipped, smoothed, resampled, interpolated, padded or deduplicated.
  * Unusual values are FLAGGED for review only.
  * FDD is a reference label and Timestamp a relative index. Neither is a model input or a telemetry series.
  * The source may be the CSV itself or the Zenodo zip (read in place, never extracted or modified).
"""
from __future__ import annotations

import csv
import hashlib
import io
import math
import os
import threading
import zipfile
from dataclasses import dataclass, field
from decimal import ROUND_HALF_EVEN, Decimal
from typing import Optional

ZIP_MEMBER_SUFFIX = "processed_data/converted_dataset.csv"
LABEL_COLUMN = "FDD"
TIME_COLUMN = "Timestamp"
CLASSES = tuple(f"F{i}" for i in range(9))
ADC_COLUMNS = ("Ia", "Ib", "IDC")
SENSOR_FEATURES = ("Ia_original", "Ib_original", "VDC", "IDC_original", "T1", "T2", "T3", "VD")
REQUIRED_COLUMNS = (
    "Ia", "Ib", "VDC", "IDC", "T1", "T2", "T3", "VD", "FDD", "Timestamp",
    "Ia_original", "Ia_arduino", "Ib_original", "Ib_arduino", "IDC_original", "IDC_arduino",
    "Power_DC", "Power_AC", "Current_Imbalance", "Temp_Diff_Max", "Ia_Normalized", "Ib_Normalized",
    "VDC_RateOfChange", "IDC_RateOfChange", "VDC_MovingAvg", "IDC_MovingAvg",
)

# Partition labels (reproduction of the training notebook split; preview information only)
P_TRAIN, P_VAL, P_TEST, P_CV, P_PURGE, P_UNKNOWN = (
    "final_train", "final_validation", "held_out_test", "cv_development", "purge_gap", "unknown")


class DatasetError(ValueError):
    pass


def parse_value(text: str) -> float:
    """Exact float64 from the CSV text. Empty cell -> NaN. 'inf' / '-inf' -> infinities."""
    t = text.strip()
    if t == "":
        return math.nan
    return float(t)


def nonfinite_kind(v: float) -> Optional[str]:
    if math.isnan(v):
        return "nan"
    if math.isinf(v):
        return "+inf" if v > 0 else "-inf"
    return None


def timestamp_to_us(text: str) -> int:
    """Relative Timestamp text -> integer microseconds (exact decimal arithmetic, no float accumulation)."""
    return int((Decimal(text.strip()) * 1_000_000).to_integral_value(rounding=ROUND_HALF_EVEN))


@dataclass
class Row:
    index: int                    # 0-based data row index in the file
    values: dict[str, float]      # every numeric column, exact
    label: str                    # FDD (reference only)
    timestamp_text: str           # original Timestamp text (trace only)
    offset_us: int                # Timestamp in integer microseconds
    flags: list[str] = field(default_factory=list)
    partition: str = P_UNKNOWN
    boundary_crossing: bool = False
    model_ready: bool = False
    null_features: list[str] = field(default_factory=list)


@dataclass
class Block:
    label: str
    start: int
    end: int

    @property
    def rows(self) -> int:
        return self.end - self.start + 1


@dataclass
class Dataset:
    source: str
    source_kind: str               # csv | zip
    sha256: str                    # of the CSV bytes (the zip member when reading a zip)
    archive_sha256: Optional[str]
    columns: list[str]
    rows: list[Row]
    blocks: list[Block]
    partition_reproduced: bool
    partition_note: str
    text_roundtrip_mismatches: int
    contract: dict

    def block_of(self, row: int) -> Block:
        for b in self.blocks:
            if b.start <= row <= b.end:
                return b
        raise DatasetError(f"row {row} is outside the dataset (0..{len(self.rows) - 1})")

    def summary(self) -> dict:
        part: dict[str, dict] = {}
        for b in self.blocks:
            per: dict[str, list] = {}
            for p in (P_TRAIN, P_VAL, P_TEST):
                idx = [r.index for r in self.rows[b.start:b.end + 1] if r.partition == p]
                per[p] = {"first_row": idx[0], "last_row": idx[-1], "rows": len(idx)} if idx else None
            part[b.label] = per
        return {
            "source": os.path.basename(self.source), "source_kind": self.source_kind,
            "sha256": self.sha256, "archive_sha256": self.archive_sha256,
            "rows": len(self.rows), "columns": len(self.columns),
            "class_blocks": [{"label": b.label, "first_row": b.start, "last_row": b.end, "rows": b.rows} for b in self.blocks],
            "partition_reproduced": self.partition_reproduced, "partition_note": self.partition_note,
            "partition_ranges": part,
            "model_ready_rows": sum(1 for r in self.rows if r.model_ready),
            "not_model_ready_rows": [r.index for r in self.rows if not r.model_ready],
            "boundary_crossing_rows": sum(1 for r in self.rows if r.boundary_crossing),
            "parse_mode": "exact (float of the file text; repr reproduces the text)",
            "text_roundtrip_mismatches": self.text_roundtrip_mismatches,
        }


# ------------------------------------------------------------------ reading
def _read_bytes(path: str) -> tuple[bytes, str, Optional[str]]:
    if path.lower().endswith(".zip"):
        if not os.path.isfile(path):
            raise DatasetError(f"dataset archive {path!r} not found")
        with open(path, "rb") as fh:  # read-only
            archive_sha = hashlib.sha256(fh.read()).hexdigest()
        with zipfile.ZipFile(path, "r") as z:
            members = [n for n in z.namelist() if n.endswith(ZIP_MEMBER_SUFFIX)]
            if len(members) != 1:
                raise DatasetError(f"expected exactly one {ZIP_MEMBER_SUFFIX} in {os.path.basename(path)}, found {len(members)}")
            return z.read(members[0]), "zip", archive_sha
    if not os.path.isfile(path):
        raise DatasetError(f"dataset file {path!r} not found")
    with open(path, "rb") as fh:  # read-only
        return fh.read(), "csv", None


def load_dataset(path: str, contract: dict, *, test_frac: float = 0.2, n_folds: int = 3, purge_gap: int = 10,
                 rolling_window: int = 10) -> Dataset:
    raw, kind, archive_sha = _read_bytes(path)
    sha = hashlib.sha256(raw).hexdigest()
    reader = csv.reader(io.StringIO(raw.decode("utf-8")))
    header = next(reader, None)
    if not header:
        raise DatasetError("dataset is empty")
    header = [h.strip() for h in header]
    missing = [c for c in REQUIRED_COLUMNS if c not in header]
    if missing:
        raise DatasetError(f"dataset is missing required columns: {missing}")
    col = {c: i for i, c in enumerate(header)}
    numeric = [c for c in header if c != LABEL_COLUMN]

    rows: list[Row] = []
    mismatches = 0
    for n, rec in enumerate(reader):
        if len(rec) != len(header):
            raise DatasetError(f"data row {n} has {len(rec)} fields, expected {len(header)}")
        vals = {}
        for c in numeric:
            text = rec[col[c]]
            try:
                v = parse_value(text)
            except ValueError:
                raise DatasetError(f"data row {n} column {c}: not a number")
            if math.isfinite(v) and repr(v) != text.strip():
                mismatches += 1   # e.g. "532" written without ".0"; the float64 value is still exact
            vals[c] = v
        label = rec[col[LABEL_COLUMN]].strip()
        if label not in CLASSES:
            raise DatasetError(f"data row {n}: unexpected FDD label {label!r}")
        ts_text = rec[col[TIME_COLUMN]].strip()
        try:
            off = timestamp_to_us(ts_text)
        except Exception:
            raise DatasetError(f"data row {n}: unparseable Timestamp")
        rows.append(Row(index=n, values=vals, label=label, timestamp_text=ts_text, offset_us=off))
    if not rows:
        raise DatasetError("dataset has no data rows")

    blocks: list[Block] = []
    for r in rows:
        if blocks and blocks[-1].label == r.label:
            blocks[-1].end = r.index
        else:
            blocks.append(Block(r.label, r.index, r.index))

    ds = Dataset(source=path, source_kind=kind, sha256=sha, archive_sha256=archive_sha, columns=header, rows=rows,
                 blocks=blocks, partition_reproduced=False, partition_note="", text_roundtrip_mismatches=mismatches,
                 contract=contract)
    _annotate(ds, rolling_window)
    _reproduce_partition(ds, test_frac, n_folds, purge_gap)
    return ds


# ------------------------------------------------------------------ annotations (flags only)
def _annotate(ds: Dataset, window: int) -> None:
    feats = ds.contract["features"]
    nullable = set(ds.contract["nullable"])
    labels = [r.label for r in ds.rows]
    seen: set[tuple] = set()
    for r in ds.rows:
        i = r.index
        # stored rolling features cover rows i-window+1 .. i and i-1
        lo = max(0, i - window + 1)
        r.boundary_crossing = len(set(labels[lo:i + 1])) > 1
        if r.boundary_crossing:
            r.flags.append("boundary_crossing")
        # model readiness under the API contract
        bad = [f["name"] for f in feats if not math.isfinite(r.values[f["name"]])]
        r.null_features = [f for f in bad if f in nullable and math.isinf(r.values[f])]
        r.model_ready = all(f in nullable and math.isinf(r.values[f]) for f in bad)
        for f in bad:
            r.flags.append(f"non_finite:{f}")
        # review flags; values are never altered
        for v in ("VDC", "VD"):
            if r.values[v] < 0:
                r.flags.append(f"negative_{v}")
        key = tuple(r.values[c] for c in SENSOR_FEATURES)
        if key in seen:
            r.flags.append("repeated_sensor_combination")
        seen.add(key)
        for f in feats:
            v = r.values[f["name"]]
            if not math.isfinite(v):
                continue
            lo_t, hi_t = f["observed_range_training_window"]
            if v < lo_t or v > hi_t:
                r.flags.append(f"outside_training_range:{f['name']}")
            lo_f, hi_f = f["observed_range_full_dataset"]
            if v < lo_f or v > hi_f:
                excess = max(lo_f - v, v - hi_f)
                tag = "outside_observed_range_1ulp" if excess <= math.ulp(v) else "outside_observed_range"
                r.flags.append(f"{tag}:{f['name']}")


# ------------------------------------------------------------------ notebook split (reproduction)
def _reproduce_partition(ds: Dataset, test_frac: float, n_folds: int, purge_gap: int) -> None:
    """Pure-Python copy of rolling_window_split() in the training notebook (cell 4).

    Valid only when every class is one contiguous block and Timestamp is strictly increasing
    inside each class (then sorting by Timestamp keeps file order). Otherwise partitions stay 'unknown'.
    """
    labels = [b.label for b in ds.blocks]
    if len(labels) != len(set(labels)):
        ds.partition_note = "a class appears in more than one block; partition not reproduced"
        return
    for b in ds.blocks:
        offs = [ds.rows[i].offset_us for i in range(b.start, b.end + 1)]
        if any(offs[k] >= offs[k + 1] for k in range(len(offs) - 1)):
            ds.partition_note = f"Timestamp not strictly increasing inside {b.label}; partition not reproduced"
            return
    for r in ds.rows:
        r.partition = P_PURGE
    n_blocks = n_folds + 1
    for b in sorted(ds.blocks, key=lambda x: x.label):
        idx = list(range(b.start, b.end + 1))
        n = len(idx)
        n_test = int(math.floor(test_frac * n))
        test_start = n - n_test
        cv_end = max(0, test_start - purge_gap)
        pool = idx[:cv_end]
        m = len(pool)
        size = m // n_blocks
        blks = [pool[k * size:(k + 1) * size] for k in range(n_blocks - 1)]
        blks.append(pool[(n_blocks - 1) * size:])
        for k in range(n_folds):
            tr = blks[k][:-purge_gap] if len(blks[k]) > purge_gap else []
            va = blks[k + 1][purge_gap:] if len(blks[k + 1]) > purge_gap else []
            for i in tr + va:
                if ds.rows[i].partition == P_PURGE:
                    ds.rows[i].partition = P_CV
            if k == n_folds - 1:                       # the final model's window (folds[-1])
                for i in va:
                    ds.rows[i].partition = P_VAL
                for i in tr:
                    ds.rows[i].partition = P_TRAIN
        for i in idx[test_start:]:
            ds.rows[i].partition = P_TEST
    expected = ds.contract.get("training_class_counts")
    got = {}
    for r in ds.rows:
        if r.partition == P_TRAIN:
            got[r.label] = got.get(r.label, 0) + 1
    ds.partition_reproduced = True
    if expected and got != expected:
        ds.partition_note = "reproduced with notebook logic, but final-train class counts differ from model_metadata.json"
    elif expected:
        ds.partition_note = "reproduced with notebook logic; final-train class counts equal model_metadata.json"
    else:
        ds.partition_note = "reproduced with notebook logic; no metadata counts to verify against"


# ------------------------------------------------------------------ cache
_CACHE: dict[tuple, Dataset] = {}
_LOCK = threading.Lock()


def get_dataset(path: Optional[str], contract: dict, **kw) -> Dataset:
    if not path:
        raise DatasetError("INVERTER_DATASET_PATH is not configured")
    try:
        st = os.stat(path)
    except OSError:
        raise DatasetError(f"dataset {path!r} not found")
    key = (os.path.abspath(path), st.st_size, st.st_mtime_ns, tuple(sorted(kw.items())), id(contract))
    with _LOCK:
        ds = _CACHE.get(key)
        if ds is None:
            ds = load_dataset(path, contract, **kw)
            _CACHE.clear()
            _CACHE[key] = ds
        return ds
