"""HTTP control API (same shape as the Battery/Transformer replay service).

Endpoints:
  GET  /health
  GET  /config                     effective non-secret settings and publish gate status
  GET  /dataset                    class blocks, reproduced partitions, readiness (no rows)
  POST /replays                    create a run (default mode dry_run)
  GET  /replays                    list runs
  GET  /replays/{run_id}           status and counters
  GET  /replays/{run_id}/preview   exact payloads, summary and reference labels
  POST /replays/{run_id}/stop

The API has no authentication of its own; it is meant to sit behind the platform's gateway.
"""
from __future__ import annotations

from typing import Literal, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field

from . import __version__
from .config import Settings
from .contract import ContractError
from .dataset import DatasetError
from .engine import ReplayManager, RunRejected, RunRequest
from .payload import MappingError, load_mapping


class CreateReplay(BaseModel):
    model_config = ConfigDict(extra="forbid")
    start_row: int = Field(..., ge=0)
    end_row: int = Field(..., ge=0, description="inclusive")
    mode: Literal["dry_run", "publish"] = "dry_run"
    profile: Optional[Literal["sensor", "sensor_plus_features"]] = None
    timestamp_policy: Optional[Literal["shifted", "reconstructed"]] = None
    anchor_mode: Optional[Literal["start", "end"]] = None
    anchor_time: Optional[str] = None
    source_interval_seconds: Optional[float] = Field(None, gt=0)
    pace_mode: Optional[Literal["fixed_interval", "timeline_scaled", "asap"]] = None
    pace_seconds: Optional[float] = Field(None, ge=0)
    speed_factor: Optional[float] = Field(None, gt=0)
    max_requests_per_second: Optional[float] = Field(None, gt=0)
    limit: Optional[int] = Field(None, ge=1)
    paced: bool = False


def create_app(settings: Settings, manager: Optional[ReplayManager] = None) -> FastAPI:
    app = FastAPI(title="PMSM Inverter Telemetry Replay Service", version=__version__)
    mgr = manager or ReplayManager(settings)

    @app.get("/health")
    def health():
        return {"status": "UP", "version": __version__}

    @app.get("/config")
    def config():
        try:
            m = load_mapping(settings.mapping_path, mgr.contract())
            mstatus, mprofile = m.get("status"), m.get("selected_profile")
        except Exception:
            mstatus, mprofile = "UNREADABLE", None
        view = settings.public_view()
        return {**view, "mapping_status": mstatus, "mapping_selected_profile": mprofile,
                "publish_blockers": settings.publish_blockers(mstatus, mprofile, settings.profile)}

    @app.get("/dataset")
    def dataset():
        try:
            return mgr.dataset().summary()
        except (DatasetError, ContractError) as e:
            raise HTTPException(409, str(e))

    @app.post("/replays", status_code=202)
    def create_replay(body: CreateReplay):
        try:
            run = mgr.create(RunRequest(**body.model_dump()))
        except RunRejected as e:
            raise HTTPException(422, {"rejected": e.reasons})
        except (DatasetError, MappingError, ContractError) as e:
            raise HTTPException(409, str(e))
        return run.status()

    @app.get("/replays")
    def list_replays():
        return [r.status() for r in mgr.runs()]

    @app.get("/replays/{run_id}")
    def get_replay(run_id: str):
        r = mgr.get(run_id)
        if not r:
            raise HTTPException(404, "unknown run_id")
        return r.status()

    @app.get("/replays/{run_id}/preview")
    def preview(run_id: str):
        r = mgr.get(run_id)
        if not r:
            raise HTTPException(404, "unknown run_id")
        p = r.prepared
        return {"summary": p.summary, "reference_labels": p.reference_labels, "payloads": p.payloads}

    @app.post("/replays/{run_id}/stop")
    def stop(run_id: str):
        r = mgr.stop(run_id)
        if not r:
            raise HTTPException(404, "unknown run_id")
        return r.status()

    return app
