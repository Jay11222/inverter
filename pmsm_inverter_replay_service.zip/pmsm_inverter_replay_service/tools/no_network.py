"""Run a command of this package with all outbound network connections disabled.

  python tools/no_network.py -m inverter_replay.cli preview --start-row 6516 --end-row 6856 --out p.json
Any socket connect raises, so a dry run that tried to reach a tenant would fail loudly.
"""
import runpy
import socket
import sys


def _deny(*a, **k):
    raise RuntimeError("network access is disabled for this run")


socket.socket.connect = _deny
socket.socket.connect_ex = _deny
socket.create_connection = _deny
socket.getaddrinfo = _deny

if __name__ == "__main__":
    if len(sys.argv) < 3 or sys.argv[1] != "-m":
        sys.exit("usage: no_network.py -m <module> [args...]")
    mod = sys.argv[2]
    sys.argv = [mod] + sys.argv[3:]
    runpy.run_module(mod, run_name="__main__", alter_sys=True)
