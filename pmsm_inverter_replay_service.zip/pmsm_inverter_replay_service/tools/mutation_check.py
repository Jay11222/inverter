"""Mutation check: deliberately break key behaviours and confirm the test suite fails for each.

  python tools/mutation_check.py [--python /path/to/python] [--out mutation_report.json]

Each mutation is applied to a temporary copy of the project (the working tree is never modified),
then pytest runs. A mutation is KILLED when pytest fails; the report lists which tests failed. The tool exits non-zero if the unmutated
baseline fails or if any mutation survives. Use a Python with requirements-validation.txt installed
so the calibration mutation is exercised (otherwise its tests are skipped and it SURVIVES).
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PKG = "src/inverter_replay"

MUTATIONS = [
    ("round_a_value", f"{PKG}/dataset.py",
     "    return float(t)\n", "    return round(float(t), 6)\n"),
    ("replace_infinity_with_zero", f"{PKG}/engine.py",
     "                if math.isfinite(v):\n                    values[name] = v                      # exactly as read\n",
     "                if True:\n                    values[name] = v if math.isfinite(v) else 0.0\n"),
    ("replace_infinity_with_median", f"{PKG}/engine.py",
     "                if math.isfinite(v):\n                    values[name] = v                      # exactly as read\n",
     "                if True:\n                    values[name] = v if math.isfinite(v) else 2.5\n"),
    ("publish_fdd", f"{PKG}/payload.py",
     "    body[mapping[\"fragment\"]] = series\n",
     "    series[\"FDD\"] = {\"value\": float(obs.reference[\"FDD\"][1:])}   # label as a number\n    body[mapping[\"fragment\"]] = series\n"),
    ("send_time_as_measurement_time", f"{PKG}/engine.py",
     "                    res = sink.send(payload, obs)\n",
     "                    payload = dict(payload, time=to_c8y_time(datetime.now(timezone.utc)))\n"
     "                    res = sink.send(payload, obs)\n"),
    ("compress_spacing_when_pace_scaled", f"{PKG}/engine.py",
     "            times = resolve_times([o.offset_us for o in obs], pol, anchor, a_mode, interval)\n",
     "            _k = speed if p_mode == \"timeline_scaled\" else 1\n"
     "            times = resolve_times([int(o.offset_us / _k) for o in obs], pol, anchor, a_mode, interval / _k)\n"),
    ("rebuild_features_with_original_calibration", f"{PKG}/validation.py",
     "    ia_a = ref.arduino_acs712_current(df[\"Ia\"])\n    ib_a = ref.arduino_acs712_current(df[\"Ib\"])\n"
     "    idc_a = ref.arduino_acs712_current(df[\"IDC\"])\n",
     "    ia_a = df[\"Ia_original\"]\n    ib_a = df[\"Ib_original\"]\n    idc_a = df[\"IDC_original\"]\n"),
    ("skip_duplicate_lookup", f"{PKG}/c8y_client.py",
     "                found = self.find_measurement(payload, trace_name)\n",
     "                found = False\n"),
    ("truncate_selection_to_cap", f"{PKG}/engine.py",
     "        if len(rows) > s.max_observations_per_run:\n            raise RunRejected(",
     "        rows = rows[: s.max_observations_per_run]\n        if False:\n            raise RunRejected("),
    ("unit_on_ratio_series", f"{PKG}/payload.py",
     "        if spec.get(\"unit\"):\n            entry[\"unit\"] = spec[\"unit\"]\n",
     "        entry[\"unit\"] = spec.get(\"unit\") or \"ratio\"\n"),
]


def run_pytest(python: str, cwd: Path) -> tuple[int, str]:
    p = subprocess.run([python, "-m", "pytest", "-q", "-rf", "-p", "no:cacheprovider"], cwd=cwd,
                       capture_output=True, text=True, timeout=900)
    lines = p.stdout.strip().splitlines() or [""]
    failed = sorted({l.split(" ")[1].split("[")[0] for l in lines if l.startswith("FAILED ")})
    return p.returncode, lines[-1] + (("  | failing tests: " + ", ".join(failed)) if failed else "")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--python", default=sys.executable)
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    results = []
    with tempfile.TemporaryDirectory() as td:
        base = Path(td) / "base"
        shutil.copytree(ROOT, base, ignore=shutil.ignore_patterns(".git", "runs", "__pycache__", ".pytest_cache"))
        code, tail = run_pytest(a.python, base)
        results.append({"mutation": "baseline (no mutation)", "pytest_exit": code, "summary": tail,
                        "result": "PASS" if code == 0 else "FAIL"})
        if code != 0:
            print(json.dumps(results, indent=1)); return 2
        for name, rel, old, new in MUTATIONS:
            work = Path(td) / name
            shutil.copytree(base, work)
            f = work / rel
            text = f.read_text(encoding="utf-8")
            if text.count(old) != 1:
                results.append({"mutation": name, "result": "NOT_APPLIED", "summary": "pattern not found exactly once"})
                continue
            f.write_text(text.replace(old, new), encoding="utf-8")
            t0 = time.time()
            code, tail = run_pytest(a.python, work)
            results.append({"mutation": name, "file": rel, "pytest_exit": code, "summary": tail,
                            "seconds": round(time.time() - t0, 1), "result": "KILLED" if code != 0 else "SURVIVED"})
            shutil.rmtree(work)
    text = json.dumps(results, indent=1)
    if a.out:
        Path(a.out).write_text(text + "\n", encoding="utf-8")
    print(text)
    return 0 if all(r["result"] in ("PASS", "KILLED") for r in results) else 1


if __name__ == "__main__":
    sys.exit(main())
