"""Build config/model_contract.json from the PMSMInverter repository (read-only).

  python -I tools/build_contract.py --repo /path/to/PMSMInverter --out config/model_contract.json

Reads artifacts/feature_schema.json, artifacts/model_metadata.json and app/schemas.py. Records the
SHA-256 of every file read. Never writes to the repository. app/schemas.py is parsed as text only
(not imported) to cross-check the nullable fields, so no model dependencies are needed.
"""
import argparse
import hashlib
import json
import re
import sys
from pathlib import Path


def sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    repo = Path(a.repo)
    files = {k: repo / k for k in ("artifacts/feature_schema.json", "artifacts/model_metadata.json", "app/schemas.py")}
    before = {k: sha(p) for k, p in files.items()}
    schema = json.loads(files["artifacts/feature_schema.json"].read_text(encoding="utf-8"))
    meta = json.loads(files["artifacts/model_metadata.json"].read_text(encoding="utf-8"))
    src = files["app/schemas.py"].read_text(encoding="utf-8")

    fields = re.findall(r"^\s{4}(\w+):\s*(Finite|FiniteOrNull)\s*=", src, flags=re.M)
    schemas_nullable = sorted(n for n, t in fields if t == "FiniteOrNull")
    schemas_fields = [n for n, _ in fields]
    names = schema["feature_order"]
    nullable = [f["name"] for f in schema["features"] if f["nullable"]]
    problems = []
    if sorted(schemas_fields) != sorted(names):
        problems.append("app/schemas.py fields differ from feature_schema.json")
    if schemas_nullable != sorted(nullable):
        problems.append("app/schemas.py nullable fields differ from feature_schema.json")
    if 'extra="forbid"' not in src:
        problems.append("app/schemas.py does not forbid extra fields")
    if "allow_inf_nan=False" not in src:
        problems.append("app/schemas.py does not reject NaN/infinity")
    if problems:
        print(json.dumps({"problems": problems}, indent=1)); return 2

    contract = {
        "contract_version": "1.0.0",
        "status": "FROM_REPOSITORY_UNVERIFIED_AGAINST_DEPLOYED_OPENAPI",
        "model_name": meta.get("model_name"), "model_version": meta.get("model_version"),
        "feature_count": schema["feature_count"], "feature_order": names, "nullable": nullable,
        "request_rules": {"all_fields_required": True, "extra_fields": "forbidden", "strict_numbers": True,
                          "nan_or_infinity": "rejected (HTTP 422)", "null": "only for nullable ratio features"},
        "sampling": schema.get("sampling"), "intermediate_definitions": schema.get("intermediate_definitions"),
        "features": [{k: f.get(k) for k in ("index", "name", "unit", "source", "formula", "nullable", "null_when",
                                               "history_required", "observed_range_training_window",
                                               "observed_range_full_dataset")} for f in schema["features"]],
        "training_class_counts": meta.get("training_data", {}).get("class_counts"),
        "dataset_sha256": meta.get("dataset", {}).get("sha256"),
        "class_definitions": meta.get("target", {}).get("class_definitions"),
        "sources": {k: {"sha256": v} for k, v in before.items()},
    }
    after = {k: sha(p) for k, p in files.items()}
    if before != after:
        print("input files changed while reading", file=sys.stderr); return 3
    Path(a.out).write_text(json.dumps(contract, indent=1) + "\n", encoding="utf-8")
    print(f"wrote {a.out}: {len(names)} features, nullable {nullable}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
