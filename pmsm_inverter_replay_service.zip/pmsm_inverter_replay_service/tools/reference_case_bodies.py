"""For each reference case in the model repo's samples/expected_predictions.json, build the /predict body the
replay would let upstream form (sensor_plus_features profile, exact file values) and compare it with the
case's request body. Offline; never calls the model.

  PYTHONPATH=src INVERTER_DATASET_PATH=... python tools/reference_case_bodies.py \
      --expected /path/PMSMInverter/samples/expected_predictions.json --out reference_case_bodies.json
"""
import argparse
import json
import math
import sys

from inverter_replay.config import load_settings
from inverter_replay.contract import body_from_measurement, validate_predict_body
from inverter_replay.engine import ReplayManager, RunRequest


def ulps(a, b):
    if a is None or b is None:
        return 0 if a is b else None
    return 0 if a == b else round(abs(a - b) / math.ulp(max(abs(a), abs(b))))


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--expected", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    exp = json.load(open(a.expected, encoding="utf-8"))
    mgr = ReplayManager(load_settings())
    contract = mgr.contract()
    out = []
    for c in exp["cases"]:
        row = c["source"]["dataset_row_index"]
        p = mgr.prepare(RunRequest(row, row, profile="sensor_plus_features"))
        frag = p.mapping["fragment"]
        body = body_from_measurement(contract, p.payloads[0][frag])
        diffs = {k: ulps(body[k], c["request"][k]) for k in contract["feature_order"]}
        out.append({"case_id": c["case_id"], "row": row, "reference_label": p.observations[0].reference["FDD"],
                    "partition": p.observations[0].reference["partition"],
                    "expected_predicted_class": c["expected_predicted_class"],
                    "replay_predict_body": body, "body_valid": not validate_predict_body(contract, body),
                    "null_features": [k for k, v in body.items() if v is None],
                    "features_differing_from_reference_request": {k: v for k, v in diffs.items() if v},
                    "max_ulp_difference": max((v for v in diffs.values() if v is not None), default=0)})
    json.dump({"note": "Replay bodies use the exact file values. Reference requests were exported with pandas' default "
                       "CSV parser and differ by a few units in the last place in some features.", "cases": out},
              open(a.out, "w", encoding="utf-8"), indent=1, allow_nan=False)
    for r in out:
        print(r["case_id"], r["row"], r["reference_label"], r["partition"], "valid", r["body_valid"],
              "null", r["null_features"], "features differing", len(r["features_differing_from_reference_request"]),
              "max ulp", r["max_ulp_difference"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
