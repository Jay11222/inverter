import json
import logging
import math
import socket
import time
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from conftest import CLASS_SIZES, INF_IMBALANCE_ROW, INF_NORMALIZED_ROW, MAPPING, read_text_cells
from inverter_replay.engine import ReplayManager, RunRejected, RunRequest
from inverter_replay.payload import DRY_RUN_DEVICE
from inverter_replay.timeline import parse_utc

FRAG = "PMSMInverter"
F0, F1 = CLASS_SIZES["F0"], CLASS_SIZES["F1"]
F1_START, F1_END = F0, F0 + F1 - 1


def mapping():
    return json.loads(Path(MAPPING).read_text())


def wait(run, states=("COMPLETED", "FAILED", "STOPPED", "HALTED_UNCONFIRMED"), timeout=10):
    t = time.time()
    while run.state not in states and time.time() - t < timeout:
        time.sleep(0.02)
    return run.state


@pytest.fixture
def no_network(monkeypatch):
    def deny(*a, **k):
        raise AssertionError("network access attempted in dry run")
    monkeypatch.setattr(socket.socket, "connect", deny)


def prep(settings, *a, **kw):
    return ReplayManager(settings).prepare(RunRequest(*a, **kw))


# ---------------- values, order, labels ----------------
@pytest.mark.parametrize("profile", ["sensor", "sensor_plus_features"])
def test_values_preserved_bit_for_bit(settings, dataset_csv, profile):
    p = prep(settings, 0, 289, profile=profile)
    header, body = read_text_cells(dataset_csv)
    spec = mapping()["profiles"][profile]["series"]
    checked = 0
    for pl in p.payloads:
        row = pl["replayTrace"]["rowIndex"]
        for name, entry in pl[FRAG].items():
            assert repr(entry["value"]) == body[row][header.index(spec[name]["source_column"])]
            checked += 1
    assert checked > 2000


def test_order_and_ids_stable(settings):
    a, b = prep(settings, 100, 140), prep(settings, 100, 140)
    rows = [pl["replayTrace"]["rowIndex"] for pl in a.payloads]
    assert rows == list(range(100, 141))
    assert [pl["time"] for pl in a.payloads] == sorted(pl["time"] for pl in a.payloads)
    assert [o.observation_id for o in a.observations] == [o.observation_id for o in b.observations]
    assert a.run_id != b.run_id
    assert a.observations[0].observation_id.endswith("-r00100")


@pytest.mark.parametrize("profile", ["sensor", "sensor_plus_features"])
def test_fdd_never_in_payload_and_timestamp_never_a_series(settings, profile):
    p = prep(settings, F1_START - 20, F1_START + 20, profile=profile)
    text = json.dumps(p.payloads)
    assert "FDD" not in text and "partition" not in text
    for pl in p.payloads:
        assert "Timestamp" not in pl[FRAG] and "FDD" not in pl[FRAG]
        assert set(pl) == {"source", "time", "type", FRAG, "replayTrace"}
        assert not ({"F0", "F1", "F2"} & {str(v) for v in pl["replayTrace"].values()})
    assert {x["FDD"] for x in p.reference_labels} == {"F0", "F1"}                    # kept separately
    assert p.payloads[0]["replayTrace"]["sourceTimestamp"] == repr(0.0 + (F1_START - 20) * 0.1)     # original text


@pytest.mark.parametrize("profile", ["sensor", "sensor_plus_features"])
def test_each_profile_publishes_exactly_its_series(settings, profile):
    p = prep(settings, 9, 60, profile=profile)
    spec = list(mapping()["profiles"][profile]["series"])
    for o, pl in zip(p.observations, p.payloads):
        omitted = {n for n, _ in o.omitted}
        assert list(pl[FRAG]) == [n for n in spec if n not in omitted]
    assert p.summary["series"] == spec


def test_units_from_contract_and_ratio_series_have_no_unit(settings):
    p = prep(settings, 9, 20, profile="sensor_plus_features")
    s = p.payloads[0][FRAG]
    for n in ("Current_Imbalance", "Ia_Normalized", "Ib_Normalized"):
        assert "unit" not in s[n]
    assert s["T1"]["unit"] == "degC" and s["VDC_RateOfChange"]["unit"] == "V/s" and s["Power_AC"]["unit"] == "W"
    assert "unit" not in prep(settings, 9, 20, profile="sensor").payloads[0][FRAG]["Ia_adc"]


# ---------------- non-finite values ----------------
def test_nonfinite_omitted_never_substituted(settings):
    p = prep(settings, 0, 40, profile="sensor_plus_features")
    by_row = {pl["replayTrace"]["rowIndex"]: pl for pl in p.payloads}
    assert "VDC_MovingAvg" not in by_row[0][FRAG] and "VDC_RateOfChange" not in by_row[0][FRAG]
    assert "VDC_RateOfChange" in by_row[1][FRAG] and "VDC_MovingAvg" not in by_row[8][FRAG]
    assert "Current_Imbalance" not in by_row[INF_IMBALANCE_ROW][FRAG]
    assert "Ia_Normalized" not in by_row[INF_NORMALIZED_ROW][FRAG]
    assert "Current_Imbalance:+inf" in by_row[INF_IMBALANCE_ROW]["replayTrace"]["omittedSeries"]
    text = json.dumps(p.payloads, allow_nan=False)                                      # raises on NaN/Infinity
    assert "Infinity" not in text and "NaN" not in text
    nf = p.summary["non_finite"]
    assert nf["omitted_count"] == 20 + 1 + 2 and nf["substitution"].startswith("none")
    for pl in p.payloads:
        for v in pl[FRAG].values():
            assert math.isfinite(v["value"])


def test_nonfinite_policy_block_refuses(settings):
    with pytest.raises(RunRejected, match="NONFINITE_POLICY=block"):
        prep(replace(settings, nonfinite_policy="block"), 0, 40, profile="sensor_plus_features")
    prep(replace(settings, nonfinite_policy="block"), 0, 40, profile="sensor")            # sensor values are finite


def test_model_readiness_and_predict_bodies(settings):
    p = prep(settings, 0, 60, profile="sensor_plus_features")
    mr = p.summary["model_readiness"]
    assert mr["not_model_ready_rows"] == list(range(9))
    assert {x["row"] for x in mr["rows_needing_null"]} == {INF_IMBALANCE_ROW, INF_NORMALIZED_ROW}
    cc = p.summary["contract_check"]
    assert cc["applies"] and cc["valid_bodies"] == 61 - 9 and cc["invalid_bodies"] == 9
    samples = p.summary["sample_predict_bodies"]
    assert samples and all(s["valid"] for s in samples if s["row"] >= 9)
    assert any(s["null_features"] == ["Current_Imbalance"] for s in samples)
    assert all("FDD" not in s["predict_body"] and s["reference_label"] in ("F0",) for s in samples)


def test_sensor_profile_samples_show_expected_body(settings):
    p = prep(settings, 20, 40, profile="sensor")
    s = p.summary["sample_predict_bodies"][0]
    assert set(s["expected_predict_body_from_dataset"]) == set(p.summary["series"][:8]) | {
        "Power_DC", "Power_AC", "Current_Imbalance", "Ia_Normalized", "Ib_Normalized", "VDC_RateOfChange",
        "IDC_RateOfChange", "VDC_MovingAvg", "IDC_MovingAvg", "Temp_Diff_Max"}
    assert p.summary["contract_check"]["applies"] is False


# ---------------- selection analysis ----------------
def test_selection_kinds_warmup_boundary_partitions(settings):
    full = prep(settings, F1_START, F1_END).summary["selection"]
    assert full["kind"] == "full_class_block" and full["class_composition"] == {"F1": F1}
    win = prep(settings, F1_START + 30, F1_START + 50).summary["selection"]
    assert win["kind"] == "window_in_class_block" and win["boundary_crossing_rows"] == []
    tr = prep(settings, F1_START - 10, F1_START + 15).summary["selection"]
    assert tr["kind"] == "across_class_transition"
    assert tr["transitions"] == [{"after_row": F1_START - 1, "from": "F0", "to": "F1"}]
    assert tr["boundary_crossing_rows"] == list(range(F1_START, F1_START + 9))
    assert tr["warmup_rows"] == list(range(F1_START - 10, F1_START - 1))
    assert any("separate recordings" in w for w in tr["warnings"])
    assert sum(tr["partition_composition"].values()) == 26
    assert any("overstates model accuracy" in w for w in tr["warnings"])


def test_held_out_only_selection_has_no_accuracy_warning(settings):
    m = ReplayManager(settings)
    rows = [r.index for r in m.dataset().rows if r.label == "F2" and r.partition == "held_out_test"]
    s = m.prepare(RunRequest(rows[0], rows[-1])).summary["selection"]
    assert s["partition_composition"] == {"held_out_test": len(rows)}
    assert not any("overstates" in w for w in s["warnings"])


def test_out_of_range_selection_rejected(settings):
    for a, b in ((-1, 3), (5, 2), (0, 290)):
        with pytest.raises(RunRejected):
            prep(settings, a, b)


# ---------------- timestamps and pacing ----------------
@pytest.mark.parametrize("pace", [("fixed_interval", 1.0, 5.0), ("timeline_scaled", 10.0, 0.0), ("asap", 1.0, 0.0)])
@pytest.mark.parametrize("policy", ["shifted", "reconstructed"])
def test_spacing_100ms_under_every_policy_and_pace(settings, policy, pace):
    mode, speed, pace_s = pace
    p = prep(settings, 50, 80, timestamp_policy=policy, pace_mode=mode, speed_factor=speed, pace_seconds=pace_s)
    t = [parse_utc(pl["time"]) for pl in p.payloads]
    assert all(t[i] - t[i - 1] == timedelta(milliseconds=100) for i in range(1, len(t)))
    assert p.summary["timeline"]["spacing_us_values"] == [100000]
    assert p.payloads[0]["replayTrace"]["timeOrigin"] == policy
    assert p.payloads[0]["time"] == "2026-01-01T00:00:00.000Z"


def test_anchor_end_and_now_resolved_once(settings):
    fixed = datetime(2030, 5, 5, 12, 0, 0, tzinfo=timezone.utc)
    m = ReplayManager(replace(settings, anchor_time="now", anchor_mode="end"), clock=lambda: fixed)
    p = m.prepare(RunRequest(10, 30))
    assert p.payloads[-1]["time"] == "2030-05-05T12:00:00.000Z"
    assert p.payloads[0]["time"] == "2030-05-05T11:59:58.000Z"
    assert p.summary["timeline"]["timezone"] == "UTC"


def test_pace_estimate_and_realtime_note(settings):
    s = prep(replace(settings, pace_mode="fixed_interval", pace_seconds=2.0, max_requests_per_second=1.0), 0, 10).summary
    assert s["pacing"]["estimated_duration_seconds"] == 20.0 and s["pacing"]["realtime_requests_per_second"] == 10.0


def test_measurement_time_is_not_send_time(settings, no_network):
    m = ReplayManager(replace(settings, pace_mode="fixed_interval", pace_seconds=0.05, max_requests_per_second=1000.0))
    run = m.create(RunRequest(30, 35, paced=True)); wait(run)
    led = [json.loads(x) for x in Path(run.ledger_path).read_text().splitlines()]
    assert [x["time"] for x in led] == [f"2026-01-01T00:00:00.{k}00Z" for k in range(6)]


# ---------------- caps, flags, partial ----------------
def test_cap_refuses_never_truncates(settings):
    with pytest.raises(RunRejected, match="never truncated"):
        prep(replace(settings, max_observations_per_run=50), 0, 120)
    assert len(prep(replace(settings, max_observations_per_run=121), 0, 120).payloads) == 121


def test_flags_reported_values_kept(settings):
    p = prep(settings, F1_START - 2, F1_START + 12)
    f = p.summary["flags"]
    assert f["counts"]["boundary_crossing"] == 9 and f["observations_flagged"] >= 9
    with pytest.raises(RunRejected):
        prep(replace(settings, flagged_rows_policy="block"), F1_START - 2, F1_START + 12)


def test_limit_is_dry_run_only_and_marked_partial(settings):
    p = prep(settings, 0, 100, limit=5)
    assert len(p.payloads) == 5 and p.summary["selection"]["partial"] is True
    assert any("partial" in b for b in p.blockers)
    with pytest.raises(RunRejected):
        prep(settings, 0, 100, mode="publish", limit=5)


def test_dry_run_end_to_end_no_network_writes_preview_and_report(settings, no_network):
    run = ReplayManager(settings).create(RunRequest(9, 40, profile="sensor_plus_features"))
    assert wait(run) == "COMPLETED" and run.counters == {"DRY_RUN": 32}
    d = Path(settings.output_dir) / run.run_id
    pv = json.loads((d / "preview.json").read_text())
    rep = json.loads((d / "report.json").read_text())
    assert pv["payloads"][0]["source"]["id"] == DRY_RUN_DEVICE and len(pv["reference_labels"]) == 32
    assert rep["reference_labels"][0]["delivery"] == "DRY_RUN" and rep["reference_labels"][0]["FDD"] == "F0"
    assert "FDD" not in json.dumps(pv["payloads"])


def test_stop_and_concurrency(settings, no_network):
    s = replace(settings, pace_mode="fixed_interval", pace_seconds=5.0)
    m = ReplayManager(s)
    first = m.create(RunRequest(10, 20, paced=True))
    with pytest.raises(RunRejected, match="MAX_CONCURRENT_RUNS"):
        m.create(RunRequest(10, 20))
    time.sleep(0.1); m.stop(first.run_id)
    assert wait(first, timeout=3) == "STOPPED" and first.counters.get("DRY_RUN", 0) < 11


# ---------------- publish gates ----------------
def test_publish_blocked_by_default_with_every_reason(settings):
    with pytest.raises(RunRejected) as e:
        prep(settings, 10, 20, mode="publish")
    text = str(e.value)
    for needle in ("PUBLISH_ENABLED", "TARGET_APPROVED", "mapping status", "selected_profile", "C8Y_BASEURL",
                   "C8Y_USER", "C8Y_DEVICE_ID", "SELECTION_MANIFEST", "approved selection manifest"):
        assert needle in text


@pytest.fixture
def publish_settings(settings, tmp_path, mock_c8y):
    m = mapping(); m["status"] = "APPROVED"; m["selected_profile"] = "sensor_plus_features"
    mp = tmp_path / "mapping.approved.json"; mp.write_text(json.dumps(m))
    sel = tmp_path / "sel.json"
    sel.write_text(json.dumps({"approved_by": "test", "selections": [{"id": "t", "start_row": 20, "end_row": 26}]}))
    return replace(settings, mapping_path=str(mp), selection_manifest=str(sel), publish_enabled=True, target_approved=True,
                   c8y_base_url=mock_c8y.url, c8y_user="svc", c8y_password="s3cr3t-pw", c8y_device_id="777",
                   http_backoff_seconds=0.0, http_read_timeout=0.3, profile="sensor_plus_features")


def test_publish_to_mock_tenant_end_to_end(publish_settings, mock_c8y):
    run = ReplayManager(publish_settings, sleep=lambda s: None).create(RunRequest(20, 26, mode="publish"))
    assert wait(run) == "COMPLETED" and run.counters == {"DELIVERED": 7}
    assert [m["source"]["id"] for m in mock_c8y.stored] == ["777"] * 7
    assert [m["time"] for m in mock_c8y.stored] == [p["time"] for p in run.prepared.payloads]     # not send time
    assert [m["time"] for m in mock_c8y.stored] == [f"2026-01-01T00:00:00.{k}00Z" for k in range(7)]
    assert not [r for r in mock_c8y.requests if r[0] == "POST" and "/inventory" in r[1]]         # never creates devices
    assert all(r[1].startswith(("/measurement/measurements", "/inventory/managedObjects/777")) for r in mock_c8y.requests)
    assert "FDD" not in json.dumps(mock_c8y.stored)
    st = mock_c8y.stored[INF_IMBALANCE_ROW - 20]
    assert "Current_Imbalance" not in st[FRAG] and st[FRAG]["Power_DC"]["unit"] == "W"


@pytest.mark.parametrize("change, needle", [
    (dict(publish_enabled=False), "PUBLISH_ENABLED"), (dict(target_approved=False), "TARGET_APPROVED"),
    (dict(c8y_device_id=None), "C8Y_DEVICE_ID"), (dict(c8y_password=None), "C8Y_USER"),
    (dict(c8y_base_url=None), "C8Y_BASEURL"), (dict(selection_manifest=None), "SELECTION_MANIFEST"),
    (dict(expected_dataset_sha256="0" * 64), "EXPECTED_DATASET_SHA256"), (dict(profile="sensor"), "differs from the approved"),
])
def test_each_gate_blocks_publishing(publish_settings, change, needle):
    with pytest.raises(RunRejected, match=needle):
        ReplayManager(replace(publish_settings, **change)).prepare(RunRequest(20, 26, mode="publish"))


def test_publish_requires_exact_approved_range(publish_settings):
    for a, b in ((20, 25), (21, 26), (19, 26)):
        with pytest.raises(RunRejected, match="approved selection manifest"):
            ReplayManager(publish_settings).prepare(RunRequest(a, b, mode="publish"))


def test_publish_mapping_not_approved_blocks(publish_settings, tmp_path):
    with pytest.raises(RunRejected, match="mapping status"):
        ReplayManager(replace(publish_settings, mapping_path=MAPPING)).prepare(RunRequest(20, 26, mode="publish"))


def test_publish_duplicate_reconciled_not_resent(publish_settings, mock_c8y):
    mock_c8y.post_script = ["ok", "503_stored"]
    run = ReplayManager(publish_settings, sleep=lambda s: None).create(RunRequest(20, 26, mode="publish"))
    assert wait(run) == "COMPLETED"
    assert run.counters == {"DELIVERED": 6, "DELIVERED_RECONCILED": 1}
    ids = [m["replayTrace"]["observationId"] for m in mock_c8y.stored]
    assert len(ids) == len(set(ids)) == 7 and len(mock_c8y.posts()) == 7


def test_publish_halts_on_unconfirmed(publish_settings, mock_c8y):
    mock_c8y.post_script = ["timeout_stored"]; mock_c8y.get_meas_status = 500
    run = ReplayManager(publish_settings).create(RunRequest(20, 26, mode="publish"))
    assert wait(run) == "HALTED_UNCONFIRMED" and len(mock_c8y.posts()) == 1


def test_publish_4xx_not_retried_and_halts(publish_settings, mock_c8y):
    mock_c8y.post_script = ["ok", "400"]
    run = ReplayManager(publish_settings).create(RunRequest(20, 26, mode="publish"))
    assert wait(run) == "FAILED" and run.counters == {"DELIVERED": 1, "REJECTED": 1} and len(mock_c8y.posts()) == 2


def test_publish_preflight_device_missing(publish_settings, mock_c8y):
    mock_c8y.device_status = 404
    run = ReplayManager(publish_settings).create(RunRequest(20, 26, mode="publish"))
    assert wait(run) == "FAILED" and "preflight" in run.error and not mock_c8y.posts()


def test_credentials_never_logged_during_publish(publish_settings, mock_c8y, caplog):
    caplog.set_level(logging.DEBUG)
    mock_c8y.post_script = ["503_stored", "400"]
    run = ReplayManager(publish_settings, sleep=lambda s: None).create(RunRequest(20, 26, mode="publish")); wait(run)
    d = Path(publish_settings.output_dir) / run.run_id
    blob = caplog.text + (d / "ledger.jsonl").read_text() + (d / "preview.json").read_text() + (d / "report.json").read_text()
    assert "s3cr3t-pw" not in blob and "svc" not in caplog.text
