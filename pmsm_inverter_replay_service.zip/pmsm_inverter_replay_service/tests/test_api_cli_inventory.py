import hashlib
import json
import time
from pathlib import Path

from fastapi.testclient import TestClient

from conftest import MAPPING
from inverter_replay import cli, inventory
from inverter_replay.api import create_app


def test_api_health_config_dataset_and_dry_run(settings):
    c = TestClient(create_app(settings))
    assert c.get("/health").json()["status"] == "UP"
    cfg = c.get("/config").json()
    assert cfg["publish_enabled"] is False and cfg["mapping_status"] == "PROPOSED" and cfg["publish_blockers"]
    assert "c8y_password" not in cfg and "c8y_user" not in cfg and cfg["credentials_configured"] is False
    ds = c.get("/dataset").json()
    assert [b["label"] for b in ds["class_blocks"]] == ["F0", "F1", "F2"] and ds["partition_reproduced"]
    r = c.post("/replays", json={"start_row": 9, "end_row": 20, "profile": "sensor_plus_features"})
    assert r.status_code == 202
    rid = r.json()["run_id"]
    for _ in range(200):
        st = c.get(f"/replays/{rid}").json()
        if st["state"] == "COMPLETED":
            break
        time.sleep(0.02)
    assert st["state"] == "COMPLETED" and st["counters"] == {"DRY_RUN": 12} and st["mode"] == "dry_run"
    pv = c.get(f"/replays/{rid}/preview").json()
    assert len(pv["payloads"]) == 12 and len(pv["reference_labels"]) == 12 and "FDD" not in json.dumps(pv["payloads"])
    assert c.get("/replays").json()[0]["run_id"] == rid
    assert c.post(f"/replays/{rid}/stop").status_code == 200
    assert c.get("/replays/nope").status_code == 404 and c.post("/replays/nope/stop").status_code == 404
    assert c.get("/replays/nope/preview").status_code == 404


def test_api_rejections(settings):
    c = TestClient(create_app(settings))
    r = c.post("/replays", json={"start_row": 9, "end_row": 20, "mode": "publish"})
    assert r.status_code == 422 and any("PUBLISH_ENABLED" in x for x in r.json()["detail"]["rejected"])
    assert c.post("/replays", json={"start_row": 9, "end_row": 20, "FDD": "F0"}).status_code == 422      # extra field
    assert c.post("/replays", json={"start_row": 9, "end_row": 20, "pace_seconds": -1}).status_code == 422
    assert c.post("/replays", json={"start_row": 9, "end_row": 20, "timestamp_policy": "send_time"}).status_code == 422
    assert c.post("/replays", json={"start_row": 9, "end_row": 99999}).status_code == 422
    assert c.post("/replays", json={"start_row": 9}).status_code == 422


def test_api_dataset_missing_is_409(settings):
    from dataclasses import replace
    c = TestClient(create_app(replace(settings, dataset_path="/nonexistent/x.csv")))
    assert c.get("/dataset").status_code == 409
    assert c.post("/replays", json={"start_row": 0, "end_row": 1}).status_code == 409


def _env(monkeypatch, settings):
    monkeypatch.setenv("INVERTER_DATASET_PATH", settings.dataset_path)
    monkeypatch.setenv("EXPECTED_DATASET_SHA256", settings.expected_dataset_sha256)
    monkeypatch.setenv("OUTPUT_DIR", settings.output_dir)
    monkeypatch.setenv("MAPPING_PATH", MAPPING)
    monkeypatch.setenv("MODEL_CONTRACT_PATH", settings.contract_path)
    monkeypatch.setenv("ANCHOR_TIME", "2026-01-01T00:00:00Z")


def test_cli_preview_and_dataset(monkeypatch, settings, tmp_path, capsys):
    _env(monkeypatch, settings)
    out = tmp_path / "p.json"
    assert cli.main(["preview", "--start-row", "100", "--end-row", "140", "--profile", "sensor_plus_features",
                     "--out", str(out)]) == 0
    doc = json.loads(out.read_text())
    assert len(doc["payloads"]) == 41 and doc["summary"]["mapping_status"] == "PROPOSED"
    assert cli.main(["preview", "--start-row", "5", "--end-row", "2"]) == 2
    assert cli.main(["dataset"]) == 0


def test_cli_contract_check(monkeypatch, settings, tmp_path):
    _env(monkeypatch, settings)
    c = json.loads(Path(settings.contract_path).read_text())
    props = {n: ({"anyOf": [{"type": "number"}, {"type": "null"}]} if n in c["nullable"] else {"type": "number"})
             for n in c["feature_order"]}
    oa = tmp_path / "openapi.json"
    oa.write_text(json.dumps({"components": {"schemas": {"PredictRequest": {
        "properties": props, "required": list(props), "additionalProperties": False}}}}))
    assert cli.main(["contract-check", "--openapi", str(oa)]) == 0


def test_inventory_is_read_only_and_aggregate(dataset_zip, contract_path, tmp_path):
    h = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
    before = h(dataset_zip)
    r = inventory.run(dataset_zip, contract_path)
    assert r["originals_unchanged"] is True and h(dataset_zip) == before
    inv = r["inverter"]
    assert inv["rows"] == 290 and inv["not_model_ready_rows"] == 9 and inv["rows_needing_null"] == 2
    assert inv["timestamp"]["equals_row_index_x_0.1"] and inv["timestamp"]["spacing_us"] == [100000]
    assert all(v["all_integer"] and v["within_0_1023"] for v in inv["adc_columns"].values())
    assert any(k.endswith("processed_data/converted_dataset.csv") for k in r["inputs_sha256_before"])
    assert "values" not in json.dumps(r)
