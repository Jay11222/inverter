"""Test double with the same public API as PMSMInverter app/feature_engineering.py (synthetic tests only).

The real module is never copied into this project; the validation tool imports it from the model
repository at run time. This double implements the same documented formulas.
"""
import numpy as np
import pandas as pd

SAMPLE_PERIOD_S = 0.1
MOVING_AVG_WINDOW = 10
RAW_ADC_COLUMNS = ["Ia", "Ib", "VDC", "IDC", "T1", "T2", "T3", "VD"]
FEATURES = ["Ia_original", "Ib_original", "VDC", "IDC_original", "T1", "T2", "T3", "VD", "Power_DC", "Power_AC",
            "Current_Imbalance", "Ia_Normalized", "Ib_Normalized", "VDC_RateOfChange", "IDC_RateOfChange",
            "VDC_MovingAvg", "IDC_MovingAvg", "Temp_Diff_Max"]


def adc_to_current_acs712_20a(adc):
    return ((adc / 1023) * 5 - 2.5) / 0.100


def arduino_acs712_current(adc):
    return 0.074 * (adc - 512)


def adc_to_voltage_acs712_100ohm(adc):
    return (((adc / 1023) * 5 - 2.5) / 0.100) * 100


def adc_to_temperature_ntc(adc):
    r = 10000 / ((1023 / adc) - 1)
    ln = np.log(r)
    return 1 / (1.2666e-3 + 2.3661e-4 * ln + 9.6094e-8 * ln**3) - 273.15


def compute_features(raw):
    r = raw[RAW_ADC_COLUMNS].astype(float)
    ia_a, ib_a, idc_a = (arduino_acs712_current(r[c]) for c in ("Ia", "Ib", "IDC"))
    vdc, vd = adc_to_voltage_acs712_100ohm(r["VDC"]), adc_to_voltage_acs712_100ohm(r["VD"])
    t = pd.DataFrame({k: adc_to_temperature_ntc(r[k]) for k in ("T1", "T2", "T3")})
    out = pd.DataFrame(index=raw.index)
    out["Ia_original"], out["Ib_original"] = adc_to_current_acs712_20a(r["Ia"]), adc_to_current_acs712_20a(r["Ib"])
    out["VDC"], out["IDC_original"] = vdc, adc_to_current_acs712_20a(r["IDC"])
    out["T1"], out["T2"], out["T3"], out["VD"] = t["T1"], t["T2"], t["T3"], vd
    out["Power_DC"], out["Power_AC"] = vdc * idc_a, vd * (ia_a + ib_a)
    out["Current_Imbalance"] = np.abs(ia_a - ib_a) / ((ia_a + ib_a) / 2)
    out["Ia_Normalized"], out["Ib_Normalized"] = ia_a / idc_a, ib_a / idc_a
    out["VDC_RateOfChange"], out["IDC_RateOfChange"] = vdc.diff() / 0.1, idc_a.diff() / 0.1
    out["VDC_MovingAvg"], out["IDC_MovingAvg"] = vdc.rolling(10).mean(), idc_a.rolling(10).mean()
    out["Temp_Diff_Max"] = t.max(axis=1) - t.min(axis=1)
    return out[FEATURES]
