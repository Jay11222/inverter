"""Feature reproducibility tool on synthetic data (needs numpy/pandas: requirements-validation.txt)."""
from pathlib import Path

import pytest

pytest.importorskip("pandas")

from conftest import make_rows, write_csv  # noqa: E402
from inverter_replay import validation  # noqa: E402

DOUBLE = str(Path(__file__).parent / "fixtures" / "reference_feature_engineering_double.py")


def _pandas_consistent_csv(tmp_path):
    """Synthetic processed file whose stored features come from the reference double (pandas arithmetic)."""
    import pandas as pd
    ref = validation.load_reference(DOUBLE)
    rows = make_rows()
    raw = pd.DataFrame([{c: r[c] for c in ("Ia", "Ib", "IDC")} for r in rows])
    raw["VDC"] = [r["VDC"] for r in rows]; raw["VD"] = [r["VD"] for r in rows]
    for k in ("T1", "T2", "T3"):
        raw[k] = [r[k] for r in rows]
    eng = validation.engineered_from_processed(ref, raw)
    for i, r in enumerate(rows):
        for f in validation.ENGINEERED:
            r[f] = float(eng.at[i, f])
    return write_csv(tmp_path / "converted_dataset.csv", rows)


def test_processed_mode_reproduces_exactly(tmp_path):
    p = _pandas_consistent_csv(tmp_path)
    r = validation.run(p, DOUBLE)
    assert r["reproduced_within_tolerance"] and r["inputs_unchanged"]
    assert all(v["max_abs_diff"] == 0.0 and v["nan_positions_equal"] and v["inf_positions_and_signs_equal"]
               for v in r["modes"]["processed"].values())


def test_wrong_calibration_would_be_detected(tmp_path):
    """Using *_original instead of the Arduino calibration must not reproduce the stored features."""
    import pandas as pd
    p = _pandas_consistent_csv(tmp_path)
    df = pd.read_csv(p, float_precision="round_trip")
    ref = validation.load_reference(DOUBLE)
    wrong = df.copy()
    wrong["Ia"], wrong["Ib"], wrong["IDC"] = (df[c + "_original"] / 0.074 + 512 for c in ("Ia", "Ib", "IDC"))
    res = validation.compare(validation.engineered_from_processed(ref, wrong), df, ["Power_AC", "Ia_Normalized"])
    assert res["Power_AC"]["max_abs_diff"] > 1.0
