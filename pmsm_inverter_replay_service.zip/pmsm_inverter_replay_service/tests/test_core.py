import logging
from datetime import datetime, timedelta, timezone

import pytest

from inverter_replay.config import Settings, load_settings
from inverter_replay.contract import compare_with_openapi, load_contract, validate_predict_body
from inverter_replay.logging_setup import JsonFormatter, redact
from inverter_replay.payload import validate_mapping
from inverter_replay.timeline import (TimelineError, resolve_anchor, resolve_times, spacing_issues, to_c8y_time)

UTC = timezone.utc
A = datetime(2026, 1, 1, tzinfo=UTC)


# ---- config ----
def test_no_defaults_for_secrets_or_targets(monkeypatch):
    for k in ("C8Y_BASEURL", "C8Y_USER", "C8Y_PASSWORD", "C8Y_DEVICE_ID", "C8Y_TENANT", "PUBLISH_ENABLED", "TARGET_APPROVED"):
        monkeypatch.delenv(k, raising=False)
    s = load_settings()
    assert s.c8y_base_url is None and s.c8y_user is None and s.c8y_password is None and s.c8y_device_id is None
    assert s.publish_enabled is False and s.target_approved is False
    assert s.source_interval_seconds == 0.1 and s.max_requests_per_second <= 1.0     # slower than 10 Hz by default


def test_secrets_not_in_repr_or_public_view():
    s = Settings(c8y_user="alice", c8y_password="s3cr3t-pw")
    for text in (repr(s), str(s), str(s.public_view())):
        assert "s3cr3t-pw" not in text and "alice" not in text
    assert s.public_view()["credentials_configured"] is True


def test_publish_blockers_list_every_missing_gate():
    b = " | ".join(Settings().publish_blockers("PROPOSED", None, "sensor"))
    for needle in ("PUBLISH_ENABLED", "TARGET_APPROVED", "mapping status", "selected_profile", "C8Y_BASEURL", "C8Y_USER",
                   "C8Y_DEVICE_ID", "SELECTION_MANIFEST"):
        assert needle in b


def test_publish_gates_pass_only_when_all_set():
    s = Settings(publish_enabled=True, target_approved=True, c8y_base_url="http://x", c8y_user="u", c8y_password="p",
                 c8y_device_id="1", selection_manifest="m.json")
    assert s.publish_blockers("APPROVED", "sensor", "sensor") == []
    assert any("differs" in x for x in s.publish_blockers("APPROVED", "sensor", "sensor_plus_features"))


# ---- logging ----
def test_redaction():
    assert "hunter2" not in redact('password=hunter2 token: abc123 Authorization: Basic dXNlcjpwYXNz')


def test_json_formatter_redacts_context():
    rec = logging.LogRecord("x", logging.INFO, "f", 1, "login password=zzz", None, None)
    rec.ctx = {"password": "zzz", "note": "ok"}
    out = JsonFormatter().format(rec)
    assert "zzz" not in out and "ok" in out


# ---- timeline ----
OFFS = [427_500_000 + 100_000 * i for i in range(12)]


@pytest.mark.parametrize("mode", ["start", "end"])
@pytest.mark.parametrize("policy", ["shifted", "reconstructed"])
def test_spacing_is_exactly_the_source_interval(policy, mode):
    t = resolve_times(OFFS, policy, A, mode, 0.1)
    assert all(t[i].time - t[i - 1].time == timedelta(milliseconds=100) for i in range(1, len(t)))
    assert spacing_issues(t, 0.1) == []
    assert all(x.origin == policy for x in t)
    if mode == "start":
        assert t[0].time == A
    else:
        assert t[-1].time == A


def test_reconstructed_uses_configured_interval_only():
    t = resolve_times([0, 7, 99], "reconstructed", A, "start", 0.25)
    assert [x.time - A for x in t] == [timedelta(0), timedelta(milliseconds=250), timedelta(milliseconds=500)]


def test_shifted_detects_non_uniform_source():
    t = resolve_times([0, 100_000, 300_000], "shifted", A)
    assert spacing_issues(t, 0.1)


def test_unknown_policy_and_bad_interval():
    with pytest.raises(TimelineError):
        resolve_times([0], "send_time", A)
    with pytest.raises(TimelineError):
        resolve_times([0, 1], "reconstructed", A, "start", 0)


def test_anchor_now_resolved_once_from_given_clock():
    fixed = datetime(2030, 5, 5, tzinfo=UTC)
    assert resolve_anchor("now", now=fixed) == fixed
    assert resolve_anchor("2026-01-01T03:00:00+03:00") == A


def test_to_c8y_time_millisecond_utc():
    assert to_c8y_time(datetime(2026, 1, 1, 0, 0, 0, 100999, tzinfo=UTC)) == "2026-01-01T00:00:00.100Z"


# ---- contract ----
def body(contract):
    return {n: 1.0 for n in contract["feature_order"]}


def test_predict_body_validation_mirrors_schema(contract_path):
    c = load_contract(contract_path)
    assert validate_predict_body(c, body(c)) == []
    b = body(c); b["Current_Imbalance"] = None
    assert validate_predict_body(c, b) == []
    b = body(c); b["VDC_MovingAvg"] = None
    assert "null is not allowed" in validate_predict_body(c, b)[0]
    b = body(c); b["T1"] = float("inf")
    assert "NaN or infinity" in validate_predict_body(c, b)[0]
    b = body(c); b["FDD"] = "F0"
    assert "unknown fields" in validate_predict_body(c, b)[0]
    b = body(c); b["T2"] = "1.0"
    assert "not a JSON number" in validate_predict_body(c, b)[0]
    b = body(c); b["T3"] = True
    assert "not a JSON number" in validate_predict_body(c, b)[0]
    b = body(c); del b["VD"]
    assert "missing fields" in validate_predict_body(c, b)[0]


def _openapi(contract, nullable=None, extra=False):
    nullable = contract["nullable"] if nullable is None else nullable
    props = {n: ({"anyOf": [{"type": "number"}, {"type": "null"}]} if n in nullable else {"type": "number"})
             for n in contract["feature_order"]}
    return {"components": {"schemas": {"PredictRequest": {"properties": props, "required": list(props),
                                                          "additionalProperties": extra}}}}


def test_compare_with_openapi(contract_path):
    c = load_contract(contract_path)
    assert compare_with_openapi(c, _openapi(c))["match"] is True
    r = compare_with_openapi(c, _openapi(c, nullable=["Current_Imbalance"], extra=True))
    assert not r["match"] and len(r["differences"]) == 2
    assert not compare_with_openapi(c, {"components": {"schemas": {}}})["match"]


# ---- mapping validation ----
def test_proposed_mapping_is_valid_and_proposed(contract_path):
    import json
    from conftest import MAPPING
    m = json.load(open(MAPPING))
    c = load_contract(contract_path)
    assert validate_mapping(m, c) == [] and m["status"] == "PROPOSED" and m["selected_profile"] is None
    ratio = [n for n, s in m["profiles"]["sensor_plus_features"]["series"].items()
             if n in ("Current_Imbalance", "Ia_Normalized", "Ib_Normalized")]
    assert len(ratio) == 3 and all(m["profiles"]["sensor_plus_features"]["series"][n]["unit"] is None for n in ratio)


def test_mapping_rejects_fdd_timestamp_wrong_units_and_ratio_units(contract_path):
    import copy
    import json
    from conftest import MAPPING
    base = json.load(open(MAPPING))
    c = load_contract(contract_path)
    m = copy.deepcopy(base); m["profiles"]["sensor"]["series"]["Label"] = {"source_column": "FDD", "unit": None}
    assert any("never published" in e for e in validate_mapping(m, c))
    m = copy.deepcopy(base); m["profiles"]["sensor"]["series"]["Timestamp"] = {"source_column": "Timestamp", "unit": "s"}
    assert any("never published" in e for e in validate_mapping(m, c))
    m = copy.deepcopy(base); m["profiles"]["sensor_plus_features"]["series"]["Ia_Normalized"]["unit"] = "ratio"
    assert any("ratio feature" in e for e in validate_mapping(m, c))
    m["ratio_units_approved"] = True
    assert validate_mapping(m, c) == []
    m = copy.deepcopy(base); m["profiles"]["sensor"]["series"]["T1"]["unit"] = "K"
    assert any("differs from contract unit" in e for e in validate_mapping(m, c))
    m = copy.deepcopy(base); del m["profiles"]["sensor_plus_features"]["series"]["Power_AC"]
    assert any("exactly the 18" in e for e in validate_mapping(m, c))
    m = copy.deepcopy(base); m["profiles"]["sensor"]["series"]["Power_DC"] = {"source_column": "Power_DC", "unit": "W"}
    assert any("must not publish engineered" in e for e in validate_mapping(m, c))
