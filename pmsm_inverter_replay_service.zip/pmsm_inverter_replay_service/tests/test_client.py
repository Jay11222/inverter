import logging

import pytest

from inverter_replay import c8y_client as c8y


def payload(i=1):
    return {"source": {"id": "777"}, "time": "2026-01-01T00:00:0%d.000Z" % i, "type": "T",
            "Frag": {"A": {"value": 1.5, "unit": "A"}}, "replayTrace": {"observationId": f"obs{i}"}}


def client(m, **kw):
    kw.setdefault("connect_timeout", 1.0); kw.setdefault("read_timeout", 0.3); kw.setdefault("backoff_seconds", 0.0)
    return c8y.C8yClient(m.url, "svc", "s3cr3t-pw", sleep=lambda s: None, **kw)


def test_success_single_post(mock_c8y):
    r = client(mock_c8y).post_measurement(payload(), "replayTrace")
    assert r.status == c8y.DELIVERED and len(mock_c8y.posts()) == 1


def test_4xx_not_retried(mock_c8y):
    mock_c8y.post_script = ["400"]
    r = client(mock_c8y).post_measurement(payload(), "replayTrace")
    assert r.status == c8y.REJECTED and r.http_status == 400 and "bad payload" in r.detail and len(mock_c8y.posts()) == 1


def test_429_is_retried_then_succeeds(mock_c8y):
    mock_c8y.post_script = ["429", "ok"]
    r = client(mock_c8y).post_measurement(payload(), "replayTrace")
    assert r.status == c8y.DELIVERED and r.attempts == 2 and len(mock_c8y.stored) == 1


def test_5xx_but_stored_is_reconciled_not_duplicated(mock_c8y):
    mock_c8y.post_script = ["503_stored"]
    r = client(mock_c8y).post_measurement(payload(), "replayTrace")
    assert r.status == c8y.DELIVERED_RECONCILED and len(mock_c8y.posts()) == 1 and len(mock_c8y.stored) == 1


def test_5xx_not_stored_is_retried(mock_c8y):
    mock_c8y.post_script = ["503_not_stored", "ok"]
    r = client(mock_c8y).post_measurement(payload(), "replayTrace")
    assert r.status == c8y.DELIVERED and len(mock_c8y.posts()) == 2 and len(mock_c8y.stored) == 1


def test_read_timeout_but_stored_is_not_resent(mock_c8y):
    mock_c8y.post_script = ["timeout_stored"]
    r = client(mock_c8y).post_measurement(payload(), "replayTrace")
    assert r.status == c8y.DELIVERED_RECONCILED and len(mock_c8y.posts()) == 1 and len(mock_c8y.stored) == 1


def test_connection_dropped_not_stored_is_retried(mock_c8y):
    mock_c8y.post_script = ["drop_not_stored", "ok"]
    r = client(mock_c8y).post_measurement(payload(), "replayTrace")
    assert r.status == c8y.DELIVERED and len(mock_c8y.stored) == 1


def test_lookup_failure_gives_unconfirmed_and_no_resend(mock_c8y):
    mock_c8y.post_script = ["timeout_stored"]; mock_c8y.get_meas_status = 500
    r = client(mock_c8y).post_measurement(payload(), "replayTrace")
    assert r.status == c8y.UNCONFIRMED and len(mock_c8y.posts()) == 1


def test_attempts_are_bounded(mock_c8y):
    mock_c8y.post_script = ["503_not_stored"] * 10
    r = client(mock_c8y, max_attempts=3).post_measurement(payload(), "replayTrace")
    assert r.status == c8y.FAILED and len(mock_c8y.posts()) == 3


def test_reconcile_without_trace_fragment_matches_on_values(mock_c8y):
    p = payload(); del p["replayTrace"]
    mock_c8y.post_script = ["503_stored"]
    assert client(mock_c8y).post_measurement(p, None).status == c8y.DELIVERED_RECONCILED


def test_unreachable_tenant_is_failed_quickly_not_a_crash():
    c = c8y.C8yClient("http://127.0.0.1:9", "u", "p", connect_timeout=0.5, max_attempts=2, backoff_seconds=0.0, sleep=lambda s: None)
    r = c.post_measurement(payload(), "replayTrace")
    assert r.status == c8y.FAILED and r.attempts == 2


def test_no_device_creation_api_exists():
    public = [n for n in dir(c8y.C8yClient) if not n.startswith("_")]
    assert not any("create" in n or "register" in n for n in public)
    assert set(public) == {"check_device", "find_measurement", "post_measurement"}


def test_credentials_never_logged(mock_c8y, caplog):
    caplog.set_level(logging.DEBUG)
    c = client(mock_c8y)
    mock_c8y.post_script = ["503_stored", "400"]
    c.post_measurement(payload(1), "replayTrace"); c.post_measurement(payload(2), "replayTrace")
    assert "s3cr3t-pw" not in caplog.text and "s3cr3t-pw" not in repr(c)


def test_nan_or_infinity_never_serialised(mock_c8y):
    p = payload(); p["Frag"]["A"]["value"] = float("inf")
    r = client(mock_c8y).post_measurement(p, "replayTrace")
    assert r.status != c8y.DELIVERED and not mock_c8y.stored          # requests refuses non-finite JSON
