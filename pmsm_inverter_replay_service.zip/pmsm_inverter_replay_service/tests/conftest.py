"""Synthetic fixtures only: no real dataset rows are used in tests."""
import csv
import json
import math
import random
import threading
import time
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from inverter_replay.config import Settings
from inverter_replay.dataset import REQUIRED_COLUMNS

REPO = Path(__file__).resolve().parent.parent
MAPPING = str(REPO / "config" / "mapping.proposed.json")
CONTRACT = str(REPO / "config" / "model_contract.json")
CLASS_SIZES = {"F0": 120, "F1": 80, "F2": 90}          # 290 rows, three contiguous blocks
INF_IMBALANCE_ROW = 25                                  # Ia_a + Ib_a == 0 -> Current_Imbalance +inf
INF_NORMALIZED_ROW = 33                                 # IDC_a == 0 -> normalized currents +/-inf
REPEAT_ROW = 50                                         # repeats the sensor combination of row 49


def _cur(adc):            # same formulas as data_conversion_script_v4.py
    return ((adc / 1023) * 5 - 2.5) / 0.100


def _ard(adc):
    return 0.074 * (adc - 512)


def _volt(adc):
    return (((adc / 1023) * 5 - 2.5) / 0.100) * 100


def _temp(adc):
    r = 10000 / ((1023 / adc) - 1)
    ln = math.log(r)
    return 1 / (1.2666e-3 + 2.3661e-4 * ln + 9.6094e-8 * ln ** 3) - 273.15


def _div(a, b):
    if b == 0:
        return math.nan if a == 0 else math.copysign(math.inf, a)
    return a / b


def _txt(v):
    if isinstance(v, str):
        return v
    if math.isnan(v):
        return ""
    if math.isinf(v):
        return "inf" if v > 0 else "-inf"
    return repr(v)


def make_rows(seed=7):
    rnd = random.Random(seed)
    labels = [c for c, n in CLASS_SIZES.items() for _ in range(n)]
    raw = []
    for i, lab in enumerate(labels):
        ia, ib = rnd.randint(430, 600), rnd.randint(430, 600)
        idc = rnd.randint(500, 516)
        if idc == 512:
            idc = 511
        if ia + ib == 1024:                              # avoid accidental zero denominators
            ib += 1
        if i == INF_IMBALANCE_ROW:
            ia, ib = 560, 464                            # (560-512) == -(464-512)
        if i == INF_NORMALIZED_ROW:
            idc = 512
        r = {"Ia": ia, "Ib": ib, "VDC": rnd.randint(495, 512), "IDC": idc, "T1": rnd.randint(480, 520),
             "T2": rnd.randint(480, 520), "T3": rnd.randint(470, 510), "VD": rnd.randint(495, 515), "FDD": lab}
        if i == REPEAT_ROW:
            r = dict(raw[-1], FDD=lab)
        raw.append(r)
    out = []
    vdcs, idcas = [], []
    for i, r in enumerate(raw):
        ia_a, ib_a, idc_a = _ard(float(r["Ia"])), _ard(float(r["Ib"])), _ard(float(r["IDC"]))
        vdc, vd = _volt(float(r["VDC"])), _volt(float(r["VD"]))
        t = [_temp(float(r[k])) for k in ("T1", "T2", "T3")]
        vdcs.append(vdc); idcas.append(idc_a)
        row = {"Ia": float(r["Ia"]), "Ib": float(r["Ib"]), "VDC": vdc, "IDC": float(r["IDC"]), "T1": t[0], "T2": t[1],
               "T3": t[2], "VD": vd, "FDD": r["FDD"], "Timestamp": 0.0 + i * 0.1,
               "Ia_original": _cur(float(r["Ia"])), "Ia_arduino": ia_a, "Ib_original": _cur(float(r["Ib"])),
               "Ib_arduino": ib_a, "IDC_original": _cur(float(r["IDC"])), "IDC_arduino": idc_a,
               "Power_DC": vdc * idc_a, "Power_AC": vd * (ia_a + ib_a),
               "Current_Imbalance": _div(abs(ia_a - ib_a), (ia_a + ib_a) / 2),
               "Temp_Diff_Max": max(t) - min(t), "Ia_Normalized": _div(ia_a, idc_a), "Ib_Normalized": _div(ib_a, idc_a),
               "VDC_RateOfChange": math.nan if i == 0 else (vdc - vdcs[i - 1]) / 0.1,
               "IDC_RateOfChange": math.nan if i == 0 else (idc_a - idcas[i - 1]) / 0.1,
               "VDC_MovingAvg": math.nan if i < 9 else sum(vdcs[i - 9:i + 1]) / 10,
               "IDC_MovingAvg": math.nan if i < 9 else sum(idcas[i - 9:i + 1]) / 10}
        out.append(row)
    return out


def write_csv(path, rows):
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(REQUIRED_COLUMNS)
        for r in rows:
            w.writerow([_txt(r[c]) for c in REQUIRED_COLUMNS])
    return str(path)


def read_text_cells(path):
    with open(path, newline="") as fh:
        rows = list(csv.reader(fh))
    return rows[0], rows[1:]


@pytest.fixture
def dataset_csv(tmp_path):
    return write_csv(tmp_path / "converted_dataset.csv", make_rows())


@pytest.fixture
def dataset_zip(tmp_path, dataset_csv):
    p = tmp_path / "PMSM-inverter-fault-diagnosis-3.0.zip"
    with zipfile.ZipFile(p, "w") as z:
        z.write(dataset_csv, "PMSM-inverter-fault-diagnosis-3.0/processed_data/converted_dataset.csv")
        z.writestr("PMSM-inverter-fault-diagnosis-3.0/README.md", "synthetic")
    return str(p)


@pytest.fixture
def contract_path(tmp_path):
    c = json.loads(Path(CONTRACT).read_text())
    c["training_class_counts"] = None          # synthetic data: nothing to verify against
    p = tmp_path / "contract.json"; p.write_text(json.dumps(c))
    return str(p)


@pytest.fixture
def settings(tmp_path, dataset_csv, contract_path):
    import hashlib
    sha = hashlib.sha256(Path(dataset_csv).read_bytes()).hexdigest()
    return Settings(dataset_path=dataset_csv, expected_dataset_sha256=sha, output_dir=str(tmp_path / "runs"),
                    mapping_path=MAPPING, contract_path=contract_path, pace_mode="asap",
                    max_requests_per_second=1000.0, anchor_time="2026-01-01T00:00:00Z")


class MockC8y:
    """Local stand-in for Cumulocity (copied from the Battery/Transformer service tests). Records every request."""

    def __init__(self):
        self.requests = []
        self.auth_seen = []
        self.stored = []
        self.post_script = []
        self.get_meas_status = 200
        self.device_status = 200
        self.slow_seconds = 1.0
        outer = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def _json(self, code, obj):
                body = json.dumps(obj).encode()
                self.send_response(code); self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

            def do_GET(self):
                outer.requests.append(("GET", self.path)); outer.auth_seen.append(self.headers.get("Authorization"))
                if self.path.startswith("/inventory/managedObjects/"):
                    return self._json(outer.device_status, {"id": "1"} if outer.device_status == 200 else {"message": "nf"})
                if self.path.startswith("/measurement/measurements"):
                    if outer.get_meas_status != 200:
                        return self._json(outer.get_meas_status, {"message": "boom"})
                    return self._json(200, {"measurements": outer.stored})
                self._json(404, {})

            def do_POST(self):
                outer.requests.append(("POST", self.path)); outer.auth_seen.append(self.headers.get("Authorization"))
                n = int(self.headers.get("Content-Length", 0)); raw = self.rfile.read(n) or b"{}"
                body = json.loads(raw)
                action = outer.post_script.pop(0) if outer.post_script else "ok"
                if action == "ok":
                    outer.stored.append(body); return self._json(201, body)
                if action == "429":
                    return self._json(429, {"message": "slow down"})
                if action == "400":
                    return self._json(400, {"message": "bad payload"})
                if action == "503_not_stored":
                    return self._json(503, {"message": "unavailable"})
                if action == "503_stored":
                    outer.stored.append(body); return self._json(503, {"message": "unavailable"})
                if action == "timeout_stored":
                    outer.stored.append(body); time.sleep(outer.slow_seconds); return
                if action == "drop_not_stored":
                    self.connection.close(); return
                self._json(500, {})

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def posts(self):
        return [r for r in self.requests if r[0] == "POST"]

    def close(self):
        self.server.shutdown(); self.server.server_close()


@pytest.fixture
def mock_c8y():
    m = MockC8y()
    yield m
    m.close()
