import hashlib
import json
import math
from pathlib import Path

import pytest

from conftest import (CLASS_SIZES, INF_IMBALANCE_ROW, INF_NORMALIZED_ROW, REPEAT_ROW, make_rows, read_text_cells,
                      write_csv)
from inverter_replay.contract import load_contract
from inverter_replay.dataset import (P_CV, P_PURGE, P_TEST, P_TRAIN, P_VAL, DatasetError, load_dataset, parse_value,
                                     timestamp_to_us)


@pytest.fixture
def ds(dataset_csv, contract_path):
    return load_dataset(dataset_csv, load_contract(contract_path))


def test_values_parsed_exactly_from_text(ds, dataset_csv):
    header, body = read_text_cells(dataset_csv)
    for r in ds.rows:
        for c, v in r.values.items():
            t = body[r.index][header.index(c)]
            if t in ("", "inf", "-inf"):
                assert not math.isfinite(v)
            else:
                assert repr(v) == t                    # bit for bit
    assert ds.text_roundtrip_mismatches == 0


def test_parse_value_and_timestamp_exact():
    assert parse_value("") != parse_value("")          # NaN
    assert parse_value("inf") == math.inf and parse_value("-inf") == -math.inf
    assert parse_value("4.0123951234567891") == 4.0123951234567891
    assert timestamp_to_us("0.30000000000000004") == 300000
    assert timestamp_to_us("1089.1000000000001") == 1089100000
    assert timestamp_to_us("385.2000000000001") == 385200000


def test_class_blocks_and_partition_reproduction(ds):
    assert [(b.label, b.rows) for b in ds.blocks] == list(CLASS_SIZES.items())
    assert ds.partition_reproduced
    for b in ds.blocks:
        n = b.rows
        n_test = math.floor(0.2 * n)
        rows = ds.rows[b.start:b.end + 1]
        assert [r.partition for r in rows[n - n_test:]] == [P_TEST] * n_test
        cv_end = n - n_test - 10
        size = cv_end // 4
        train = [r.index - b.start for r in rows if r.partition == P_TRAIN]
        val = [r.index - b.start for r in rows if r.partition == P_VAL]
        assert train == list(range(2 * size, 3 * size - 10))
        assert val == list(range(3 * size + 10, cv_end))
        assert {r.partition for r in rows} <= {P_TRAIN, P_VAL, P_TEST, P_CV, P_PURGE}


def test_partition_verification_against_metadata_counts(dataset_csv, contract_path, tmp_path):
    c = load_contract(contract_path)
    c["training_class_counts"] = {"F0": 1}
    ds = load_dataset(dataset_csv, c)
    assert "differ" in ds.partition_note


def test_model_readiness_and_null_rules(ds):
    assert [r.index for r in ds.rows if not r.model_ready] == list(range(9))          # rolling features NaN
    assert ds.rows[INF_IMBALANCE_ROW].null_features == ["Current_Imbalance"] and ds.rows[INF_IMBALANCE_ROW].model_ready
    assert ds.rows[INF_NORMALIZED_ROW].null_features == ["Ia_Normalized", "Ib_Normalized"]


def test_flags_never_alter_values(ds, dataset_csv):
    r = ds.rows[REPEAT_ROW]
    assert "repeated_sensor_combination" in r.flags
    assert any(f == "negative_VDC" for f in ds.rows[0].flags) or ds.rows[0].values["VDC"] >= 0
    first_f1 = CLASS_SIZES["F0"]
    assert all(ds.rows[i].boundary_crossing for i in range(first_f1, first_f1 + 9))
    assert not ds.rows[first_f1 + 9].boundary_crossing and not ds.rows[first_f1 - 1].boundary_crossing
    header, body = read_text_cells(dataset_csv)
    assert repr(r.values["VDC"]) == body[REPEAT_ROW][header.index("VDC")]


def test_range_flags_one_ulp_labelled(dataset_csv, contract_path):
    c = load_contract(contract_path)
    rows = make_rows()
    v = rows[40]["T1"]
    for f in c["features"]:
        if f["name"] == "T1":
            f["observed_range_full_dataset"] = [f["observed_range_full_dataset"][0], math.nextafter(v, -math.inf)]
            f["observed_range_training_window"] = [-1e9, 1e9]
    ds = load_dataset(dataset_csv, c)
    assert "outside_observed_range_1ulp:T1" in ds.rows[40].flags


def test_zip_source_read_in_place(dataset_zip, dataset_csv, contract_path):
    before = hashlib.sha256(Path(dataset_zip).read_bytes()).hexdigest()
    z = load_dataset(dataset_zip, load_contract(contract_path))
    c = load_dataset(dataset_csv, load_contract(contract_path))
    assert z.sha256 == c.sha256 and z.source_kind == "zip" and z.archive_sha256 == before
    assert hashlib.sha256(Path(dataset_zip).read_bytes()).hexdigest() == before


def test_missing_column_and_bad_label_rejected(tmp_path, contract_path):
    rows = make_rows()
    p = write_csv(tmp_path / "x.csv", rows)
    text = Path(p).read_text().replace("Power_DC", "PowerDC", 1)
    Path(p).write_text(text)
    with pytest.raises(DatasetError, match="missing required columns"):
        load_dataset(p, load_contract(contract_path))
    rows[3]["FDD"] = "F9"
    p2 = write_csv(tmp_path / "y.csv", rows)
    with pytest.raises(DatasetError, match="unexpected FDD"):
        load_dataset(p2, load_contract(contract_path))


def test_dataset_summary_has_no_rows(ds):
    s = json.dumps(ds.summary())
    assert "values" not in s and len(s) < 5000
