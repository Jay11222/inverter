# Feature reproducibility report

The replay never calculates or alters a published value. This report only validates that the 10 engineered features stored in `converted_dataset.csv` can be rebuilt from the sensor channels, using the model repository's `app/feature_engineering.py` as the reference (imported read-only from the repository, not edited, not copied into this project).

Command (Python 3.13, numpy 2.5.2, pandas 3.0.5 as in the model repo):

```bash
python -m inverter_replay.validation --dataset processed_data/converted_dataset.csv \
  --reference-module PMSMInverter/app/feature_engineering.py --raw-csv raw_data/dataset_CSV.csv --out report.json
```

Inputs (SHA-256, all unchanged after the run): dataset `134d1e0abbcdbabcaf2fc7c02f95b4bf8d90bb8c3d1b7f97f66b7c807318288f`, reference module `9392bafebd3c250c97b9e9dc1b1af9b261a0127709acfc8706e9bab1ab0f6fb9`, raw file `acfd0f89d4589db103ae8cc0af5b64726196fb49460da90e9054d042b642736b`. Parsing is exact (`float_precision="round_trip"`).

## Result: reproduced exactly

| Feature | Processed mode: max abs diff | Raw mode: max abs diff | Rows compared |
|---|---|---|---|
| Power_DC | 0.0 | 0.0 | 10,892 |
| Power_AC | 0.0 | 0.0 | 10,892 |
| Current_Imbalance | 0.0 | 0.0 | 10,871 (21 infinite, same positions and signs) |
| Ia_Normalized | 0.0 | 0.0 | 10,878 (14 infinite, same positions and signs) |
| Ib_Normalized | 0.0 | 0.0 | 10,878 (14 infinite, same positions and signs) |
| VDC_RateOfChange | 0.0 | 0.0 | 10,891 (row 0 NaN in both) |
| IDC_RateOfChange | 0.0 | 0.0 | 10,891 (row 0 NaN in both) |
| VDC_MovingAvg | 0.0 | 0.0 | 10,883 (rows 0 to 8 NaN in both) |
| IDC_MovingAvg | 0.0 | 0.0 | 10,883 (rows 0 to 8 NaN in both) |
| Temp_Diff_Max | 0.0 | 0.0 | 10,892 |

Raw mode also reproduces the 8 sensor features (`Ia_original`, `Ib_original`, `VDC`, `IDC_original`, `T1`, `T2`, `T3`, `VD`) with max difference 0.0.

- **Processed mode** uses only the processed file: Arduino-calibrated currents from the ADC columns `Ia`, `Ib`, `IDC` (`ref.arduino_acs712_current`), `VDC`, `VD`, `T1..T3` as stored, and the reference constants (`SAMPLE_PERIOD_S = 0.1`, `MOVING_AVG_WINDOW = 10`).
- **Raw mode** runs `ref.compute_features()` unchanged on the raw 8-channel ADC stream.

## Calibration note

Rebuilding the features from `*_original` (the values the model receives) instead of the Arduino calibration does **not** reproduce them: Power_AC differs by up to 216.7 W, Power_DC by 15.0 W, Ia/Ib_Normalized by up to 134, IDC_MovingAvg by 0.24 A, and the non-finite positions change. This is why the `sensor` profile proposes publishing the three ADC counts. The test suite contains a test for this case and the mutation check confirms it fails when the calibration is swapped.

## Parsing note

Reading the CSV with pandas' default float parser changes 57,404 cells by 1 ulp. With that parser the comparison above would show differences of about 1e-15 instead of 0.0. The model notebook and the export script used the default parser (Data Science item in `OPEN_ITEMS.md`).
