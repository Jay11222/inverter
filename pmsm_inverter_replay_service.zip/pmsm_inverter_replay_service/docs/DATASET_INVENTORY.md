# Dataset inventory (read-only, aggregates only)

Generated with `python -m inverter_replay.inventory --dataset PMSM-inverter-fault-diagnosis-3.0.zip --model-repo PMSMInverter`. No dataset rows are reproduced here. The SHA-256 of all 33 inputs (the archive, its 25 members and 7 repository files) was identical before and after, so nothing was modified. The full inspection is in `INSPECTION_REPORT.md`.

| Input | SHA-256 |
|---|---|
| `PMSM-inverter-fault-diagnosis-3.0.zip` (Zenodo 14482932, md5 `828b25aa7fc9247614634d501956a16b` as published) | `88d8940ef9606fbb2aaec888e5b08596fe618600e83879fbaf7dfe8763cd6e83` |
| `processed_data/converted_dataset.csv` (identical in the zip and in the model repo; equals `model_metadata.json`) | `134d1e0abbcdbabcaf2fc7c02f95b4bf8d90bb8c3d1b7f97f66b7c807318288f` |
| `raw_data/dataset_CSV.csv` | `acfd0f89d4589db103ae8cc0af5b64726196fb49460da90e9054d042b642736b` |
| `code/data_conversion_script_v4.py` | `30c916565529851f483bbed5842c5ffbae3d04b3623d16eec1a0afe622cfcff1` |
| repo `artifacts/feature_schema.json` | `99c4ed6449c4711d41bdadd7e2547934cac7cd3fe9640135f80a2e2b2cceb470` |
| repo `artifacts/model_metadata.json` | `eea1c9e0105b703126cb8bd3320def2d847845e4a61749e83257043ffbe70e7a` |
| repo `app/schemas.py` | `d8101e7c060e55291088cb30e484d74930d33b67dfef1945556bba504f4077ac` |
| repo `app/feature_engineering.py` | `9392bafebd3c250c97b9e9dc1b1af9b261a0127709acfc8706e9bab1ab0f6fb9` |
| repo `samples/expected_predictions.json` | `710ebb4d243aa8af0745617fd8e7a5d4cf4bf58ba878829a73c89e418608fa72` |

## converted_dataset.csv

- 10,892 rows, 26 columns. Parsed exactly; every finite value's `repr` equals its text (0 mismatches).
- Nine contiguous class blocks in order: F0 0 to 4294 (4,295), F1 4295 to 4986 (692), F2 4987 to 6108 (1,122), F3 6109 to 6515 (407), F4 6516 to 6856 (341), F5 6857 to 7268 (412), F6 7269 to 8122 (854), F7 8123 to 9857 (1,735), F8 9858 to 10891 (1,034).
- `Timestamp`: `np.arange(0, n*0.1, 0.1)` from row position (first `0.0`, last `1089.1000000000001`). In exact microseconds every step is 100,000 us and equals row index x 0.1 s. No acquisition date.
- ADC columns are integers within 0..1023: Ia 350 to 651, Ib 355 to 647, IDC 488 to 517.
- Non-finite values: 20 NaN (VDC/IDC_RateOfChange row 0; VDC/IDC_MovingAvg rows 0 to 8) and 49 infinities (Current_Imbalance 21; Ia_Normalized and Ib_Normalized 14 each, same rows), in 44 rows.
- Model readiness under the API contract: 10,883 rows model-ready (35 of them need a `null` ratio feature), 9 not (rows 0 to 8).
- 72 rows have stored rolling features that cross a class boundary (first 9 rows of F1 to F8).
- Review flags (rows): negative VDC 10,856; negative VD 10,721; repeated 8-sensor combination 17; at least one feature outside the training-window range 272 (299 feature flags); 8 values 1 ulp outside the schema's full-dataset range (the schema ranges were computed with pandas' default parser).
- Reproduced notebook split: final training 2,064 (class counts equal `model_metadata.json`), final validation 2,075, held-out test 2,175, CV development only 4,308, purge gaps 270.

## Raw recordings (raw_data)

Each class is a separate recording with a time of day per row (no date), made in the order F0, F1, F2, F6, F7, F8, F3, F4, F5, separated by 83 to 1,413 s. Values equal the processed blocks. Real intervals are 66 to 137 ms (median 101 ms). F6 contains a 3.9 s gap followed by 37 rows with one time stamp (processed rows 7415 to 7453). The service does not read the raw files.
