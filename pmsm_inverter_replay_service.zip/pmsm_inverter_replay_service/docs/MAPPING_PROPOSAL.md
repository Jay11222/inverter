# Cumulocity mapping proposal: PMSM inverter (for approval by the Software / Cumulocity team)

Status: **PROPOSED**. The service refuses to publish until `config/mapping.proposed.json` carries `"status": "APPROVED"` and `selected_profile` names one profile. Nothing has been sent to any tenant.

## Measurement

| Item | Proposed value | Note |
|---|---|---|
| Measurement `type` | `ElectricalAssets_PMSMInverterTelemetry` | follows the Battery/Transformer naming; needs approval |
| Fragment | `PMSMInverter` | one fragment, one series per channel |
| Observation | one dataset row = one measurement, all series at one `time` | |
| Units | taken from `artifacts/feature_schema.json` exactly (`A`, `V`, `degC`, `W`, `V/s`, `A/s`) | `degC` is written as in the schema; confirm whether the tenant prefers another spelling |
| Ratio features | **no unit** (schema says `dimensionless`) | `Current_Imbalance`, `Ia_Normalized`, `Ib_Normalized`; set `ratio_units_approved: true` only if the team approves a unit |
| ADC counts | no unit | raw 10-bit counts 0..1023 |

## Profile `sensor` (represents the real device)

| Series | Source column | Unit |
|---|---|---|
| `Ia_original`, `Ib_original`, `IDC_original` | same | A |
| `VDC`, `VD` | same | V |
| `T1`, `T2`, `T3` | same | degC |
| `Ia_adc`, `Ib_adc`, `IDC_adc` | `Ia`, `Ib`, `IDC` | none |

Why the three ADC counts: the engineered features use the Arduino calibration `X_a = 0.074 x (ADC - 512)`, not the `*_original` values the model receives (different offset and scale). With the ADC counts upstream rebuilds all 10 features exactly (max difference 0.0, see `FEATURE_REPRODUCIBILITY.md`). Applying the formulas to `*_original` instead gives errors up to 216.7 W in `Power_AC`. Without the ADC counts (option B) upstream must invert `*_original` and round, which is exact for this dataset but an implicit step. To choose option B, delete the three `*_adc` series from the mapping. Decision: Data Science and Mudhawi.

## Profile `sensor_plus_features` (inference path before the upstream pipeline exists)

The 18 model features under their model names, in model order: the 8 sensor series above plus `Power_DC` (W), `Power_AC` (W), `Current_Imbalance`, `Ia_Normalized`, `Ib_Normalized` (no unit), `VDC_RateOfChange` (V/s), `IDC_RateOfChange` (A/s), `VDC_MovingAvg` (V), `IDC_MovingAvg` (A), `Temp_Diff_Max` (degC). A `/predict` body is formed by taking each feature from the series of the same name; a missing (omitted) nullable series becomes `null`.

## Non-finite values

NaN and infinity are not valid JSON numbers. With `NONFINITE_POLICY=omit` the series is left out of that measurement and named in `replayTrace.omittedSeries` (for example `Current_Imbalance:+inf`). Nothing is substituted. In the full file this affects only the `sensor_plus_features` profile: 35 rows lose one or two nullable ratio series (allowed as `null` by the model) and rows 0 to 8 lose rolling features (not model-ready).

## Traceability fragment `replayTrace`

| Field | Meaning |
|---|---|
| `runId`, `observationId` | run and stable observation ID (`pmsm-<dataset hash 12>-r<row>`) |
| `datasetSha256` | first 16 hex characters of the dataset hash |
| `rowIndex`, `selectionIndex` | 0-based row in the file and position in the selection |
| `sourceTimestamp` | original `Timestamp` text (relative seconds, not a date) |
| `timeOrigin` | `shifted` or `reconstructed` |
| `profile` | `sensor` or `sensor_plus_features` |
| `omittedSeries` | comma-separated `series:kind`, empty when none |
| `reviewFlags` | comma-separated review flags, empty when none |

Question for the team: does the tenant accept a non-series custom fragment? If not, set `trace_fragment.enabled` to `false`; duplicate reconciliation then matches on time and values.

## Never published

`FDD` (reference label), `Timestamp` (relative index), partition membership, model predictions.

## Example (dry run, device ID and run ID are placeholders)

See `docs/samples/sample_sensor_plus_features.json` and `docs/samples/sample_sensor.json`.
