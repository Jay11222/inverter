# PMSM Inverter Telemetry Replay: Inspection Report (Phase 1, v2)

Status: **COMPLETE (2026-10-15).** Implementation followed as a standalone service (see section 12 note).
Date: 2026-10-15. Author: Jayan (prepared with Claude).
Scope: the replay only publishes telemetry. It never calls the model, never builds model requests and never stores predictions.
Inspection scripts (read-only, analysis only) and their machine-readable results are delivered separately in the handoff bundle (`inspection/`), not in this service.

## 0. Summary

| # | Check | Status |
|---|---|---|
| 1 | Input inventory, hashes before and after | PASS (97 files, unchanged) |
| 2 | Zenodo 14482932 file vs repo training copy | PASS (byte-identical) |
| 3 | Rows per class, nine consecutive blocks | PASS |
| 4 | Timestamp generation | PASS (synthetic row index), with a timing finding |
| 5 | Sensor columns vs raw data, ADC integers 0..1023 | PASS |
| 6 | Recompute 10 engineered features with `app/feature_engineering.py` | PASS (max difference 0.0 for all 18) |
| 7 | Columns needed to rebuild all 18 features | NEEDS CONFIRMATION (decision, evidence complete) |
| 8 | NaN, infinity, boundary rows | PASS (all report figures confirmed) |
| 9 | Held-out partition and reference cases | PASS for partition; reference cases NEEDS CONFIRMATION (last-bit differences) |
| 10 | CSV parsing precision | **NEW FINDING**: the replay must parse exactly |
| 11 | Raw recordings have real time of day | **NEW FINDING**: class boundaries are splices, not fault onsets |
| 12 | Reference replay service fit | PASS (72/72 tests), small shared-code changes needed |

## 1. Input inventory

**Found.** All inputs locked read-only, SHA-256 recorded before and after; no change in 97 files (`inputs_sha256_before.txt`, `inputs_sha256_after.txt`). No `__pycache__` written into inputs.

| Input | SHA-256 |
|---|---|
| `PMSM-inverter-fault-diagnosis-3.0.zip` (md5 `828b25aa7fc9247614634d501956a16b`, **matches Zenodo 14482932**) | `88d8940ef9606fbb2aaec888e5b08596fe618600e83879fbaf7dfe8763cd6e83` |
| `PMSMInverter-main` zip | `76a3eebee3db9da9c436cccd55fd54c064a41667ac8aa18b56ee2ab6abcf1b43` |
| `processed_data/converted_dataset.csv` (both copies) | `134d1e0abbcdbabcaf2fc7c02f95b4bf8d90bb8c3d1b7f97f66b7c807318288f` |
| `raw_data/dataset_CSV.csv` | `acfd0f89d4589db103ae8cc0af5b64726196fb49460da90e9054d042b642736b` |
| `code/data_conversion_script_v4.py` | `30c916565529851f483bbed5842c5ffbae3d04b3623d16eec1a0afe622cfcff1` |
| `app/feature_engineering.py` | `9392bafebd3c250c97b9e9dc1b1af9b261a0127709acfc8706e9bab1ab0f6fb9` |
| `app/schemas.py` | `d8101e7c060e55291088cb30e484d74930d33b67dfef1945556bba504f4077ac` |
| `artifacts/feature_schema.json` | `99c4ed6449c4711d41bdadd7e2547934cac7cd3fe9640135f80a2e2b2cceb470` |
| `artifacts/model_metadata.json` | `eea1c9e0105b703126cb8bd3320def2d847845e4a61749e83257043ffbe70e7a` |
| `samples/expected_predictions.json` | `710ebb4d243aa8af0745617fd8e7a5d4cf4bf58ba878829a73c89e418608fa72` |

Still not supplied: deployed model OpenAPI and the Cumulocity OpenAPI spec. The contract checks below use `app/schemas.py` and `feature_schema.json`.

## 2. Dataset copy vs training copy

**Found.** Zenodo `converted_dataset.csv` and repo `processed_data/converted_dataset.csv` are byte-identical (same SHA-256), and that hash equals `model_metadata.json` `dataset.sha256`. The record-number difference (report cites 13974503, earlier version) does not affect this file.
**Status.** PASS. Data Science only needs to acknowledge the record number in the report.

## 3. Rows per class

**Found.** 10,892 rows, 26 columns. Nine contiguous blocks in order F0 to F8: F0 0 to 4294 (4,295), F1 4295 to 4986 (692), F2 4987 to 6108 (1,122), F3 6109 to 6515 (407), F4 6516 to 6856 (341), F5 6857 to 7268 (412), F6 7269 to 8122 (854), F7 8123 to 9857 (1,735), F8 9858 to 10891 (1,034). Matches the report and `metadata/fault_definitions.csv`.
**Status.** PASS.

## 4. Timestamp

**Found.** The conversion script sets `df['Timestamp'] = pd.Series(np.arange(0, len(df) * 0.1, 0.1))`, from row position only. Parsed exactly, every stored value is bit-identical to that `np.arange` (length 10,892, no off-by-one). It is not exact tenths: 3,822 values carry float noise (for example the last value is `1089.1000000000001`); the maximum deviation from index x 0.1 is 1e-13 s, and rounding to one decimal always gives index x 0.1.
**Consequence for the replay.** Measurement times are built as anchor + (row index - first index) x 100 ms, using integer milliseconds, never by subtracting stored floats. The stored text goes unchanged into the trace fragment.
**Status.** PASS.

## 5. Sensor columns vs raw data

**Found.**
- `raw_data/dataset_CSV.csv` (10,892 rows, raw ADC for all 8 channels plus FDD) is the script input. FDD sequence identical.
- All raw ADC values are integers within 0..1023 (Ia 350..651, Ib 355..647, VDC 494..518, IDC 488..517, T1 281..554, T2 357..542, T3 317..533, VD 494..523).
- Processed `Ia`, `Ib`, `IDC` equal the raw ADC (stored as floats like `532.0`, all integer-valued).
- Applying the script's functions to the raw ADC reproduces `*_original`, `*_arduino`, `VDC`, `VD`, `T1`, `T2`, `T3` **bit for bit** (exact parsing).
- The processed file does not carry raw ADC for VDC, VD, T1, T2, T3; only `raw_data/dataset_CSV.csv` does.

**Status.** PASS.

## 6. Feature reproducibility

**Found.** `app/feature_engineering.compute_features` (imported from the read-only repo, unedited) applied to the raw ADC stream reproduces all 18 model columns with **maximum absolute difference 0.0** and identical NaN and infinity positions (including sign). The handover's "within 1e-12" claim holds, and the result is in fact exact.

| Feature | Max abs diff | Finite rows compared |
|---|---|---|
| Power_DC, Power_AC, Temp_Diff_Max | 0.0 | 10,892 |
| Current_Imbalance | 0.0 | 10,871 |
| Ia_Normalized, Ib_Normalized | 0.0 | 10,878 |
| VDC_RateOfChange, IDC_RateOfChange | 0.0 | 10,891 |
| VDC_MovingAvg, IDC_MovingAvg | 0.0 | 10,883 |

My v1 note that the formula did not reproduce `Ib_original` was caused by parsing, not by the formula (section 10).
**Status.** PASS. This becomes the feature reproducibility report deliverable.

## 7. Columns needed to rebuild the 18 features

**Found.** Engineered currents use `X_a = 0.074 x (ADC - 512)`; the model receives `X_original = ((ADC/1023)*5 - 2.5)/0.1`. Tested three ways of computing the engineered features from what could be published:

| Inputs used | Result |
|---|---|
| 8 model sensors + `Ia`, `Ib`, `IDC` ADC counts (Arduino calibration applied) | exact (0.0) for all 10 |
| 8 model sensors + `*_arduino` columns | exact (0.0) for all 10 |
| 8 model sensors only, applying the formulas to `*_original` (naive) | **wrong**: Power_AC off by up to 216.7 W, Power_DC 15.0 W, Ia/Ib_Normalized up to 134, IDC_MovingAvg 0.24 A, Current_Imbalance unbounded, non-finite positions differ |
| 8 model sensors only, recovering ADC by `round((x*0.1+2.5)/5*1023)` | exact; inversion error before rounding is at most 5.7e-14 counts, so rounding is exact for all rows |

Also, `compute_features` itself takes **all 8 raw ADC channels**, which are not in the processed file.

**Options for the `sensor` profile** (decision for Data Science and Mudhawi):
- **A (proposed):** 8 model sensor values + 3 ADC counts `Ia`, `Ib`, `IDC` from the processed file. Exact; integers; no inversion upstream.
- B: 8 model sensor values only; upstream must invert and round. Exact today, but a fragile implicit step.
- C: publish all 8 raw ADC counts from `raw_data/dataset_CSV.csv` so upstream can run `compute_features` unchanged. Closest to a real Arduino device, but then the published sensor series are not the model's 8 values and the replay reads a second file.

**Status.** NEEDS CONFIRMATION (evidence complete).

## 8. Non-finite values and boundary rows

**Found (all report figures confirmed).**
- 20 NaN in rows 0 to 8 (VDC/IDC_RateOfChange row 0; VDC/IDC_MovingAvg rows 0 to 8).
- 49 infinities in 35 rows: Current_Imbalance 21 (all +inf), Ia_Normalized 14 (8 +inf, 6 -inf), Ib_Normalized 14 (4 +inf, 10 -inf); the same 14 rows for both normalized currents. No row has both NaN and infinity; 44 rows in total. Infinite rows by class: F0 19, F7 11, F8 2, F2 1, F3 1, F6 1.
- Model readiness under the API contract (only the three ratio features may be `null`): **10,883 model-ready rows** (35 of them need a `null`), **9 not model-ready** (rows 0 to 8).
- Boundary crossing: 72 rows (first 9 rows of each class F1 to F8) have moving-average windows spanning two classes; the 8 rate-of-change crossings are inside those 72.
- Flags for review: VDC negative in 10,856 rows and VD in 10,721 (nearly all rows, so this is a dataset-level polarity question, not a per-row anomaly); 17 rows repeat an earlier 8-sensor combination; 0 exact duplicates excluding Timestamp; 272 rows have at least one feature outside the **training-window** range in `feature_schema.json`.
- Range caveat: with exact parsing, 8 values sit **1 ulp outside** the schema's `observed_range_full_dataset` (the schema ranges were computed with pandas' default parser). The replay will flag against both ranges but report which flags are 1-ulp artifacts.

**Status.** PASS.

## 9. Held-out partition and reference cases

**Found.** The notebook split (copied verbatim) reproduces the metadata exactly: final training 2,064 rows with class counts equal to `model_metadata.json`, final validation 2,075, held-out test 2,175, CV-only development 4,308, purge gaps 270. Held-out rows are contiguous per class:

| Class | Final-model training | Final-model validation | Held-out test |
|---|---|---|---|
| F0 | 1712 to 2557 | 2578 to 3425 | 3436 to 4294 |
| F1 | 4567 to 4692 | 4713 to 4838 | 4849 to 4986 |
| F2 | 5431 to 5642 | 5663 to 5874 | 5885 to 6108 |
| F3 | 6267 to 6335 | 6356 to 6424 | 6435 to 6515 |
| F4 | 6646 to 6700 | 6721 to 6778 | 6789 to 6856 |
| F5 | 7017 to 7086 | 7107 to 7176 | 7187 to 7268 |
| F6 | 7605 to 7762 | 7783 to 7942 | 7953 to 8122 |
| F7 | 8811 to 9144 | 9165 to 9500 | 9511 to 9857 |
| F8 | 10266 to 10459 | 10480 to 10675 | 10686 to 10891 |

All 72 boundary rows and all 9 not-model-ready rows are CV-only development rows. Held-out test contains 7 rows with infinite ratio features.

**Reference cases.** All 11 cases in `samples/expected_predictions.json` sit at their stated rows, are in the held-out test partition, have the right true label, and none is a boundary row (ref-10 has `Current_Imbalance = null`). But **no case matches the file text bit for bit**: each differs in 2 to 7 features by 1 to 6 ulps. With pandas' default parser on this machine, 5 of 11 match exactly. So the export ran on a platform whose default parse differs from this one (section 10).
**Consequence.** Comparing replayed values to reference request bodies needs a tolerance (proposed: at most 8 ulps, or relative 1e-14). Whether the model's predictions change for exact-text inputs is a model question, not tested here (Data Science).
**Status.** Partition PASS. Reference cases NEEDS CONFIRMATION.

## 10. New finding: CSV parsing precision

pandas `read_csv` with its default float parser changes **57,404 cells** by 1 ulp compared with the exact text. `float_precision="round_trip"` (or Python `float()` on the text) reproduces every value exactly, and `repr(float(text)) == text` for every cell, so the file text is the canonical value.
**Consequences.**
- The replay reads with exact parsing and serializes with `repr` (Python `json` does this), so published values equal the file text bit for bit.
- The notebook and `export_artifacts.py` used the default parser, so the model trained on values up to a few ulps from the file text, and the reference cases carry such values. Owner: Data Science (acknowledge; probably harmless but untested).

## 11. New finding: raw recordings have time of day

Every row in the per-scenario raw files carries a serial-monitor time of day (`HH:MM:SS.mmm`, no date). Values in each file equal the matching processed class block exactly.
- **Acquisition order differs from file order:** F0, F1, F2, F6, F7, F8, F3, F4, F5 (13:24 to 14:32 on one unknown day).
- **Each class is a separate recording**, separated by gaps of 83 s to 1,413 s. So **every class boundary in the processed file is a splice of two recordings**, not a physical fault onset. The 72 boundary rows mix two recordings.
- Real sampling is nominal 10 Hz: intervals 66 to 137 ms, median 101 ms; each block's real duration is about 2.2 % longer than index x 0.1 (F0: 439.0 s vs 429.4 s).
- F6 has a 3.9 s gap followed by 37 rows sharing one time stamp (processed rows 7415 to 7453, CV development partition), which looks like a buffer flush. Rate-of-change and moving averages there assume 0.1 s spacing that did not happen.

The handover report says there are no run identifiers; the raw file names act as run identifiers. These timestamps are **not** used by the proposed timestamp policies (the brief specifies the processed relative index). An optional `raw_time_of_day` reference field could go in the trace fragment; decision for the integration team and Data Science.

## 12. Reference replay service

Unchanged from v1: 72/72 tests pass on a copy (Python 3.13.16). Hard-coded two-asset assumptions in `engine`, `api`, `cli`, `config.device_id_for` (unknown assets fall through to the **transformer device ID**), `payload.load_mapping` (requires both assets), `payload.build_measurement` (no omit path), unguarded `NaN`/`Infinity` JSON, `shifted` needs absolute datetimes, manifest has no row ranges. Battery `_parse_float` passes `inf` (latent, not to be changed without approval).

**Decision (2026-10-15):** the Battery and Transformer service has already been handed to the software developers and stays unchanged, so the inverter replay is a standalone service with the same structure (`pmsm_inverter_replay_service`). The adapter route below was not taken. Originally proposed route: `adapters/inverter.py` plus small, behaviour-preserving shared changes: explicit asset registry; `C8Y_DEVICE_ID_INVERTER` (no default); per-asset mapping validation; inverter-only non-finite policy (`omit` or `block`) with `allow_nan=False`; relative-index timeline in integer milliseconds; manifest `inverter` list of row ranges. Battery and Transformer tests unchanged and passing.

## 13. Proposed real-data dry-run selections (pending approval)

| Kind | Rows | Composition | Notes |
|---|---|---|---|
| Complete class block | F4, 6516 to 6856 (341) | 55 final train, 58 final validation, 68 held-out, 130 CV development, 30 purge | Smallest block. Starts with 9 boundary rows whose stored moving averages include F3 rows. No complete block can be fully held out. |
| Window across a transition | F0 to F1, 4275 to 4314 (40) | 20 F0 held-out + 20 F1 CV development | Only normal-to-fault boundary; consecutive in acquisition order but 548 s apart in reality. No transition window can be fully held out. |
| Optional, held-out only | F2 held-out, 5885 to 6108 (224) | 224 held-out | Window inside one block; contains the ref-03 row, useful for comparison. |

The preview will state that replaying training or development rows overstates model accuracy.

## 14. Open items (owners as proposed in the brief)

| Item | Owner | Status |
|---|---|---|
| `sensor` profile channels: option A, B or C (section 7) | Data Science, Mudhawi | NEEDS CONFIRMATION |
| Which profile the platform receives; who computes the 10 features | Mudhawi with Riyaz and Software team | NEEDS CONFIRMATION |
| Record 13974503 vs 14482932 wording in the report (file is identical) | Data Science | NEEDS CONFIRMATION |
| Default-parser drift in training data and reference cases (sections 9, 10) | Data Science | NEEDS CONFIRMATION |
| Class boundaries are recording splices; transition windows do not test real fault onset (section 11) | Data Science, Mudhawi | NEEDS CONFIRMATION |
| F6 timing anomaly rows 7415 to 7453 | Data Science | NEEDS CONFIRMATION |
| Representative selection, approver, held-out only or not | Data Science, Mudhawi | NEEDS CONFIRMATION |
| Non-finite rows and rows 0 to 8 handling | Data Science | NEEDS CONFIRMATION |
| Voltage sign (VDC, VD negative in over 98 % of rows) and calibration | Data Science | NEEDS CONFIRMATION |
| Timestamp anchor, timezone, old or future timestamps; optional raw time-of-day trace | Integration team | NEEDS CONFIRMATION |
| Send cadence vs 10 Hz, ingestion and bulk limits | Riyaz, Software team | BLOCKED |
| Mapping approval, ratio-feature units (`dimensionless` in schema), trace fragment | Software team | NEEDS CONFIRMATION |
| Target tenant, existing device, credentials | Software team, Mudhawi | NEEDS CONFIRMATION |
| Deployed model OpenAPI contract | Mudhawi | NEEDS CONFIRMATION |
| Packaging and API authentication | Mudhawi, deployment team | NEEDS CONFIRMATION |
| Docker build (needs a Docker daemon) | Mudhawi or builder | NOT TESTED |
| Reference Battery parser accepts `inf` | Reference service owner | NEEDS CONFIRMATION |

## 15. Decisions (status at implementation)

1. Architecture: decided, standalone service.
2. `sensor` profile channels: option A is in the proposed mapping; B is a mapping edit. Still NEEDS CONFIRMATION (OPEN_ITEMS 2).
3. Dry-run selections: run as proposed and recorded in `config/selections.pending.json` as PENDING_APPROVAL (OPEN_ITEMS 4).
