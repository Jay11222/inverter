# Test report (2026-10-15)

Everything below was run. Nothing was sent to a real Cumulocity tenant, the model was never called, and the Docker image was not built.

## Automated tests (synthetic fixtures, local mock Cumulocity)

| Environment | Result |
|---|---|
| Python 3.11.17 (as the Dockerfile), `requirements-dev.txt` | 95 passed; the 2 validation tests skipped (numpy 2.5.2 needs Python 3.12+) |
| Python 3.13.16, `requirements-dev.txt` + `requirements-validation.txt` | 97 passed |

No real dataset rows are used. `tests/conftest.py` generates a 290-row file (classes F0, F1, F2) with the dataset's column layout and formulas, NaN in the first rows, a zero-sum phase pair (+inf imbalance), a zero DC current (+/-inf normalized currents) and a repeated sensor combination.

Coverage, by requirement:

| Requirement | Tests |
|---|---|
| Values preserved bit for bit (both profiles) | `test_values_preserved_bit_for_bit`, `test_values_parsed_exactly_from_text`, `test_parse_value_and_timestamp_exact` |
| Ordering, stable observation IDs, run IDs | `test_order_and_ids_stable` |
| 0.1 s spacing under each timestamp policy and pacing mode | `test_spacing_100ms_under_every_policy_and_pace` (6 combinations), `test_spacing_is_exactly_the_source_interval`, `test_anchor_end_and_now_resolved_once` |
| Non-finite policy, no substitution | `test_nonfinite_omitted_never_substituted`, `test_nonfinite_policy_block_refuses`, `test_nan_or_infinity_never_serialised` |
| FDD never in a payload; Timestamp never a series | `test_fdd_never_in_payload_and_timestamp_never_a_series`, mapping validation tests |
| Flags, warm-up and boundary detection, partitions | `test_flags_never_alter_values`, `test_flags_reported_values_kept`, `test_selection_kinds_warmup_boundary_partitions`, `test_class_blocks_and_partition_reproduction`, `test_held_out_only_selection_has_no_accuracy_warning` |
| Each profile publishes exactly its approved series; units; ratio without unit | `test_each_profile_publishes_exactly_its_series`, `test_units_from_contract_and_ratio_series_have_no_unit`, `test_mapping_rejects_fdd_timestamp_wrong_units_and_ratio_units` |
| Model contract and /predict bodies | `test_model_readiness_and_predict_bodies`, `test_predict_body_validation_mirrors_schema`, `test_compare_with_openapi`, `test_cli_contract_check` |
| Publish gates (each one), exact approved range, dataset hash, profile match | `test_publish_blocked_by_default_with_every_reason`, `test_each_gate_blocks_publishing` (8 cases), `test_publish_requires_exact_approved_range`, `test_publish_mapping_not_approved_blocks` |
| Refusal instead of truncation | `test_cap_refuses_never_truncates`, `test_limit_is_dry_run_only_and_marked_partial` |
| Retry and duplicate reconciliation | `tests/test_client.py` (copied from the reference service), `test_publish_duplicate_reconciled_not_resent`, `test_publish_halts_on_unconfirmed`, `test_publish_4xx_not_retried_and_halts` |
| No device creation | `test_no_device_creation_api_exists`, `test_publish_to_mock_tenant_end_to_end` |
| Credentials never logged | `test_credentials_never_logged` (client), `test_credentials_never_logged_during_publish`, `test_secrets_not_in_repr_or_public_view`, `/config` test |
| Measurement time is not send time | `test_measurement_time_is_not_send_time`, `test_publish_to_mock_tenant_end_to_end` |
| API behaviour | `test_api_health_config_dataset_and_dry_run`, `test_api_rejections`, `test_api_dataset_missing_is_409` |
| Read-only inventory | `test_inventory_is_read_only_and_aggregate`, `test_zip_source_read_in_place` |
| Feature recomputation and calibration | `test_processed_mode_reproduces_exactly`, `test_wrong_calibration_would_be_detected` |

## Mutation check (`tools/mutation_check.py`, Python 3.13)

Each mutation was applied to a temporary copy; the working tree was not changed. Baseline: 97 passed.

| Mutation | Result | Caught by (examples) |
|---|---|---|
| Round a value (6 decimals) | KILLED | `test_parse_value_and_timestamp_exact`, `test_flags_never_alter_values` |
| Replace infinity with zero | KILLED | `test_nonfinite_omitted_never_substituted`, `test_model_readiness_and_predict_bodies` |
| Replace infinity with a median | KILLED | same as above |
| Publish FDD (as a number) | KILLED | `test_fdd_never_in_payload_and_timestamp_never_a_series`, `test_publish_to_mock_tenant_end_to_end` and 4 others |
| Use send time as measurement time | KILLED | `test_measurement_time_is_not_send_time`, `test_publish_to_mock_tenant_end_to_end` |
| Compress the 0.1 s spacing when pacing is scaled | KILLED | `test_spacing_100ms_under_every_policy_and_pace` |
| Rebuild features with `*_original` instead of the Arduino calibration | KILLED | `test_processed_mode_reproduces_exactly`, `test_wrong_calibration_would_be_detected` |
| Skip the duplicate lookup | KILLED | 6 client tests |
| Truncate a selection to fit the cap | KILLED | `test_cap_refuses_never_truncates` |
| Add a unit to a ratio series | KILLED | `test_units_from_contract_and_ratio_series_have_no_unit` |

## Real-data dry runs (network disabled with `tools/no_network.py`)

Dataset: the Zenodo zip read in place (SHA-256 `88d8940e...6cd6e83` before and after; CSV member equals the verified training copy). Anchor `2026-10-15T00:00:00Z`, shifted policy. Every run: spacing exactly 100,000 us, no FDD in any payload, 9 publish blockers reported (nothing approved), selection marked not approved.

| Selection (pending approval) | Profile | Obs | Partitions | Boundary / warm-up rows | Omitted series | Valid /predict bodies |
|---|---|---|---|---|---|---|
| F4 full block 6516 to 6856 | sensor | 341 | 55 train, 58 val, 68 test, 130 CV, 30 purge | 9 / 9 | 0 | n/a (upstream) |
| F4 full block | sensor_plus_features | 341 | same | 9 / 9 | 0 | 341 of 341 |
| F0 to F1 4275 to 4314 | sensor | 40 | 20 test, 20 CV | 9 / 9 | 0 | n/a |
| F0 to F1 | sensor_plus_features | 40 | same | 9 / 9 | 0 | 40 of 40 |
| F2 held-out 5885 to 6108 | sensor / sensor_plus_features | 224 | 224 test | 0 / 9 | 0 | 224 of 224 |
| F0 held-out 3436 to 3475 | sensor_plus_features | 40 | 40 test | 0 / 9 | 1 (row 3449 Current_Imbalance +inf) | 40 of 40 (one with null) |

Reference cases: `tools/reference_case_bodies.py` built valid bodies for all 11 cases (all held-out, labels match); they differ from the exported request bodies by 1 to 6 ulps in 2 to 7 features (parser drift, OPEN_ITEMS 7).

## HTTP service

Started with `python -m inverter_replay.main` from a fresh Python 3.11 environment with only `requirements.txt`, real dataset zip mounted read-only, dummy credentials in the environment. Called over HTTP: `/health` UP; `/config` showed no credentials (`credentials_configured: true`) and 7 configuration blockers; `/dataset` returned aggregates; `POST /replays` dry run of 341 rows completed; `/preview` returned 341 payloads and 341 reference labels; publish request refused with 422; unknown field refused with 422. JSON logs at DEBUG contained no credentials.

## Not tested

Real tenant, deployed model and its OpenAPI, upstream pipeline, Docker build and packaging, behaviour under real ingestion limits.
