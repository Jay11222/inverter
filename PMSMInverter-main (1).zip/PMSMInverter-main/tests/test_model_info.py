import json

from app.feature_engineering import FEATURES
from tests.conftest import ROOT

EXPECTED_FEATURES = [
    "Ia_original", "Ib_original", "VDC", "IDC_original", "T1", "T2", "T3", "VD",
    "Power_DC", "Power_AC", "Current_Imbalance", "Ia_Normalized", "Ib_Normalized",
    "VDC_RateOfChange", "IDC_RateOfChange", "VDC_MovingAvg", "IDC_MovingAvg", "Temp_Diff_Max",
]


def test_model_info(client):
    r = client.get("/model-info")
    assert r.status_code == 200
    body = r.json()
    assert body["model_version"] == "1.0.0"
    assert body["feature_count"] == 18
    assert body["features"] == EXPECTED_FEATURES
    assert body["labels"] == [f"F{i}" for i in range(9)]
    assert body["label_mapping"] == {str(i): f"F{i}" for i in range(9)}
    assert set(body["class_definitions"]) == set(body["labels"])
    assert body["nullable_features"] == ["Current_Imbalance", "Ia_Normalized", "Ib_Normalized"]
    assert body["limitations"]


def test_metadata_is_complete():
    md = json.loads((ROOT / "artifacts" / "model_metadata.json").read_text())
    for key in ("model_name", "model_version", "training_date", "framework", "artifacts",
                "dataset", "feature_order", "target", "limitations", "evaluation"):
        assert md[key], key
    assert {"python", "xgboost"} <= set(md["framework"])
    assert md["feature_order"] == EXPECTED_FEATURES == FEATURES
    assert md["evaluation"]["macro_f1"] == 0.960095  # notebook held-out test result


def test_feature_schema_documents_every_feature():
    schema = json.loads((ROOT / "artifacts" / "feature_schema.json").read_text())
    assert schema["feature_order"] == EXPECTED_FEATURES
    for i, f in enumerate(schema["features"]):
        assert f["index"] == i and f["name"] == EXPECTED_FEATURES[i]
        for key in ("description", "unit", "dtype", "source", "formula", "missing_value_handling"):
            assert f[key], (f["name"], key)
        assert f["source"] in {"raw_sensor", "engineered"}
