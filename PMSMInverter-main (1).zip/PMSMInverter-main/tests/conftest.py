import json
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import app

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples"


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:  # runs startup: artifacts loaded once
        yield c


@pytest.fixture
def valid_request():
    return json.loads((SAMPLES / "valid_request.json").read_text())


@pytest.fixture(scope="session")
def reference_cases():
    return json.loads((SAMPLES / "expected_predictions.json").read_text())
