"""The upstream feature contract (app/feature_engineering.py) reproduces the training data."""

import numpy as np
import pandas as pd

from app.feature_engineering import FEATURES, MOVING_AVG_WINDOW, compute_features
from tests.conftest import SAMPLES


def test_reference_implementation_reproduces_training_features():
    raw = pd.read_csv(SAMPLES / "raw_adc_stream_sample.csv", index_col="dataset_row_index")
    expected = pd.read_csv(SAMPLES / "raw_adc_stream_expected_features.csv",
                           index_col="dataset_row_index")
    got = compute_features(raw)
    assert list(got.columns) == FEATURES
    # The first rows of a stream lack history for the rolling features.
    assert got["VDC_MovingAvg"].iloc[:MOVING_AVG_WINDOW - 1].isna().all()
    assert got["VDC_RateOfChange"].iloc[:1].isna().all()
    warm = got.iloc[MOVING_AVG_WINDOW - 1:]
    exp = expected.loc[warm.index]
    for f in FEATURES:
        np.testing.assert_allclose(warm[f], exp[f], rtol=1e-12, atol=1e-12, err_msg=f)
    # Sample includes a row with IDC_a == 0 -> undefined ratios.
    assert np.isinf(got.loc[237, "Ia_Normalized"]) and np.isinf(exp.loc[237, "Ia_Normalized"])


def test_current_imbalance_undefined_when_currents_cancel():
    raw = pd.DataFrame({"Ia": [429], "Ib": [595], "VDC": [507], "IDC": [506],
                        "T1": [515], "T2": [504], "T3": [495], "VD": [510]})
    assert np.isinf(compute_features(raw)["Current_Imbalance"].iloc[0])
