import json

import pytest

from app.model import ArtifactError, PMSMModel
from tests.conftest import ROOT


def test_health_ok(client):
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["model_loaded"] is True
    assert body["artifacts_verified"] is True
    assert body["model_version"] == "1.0.0"


def test_docs_and_openapi_available(client):
    assert client.get("/docs").status_code == 200
    spec = client.get("/openapi.json").json()
    assert {"/health", "/model-info", "/predict"} <= set(spec["paths"])


def test_artifacts_load_directly():
    model = PMSMModel(ROOT / "artifacts")
    assert len(model.features) == 18
    assert model.labels == [f"F{i}" for i in range(9)]


def test_tampered_artifact_is_refused(tmp_path):
    for p in (ROOT / "artifacts").iterdir():
        (tmp_path / p.name).write_bytes(p.read_bytes())
    meta_path = tmp_path / "model_metadata.json"
    meta = json.loads(meta_path.read_text())
    meta["artifacts"]["pmsm_xgboost_model.joblib"]["sha256"] = "0" * 64
    meta_path.write_text(json.dumps(meta))
    with pytest.raises(ArtifactError, match="Checksum mismatch"):
        PMSMModel(tmp_path)


def test_missing_artifact_is_refused(tmp_path):
    for p in (ROOT / "artifacts").iterdir():
        if p.name != "feature_imputer.joblib":
            (tmp_path / p.name).write_bytes(p.read_bytes())
    with pytest.raises(ArtifactError, match="Missing artifact"):
        PMSMModel(tmp_path)
