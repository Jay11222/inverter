import json
import math

import pytest

from tests.conftest import SAMPLES


def post_raw(client, body: str):
    return client.post("/predict", content=body, headers={"content-type": "application/json"})


def test_valid_prediction(client, valid_request):
    r = client.post("/predict", json=valid_request)
    assert r.status_code == 200
    body = r.json()
    assert body["predicted_class"] in {f"F{i}" for i in range(9)}
    assert list(body["class_probabilities"]) == [f"F{i}" for i in range(9)]
    assert math.isclose(sum(body["class_probabilities"].values()), 1.0, abs_tol=1e-5)
    assert body["predicted_class"] == max(body["class_probabilities"], key=body["class_probabilities"].get)
    assert body["model_version"] == "1.0.0"
    assert body["imputed_features"] == []


def test_reference_predictions_match_exported_artifacts(client, reference_cases):
    assert len(reference_cases["cases"]) >= 5
    tol = reference_cases["probability_tolerance"]
    for case in reference_cases["cases"]:
        r = client.post("/predict", json=case["request"])
        assert r.status_code == 200, case["case_id"]
        body = r.json()
        assert body["predicted_class"] == case["expected_predicted_class"], case["case_id"]
        for label, p in case["expected_class_probabilities"].items():
            assert abs(body["class_probabilities"][label] - p) <= tol, (case["case_id"], label)


def test_reference_model_checksum_matches(client, reference_cases):
    info = client.get("/model-info").json()
    assert info["artifacts"]["pmsm_xgboost_model.joblib"]["sha256"] == reference_cases["model_sha256"]


def test_nullable_ratio_feature_is_imputed(client, valid_request):
    r = client.post("/predict", json={**valid_request, "Current_Imbalance": None})
    assert r.status_code == 200
    assert r.json()["imputed_features"] == ["Current_Imbalance"]


def test_missing_required_feature(client):
    body = json.loads((SAMPLES / "invalid_request_missing_feature.json").read_text())
    r = client.post("/predict", json=body)
    assert r.status_code == 422
    assert {"loc": ["body", "T3"], "type": "missing", "msg": "Field required"} in r.json()["detail"]


def test_nullable_feature_key_still_required(client, valid_request):
    del valid_request["Ia_Normalized"]
    r = client.post("/predict", json=valid_request)
    assert r.status_code == 422
    assert r.json()["detail"][0]["loc"] == ["body", "Ia_Normalized"]


@pytest.mark.parametrize("bad", ["12.5", "abc", True, [1.0], {"v": 1.0}])
def test_wrong_field_type(client, valid_request, bad):
    r = client.post("/predict", json={**valid_request, "T1": bad})
    assert r.status_code == 422
    assert r.json()["detail"][0]["loc"] == ["body", "T1"]


def test_null_for_non_nullable_feature(client, valid_request):
    r = client.post("/predict", json={**valid_request, "VDC": None})
    assert r.status_code == 422


@pytest.mark.parametrize("token", ["NaN", "Infinity", "-Infinity", "1e400"])
@pytest.mark.parametrize("field", ["T1", "Current_Imbalance"])
def test_nan_and_infinite_rejected(client, valid_request, token, field):
    body = json.dumps({**valid_request, field: "__X__"}).replace('"__X__"', token)
    r = post_raw(client, body)
    assert r.status_code == 422
    assert r.json()["detail"][0]["type"] == "finite_number"


def test_unknown_field_rejected(client, valid_request):
    r = client.post("/predict", json={**valid_request, "Ia": 532})
    assert r.status_code == 422
    assert r.json()["detail"][0]["type"] == "extra_forbidden"


@pytest.mark.parametrize("body", ["", "{}", "{not json", "[]", "null", '"text"'])
def test_empty_or_malformed_request(client, body):
    r = post_raw(client, body)
    assert r.status_code == 422
    assert r.json()["detail"]


def test_validation_error_does_not_echo_input(client, valid_request):
    r = client.post("/predict", json={**valid_request, "T1": "secret-value-123"})
    assert r.status_code == 422
    assert "secret-value-123" not in r.text
