"""Load the exported artifacts once and run inference. Never trains."""

import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

DEFAULT_ARTIFACTS_DIR = Path(__file__).resolve().parents[1] / "artifacts"


class ArtifactError(RuntimeError):
    """Artifacts are missing, altered, or inconsistent with each other."""


def artifacts_dir() -> Path:
    return Path(os.environ.get("PMSM_ARTIFACTS_DIR", DEFAULT_ARTIFACTS_DIR))


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


@dataclass(frozen=True)
class Prediction:
    predicted_class: str
    class_probabilities: dict[str, float]
    imputed_features: list[str]


class PMSMModel:
    def __init__(self, directory: Path):
        self.directory = directory
        self.metadata = json.loads((directory / "model_metadata.json").read_text())
        self.schema = json.loads((directory / "feature_schema.json").read_text())

        # Refuse to serve artifacts that differ from what metadata describes.
        for name, info in self.metadata["artifacts"].items():
            path = directory / name
            if not path.is_file():
                raise ArtifactError(f"Missing artifact: {name}")
            if _sha256(path) != info["sha256"]:
                raise ArtifactError(f"Checksum mismatch for {name}")

        self.model = joblib.load(directory / "pmsm_xgboost_model.joblib")
        self.imputer = joblib.load(directory / "feature_imputer.joblib")
        self.label_encoder = joblib.load(directory / "label_encoder.joblib")

        self.features: list[str] = self.schema["feature_order"]
        self.labels: list[str] = [str(c) for c in self.label_encoder.classes_]
        self.nullable = {f["name"] for f in self.schema["features"] if f["nullable"]}

        consistency = {
            "schema vs metadata feature order": self.features == self.metadata["feature_order"],
            "imputer feature order": list(self.imputer.feature_names_in_) == self.features,
            "model feature order": list(self.model.get_booster().feature_names) == self.features,
            "label mapping": self.labels == self.metadata["target"]["classes"],
            "model class count": int(self.model.n_classes_) == len(self.labels),
        }
        broken = [k for k, ok in consistency.items() if not ok]
        if broken:
            raise ArtifactError(f"Inconsistent artifacts: {broken}")

    @property
    def version(self) -> str:
        return self.metadata["model_version"]

    def class_description(self, label: str) -> str:
        return self.metadata["target"]["class_definitions"][label]

    def predict(self, record: dict[str, float | None]) -> Prediction:
        imputed = [f for f in self.features if record[f] is None]
        if any(f not in self.nullable for f in imputed):
            raise ValueError("Only nullable features may be null")
        row = pd.DataFrame(
            [[np.nan if record[f] is None else record[f] for f in self.features]],
            columns=self.features, dtype="float64",
        )
        X = pd.DataFrame(self.imputer.transform(row), columns=self.features)
        proba = self.model.predict_proba(X)[0]
        best = int(np.argmax(proba))
        return Prediction(
            predicted_class=str(self.label_encoder.inverse_transform([best])[0]),
            class_probabilities={label: float(p) for label, p in zip(self.labels, proba)},
            imputed_features=imputed,
        )
