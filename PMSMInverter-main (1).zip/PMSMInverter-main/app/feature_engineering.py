"""Reference implementation of the 18 model features from raw ADC counts.

The inference API receives the 18 features already calculated (see README and
artifacts/feature_schema.json). This module is the executable specification of how
those features must be calculated upstream. It reproduces
`code/data_conversion_script_v4.py` from the PMSM-inverter-fault-diagnosis-3.0
dataset, which produced `processed_data/converted_dataset.csv`, and
`tests/test_feature_engineering.py` checks it against that CSV.

It is not called by the API at request time.

Input: one continuous stream from one drive, in time order, sampled every
0.1 s (10 Hz), with the raw 10-bit ADC columns Ia, Ib, VDC, IDC, T1, T2, T3, VD.
"""

import numpy as np
import pandas as pd

SAMPLE_PERIOD_S = 0.1          # 10 Hz; used as the rate-of-change time step
MOVING_AVG_WINDOW = 10         # samples (1.0 s), current sample included
RAW_ADC_COLUMNS = ["Ia", "Ib", "VDC", "IDC", "T1", "T2", "T3", "VD"]

FEATURES = [
    "Ia_original", "Ib_original", "VDC", "IDC_original",
    "T1", "T2", "T3", "VD",
    "Power_DC", "Power_AC", "Current_Imbalance",
    "Ia_Normalized", "Ib_Normalized",
    "VDC_RateOfChange", "IDC_RateOfChange",
    "VDC_MovingAvg", "IDC_MovingAvg", "Temp_Diff_Max",
]


def adc_to_current_acs712_20a(adc):
    """ACS712-20A, 100 mV/A, 5 V / 10-bit ADC -> amps ("original" calibration)."""
    voltage = (adc / 1023) * 5
    return (voltage - 2.5) / 0.100


def arduino_acs712_current(adc):
    """Arduino-firmware current calibration -> amps. Used by engineered features."""
    return 0.074 * (adc - 512)


def adc_to_voltage_acs712_100ohm(adc):
    """ACS712 in series with a 100 ohm resistor -> volts."""
    voltage = (adc / 1023) * 5
    current = (voltage - 2.5) / 0.100
    return current * 100


def adc_to_temperature_ntc(adc):
    """10k NTC + 10k divider, Steinhart-Hart -> degrees Celsius."""
    r1 = 10000
    a, b, c = 1.2666e-3, 2.3661e-4, 9.6094e-8
    r_th = r1 / ((1023 / adc) - 1)
    ln_r = np.log(r_th)
    return 1 / (a + b * ln_r + c * ln_r**3) - 273.15


def compute_features(raw: pd.DataFrame) -> pd.DataFrame:
    """Raw ADC stream -> the 18 model features, in model order.

    Rows at the start of the stream without enough history get NaN for the
    rate-of-change (first row) and moving-average (first 9 rows) features;
    do not send those rows to the API.

    Division by zero gives +/-inf in Current_Imbalance (Ia_a + Ib_a == 0) and
    in Ia_Normalized / Ib_Normalized (IDC_a == 0). The model treats those as
    missing; send them to the API as JSON null.
    """
    missing = [c for c in RAW_ADC_COLUMNS if c not in raw.columns]
    if missing:
        raise KeyError(f"Missing raw ADC columns: {missing}")
    r = raw[RAW_ADC_COLUMNS].astype(float)

    ia_a = arduino_acs712_current(r["Ia"])
    ib_a = arduino_acs712_current(r["Ib"])
    idc_a = arduino_acs712_current(r["IDC"])
    vdc = adc_to_voltage_acs712_100ohm(r["VDC"])
    vd = adc_to_voltage_acs712_100ohm(r["VD"])
    temps = pd.DataFrame({
        "T1": adc_to_temperature_ntc(r["T1"]),
        "T2": adc_to_temperature_ntc(r["T2"]),
        "T3": adc_to_temperature_ntc(r["T3"]),
    })

    out = pd.DataFrame(index=raw.index)
    out["Ia_original"] = adc_to_current_acs712_20a(r["Ia"])
    out["Ib_original"] = adc_to_current_acs712_20a(r["Ib"])
    out["VDC"] = vdc
    out["IDC_original"] = adc_to_current_acs712_20a(r["IDC"])
    out["T1"], out["T2"], out["T3"] = temps["T1"], temps["T2"], temps["T3"]
    out["VD"] = vd
    out["Power_DC"] = vdc * idc_a
    out["Power_AC"] = vd * (ia_a + ib_a)
    out["Current_Imbalance"] = np.abs(ia_a - ib_a) / ((ia_a + ib_a) / 2)
    out["Ia_Normalized"] = ia_a / idc_a
    out["Ib_Normalized"] = ib_a / idc_a
    out["VDC_RateOfChange"] = vdc.diff() / SAMPLE_PERIOD_S
    out["IDC_RateOfChange"] = idc_a.diff() / SAMPLE_PERIOD_S
    out["VDC_MovingAvg"] = vdc.rolling(window=MOVING_AVG_WINDOW).mean()
    out["IDC_MovingAvg"] = idc_a.rolling(window=MOVING_AVG_WINDOW).mean()
    out["Temp_Diff_Max"] = temps.max(axis=1) - temps.min(axis=1)
    return out[FEATURES]
