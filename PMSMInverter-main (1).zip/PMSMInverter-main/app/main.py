"""PMSM inverter fault-diagnosis inference service.

Start with: uvicorn app.main:app --host 0.0.0.0 --port 8000
"""

import json
import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.model import PMSMModel, artifacts_dir
from app.schemas import HealthResponse, PredictRequest, PredictResponse


class JsonFormatter(logging.Formatter):
    def format(self, record):
        entry = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        entry.update(getattr(record, "fields", {}))
        return json.dumps(entry)


_handler = logging.StreamHandler()
_handler.setFormatter(JsonFormatter())
log = logging.getLogger("pmsm_fdd")
log.addHandler(_handler)
log.setLevel(logging.INFO)
log.propagate = False


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Load once. Any artifact problem stops startup (container exits non-zero)
    # instead of serving a half-working model.
    directory = artifacts_dir()
    model = PMSMModel(directory)
    app.state.model = model
    log.info("model loaded", extra={"fields": {
        "model_name": model.metadata["model_name"],
        "model_version": model.version,
        "artifacts_dir": str(directory),
        "feature_count": len(model.features),
    }})
    yield


app = FastAPI(
    title="PMSM Inverter Fault Diagnosis",
    description=(
        "XGBoost classifier for inverter-driven PMSM operating state (F0 normal, F1-F8 faults). "
        "POST one record of 18 pre-engineered features to /predict. Decision support only."
    ),
    version="1.0.0",
    lifespan=lifespan,
)


@app.exception_handler(RequestValidationError)
async def validation_error_handler(request: Request, exc: RequestValidationError):
    # Report which fields failed and why; never log or echo the submitted values.
    errors = [
        {"loc": list(e["loc"]), "type": e["type"], "msg": e["msg"]}
        for e in exc.errors()
    ]
    log.info("request rejected", extra={"fields": {
        "path": request.url.path, "status": 422,
        "error_fields": [".".join(str(p) for p in e["loc"]) for e in errors][:20],
    }})
    return JSONResponse(status_code=422, content={"detail": errors})


@app.get("/health", response_model=HealthResponse)
def health(request: Request):
    model: PMSMModel = request.app.state.model
    return HealthResponse(
        status="ok", model_loaded=True, model_version=model.version, artifacts_verified=True,
    )


@app.get("/model-info")
def model_info(request: Request):
    model: PMSMModel = request.app.state.model
    md = model.metadata
    return {
        "model_name": md["model_name"],
        "model_version": md["model_version"],
        "owner": md["owner"],
        "training_date": md["training_date"],
        "feature_count": len(model.features),
        "features": model.features,
        "nullable_features": sorted(model.nullable),
        "labels": model.labels,
        "label_mapping": md["target"]["label_mapping"],
        "class_definitions": md["target"]["class_definitions"],
        "framework": md["framework"],
        "artifacts": md["artifacts"],
        "dataset": md["dataset"],
        "evaluation": {k: md["evaluation"][k] for k in
                       ("data_reference", "rows", "macro_f1", "accuracy", "balanced_accuracy")},
        "limitations": md["limitations"],
    }


@app.post("/predict", response_model=PredictResponse)
def predict(payload: PredictRequest, request: Request):
    model: PMSMModel = request.app.state.model
    started = time.perf_counter()
    result = model.predict(payload.model_dump())
    log.info("prediction", extra={"fields": {
        "request_id": request.headers.get("x-request-id") or uuid.uuid4().hex,
        "predicted_class": result.predicted_class,
        "confidence": round(result.class_probabilities[result.predicted_class], 4),
        "imputed_features": result.imputed_features,
        "latency_ms": round((time.perf_counter() - started) * 1000, 2),
        "model_version": model.version,
    }})
    return PredictResponse(
        predicted_class=result.predicted_class,
        predicted_class_description=model.class_description(result.predicted_class),
        class_probabilities=result.class_probabilities,
        imputed_features=result.imputed_features,
        model_version=model.version,
    )
