"""Request/response contract for the inference API."""

from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field

# strict: reject strings/booleans instead of coercing them; allow_inf_nan:
# reject NaN/Infinity tokens. Every field is required (no default).
Finite = Annotated[float, Field(strict=True, allow_inf_nan=False)]
# Only for the three ratio features whose denominator can be exactly zero.
# The key must still be present; null means "undefined" and is median-imputed.
FiniteOrNull = Annotated[float | None, Field(strict=True, allow_inf_nan=False)]


class PredictRequest(BaseModel):
    """One PMSM measurement record: the 18 features, already calculated.

    Field order here is documentation only; the service always feeds the model
    in the order recorded in artifacts/feature_schema.json.
    """

    model_config = ConfigDict(
        extra="forbid",
        # Reference case ref-01 (samples/valid_request.json), expected F0.
        json_schema_extra={"examples": [{
            "Ia_original": -3.592375366568916,
            "Ib_original": -1.9305962854349976,
            "VDC": -12.218963831867049,
            "IDC_original": -0.2199413489736068,
            "T1": 11.401304818190908,
            "T2": 12.063802076642958,
            "T3": 14.072288751798853,
            "VD": -7.331378299120228,
            "Power_DC": 4.521016617790807,
            "Power_AC": 61.847507331378246,
            "Current_Imbalance": -0.5964912280701754,
            "Ia_Normalized": 14.8,
            "Ib_Normalized": 8.0,
            "VDC_RateOfChange": 146.62756598240455,
            "IDC_RateOfChange": 0.7399999999999995,
            "VDC_MovingAvg": -21.01661779081132,
            "IDC_MovingAvg": -0.3995999999999999,
            "Temp_Diff_Max": 2.6709839336079426,
        }]},
    )

    Ia_original: Finite = Field(description="Phase A current, A")
    Ib_original: Finite = Field(description="Phase B current, A")
    VDC: Finite = Field(description="DC bus voltage, V")
    IDC_original: Finite = Field(description="DC bus current, A")
    T1: Finite = Field(description="Half-bridge 1 temperature, degC")
    T2: Finite = Field(description="Half-bridge 2 temperature, degC")
    T3: Finite = Field(description="Half-bridge 3 temperature, degC")
    VD: Finite = Field(description="Gate-driver voltage, V")
    Power_DC: Finite = Field(description="VDC * IDC_a, W")
    Power_AC: Finite = Field(description="VD * (Ia_a + Ib_a), W")
    Current_Imbalance: FiniteOrNull = Field(
        description="abs(Ia_a - Ib_a) / ((Ia_a + Ib_a) / 2); null if Ia_a + Ib_a == 0")
    Ia_Normalized: FiniteOrNull = Field(description="Ia_a / IDC_a; null if IDC_a == 0")
    Ib_Normalized: FiniteOrNull = Field(description="Ib_a / IDC_a; null if IDC_a == 0")
    VDC_RateOfChange: Finite = Field(description="(VDC[t] - VDC[t-1]) / 0.1, V/s")
    IDC_RateOfChange: Finite = Field(description="(IDC_a[t] - IDC_a[t-1]) / 0.1, A/s")
    VDC_MovingAvg: Finite = Field(description="Mean of last 10 VDC samples (1 s), V")
    IDC_MovingAvg: Finite = Field(description="Mean of last 10 IDC_a samples (1 s), A")
    Temp_Diff_Max: Finite = Field(description="max(T1,T2,T3) - min(T1,T2,T3), degC")


class PredictResponse(BaseModel):
    predicted_class: str = Field(description="Most probable class, F0-F8")
    predicted_class_description: str
    class_probabilities: dict[str, float] = Field(
        description="Full softmax distribution over F0-F8 (sums to 1; not calibrated)")
    imputed_features: list[str] = Field(
        description="Features sent as null and replaced by the training median")
    model_version: str


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    model_version: str
    artifacts_verified: bool
