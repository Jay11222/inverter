"""Reproduce the final evaluated notebook model and export inference artifacts.

Offline Data Science step; never run by the API or inside the Docker image.

Mirrors notebooks/PMSM_XGBoost_Training_Validation.ipynb exactly: same 18
features, per-class chronological split with purge gap, most-recent-fold
training window, train-only median imputer, balanced sample weights, the same
row shuffle, and the same frozen hyperparameters. It then checks the held-out
test results against the figures saved in the notebook outputs and refuses to
write artifacts if they differ.

Usage (from the repository root):
    python training/export_artifacts.py
"""

import datetime as dt
import hashlib
import json
import platform
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
import xgboost
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, classification_report, confusion_matrix,
)
from sklearn.preprocessing import LabelEncoder
from sklearn.utils.class_weight import compute_sample_weight
from xgboost import XGBClassifier

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.feature_engineering import FEATURES, MOVING_AVG_WINDOW, SAMPLE_PERIOD_S  # noqa: E402

DATA_PATH = ROOT / "processed_data" / "converted_dataset.csv"
ARTIFACTS = ROOT / "artifacts"
SAMPLES = ROOT / "samples"

MODEL_NAME = "pmsm-inverter-fdd-xgboost"
MODEL_VERSION = "1.0.0"
NOTEBOOK = "notebooks/PMSM_XGBoost_Training_Validation.ipynb"

# --- Notebook constants (cells 2, 4, 8) -------------------------------------
RANDOM_STATE = 42
TARGET = "FDD"
TEST_FRAC = 0.20
N_FOLDS = 3
PURGE_GAP = 10
BEST_PARAMS = {
    "n_estimators": 150, "max_depth": 5, "learning_rate": 0.02,
    "subsample": 0.8, "colsample_bytree": 0.7, "reg_lambda": 1,
}

# Held-out test results saved in the notebook's outputs (cell 20).
NOTEBOOK_TEST_MACRO_F1 = 0.960095
NOTEBOOK_TEST_ACCURACY = 0.9591
NOTEBOOK_TEST_BALANCED_ACCURACY = 0.9678
NOTEBOOK_TEST_ROWS = 2175
NOTEBOOK_TRAIN_ROWS = 2064

# Engineering documentation for feature_schema.json. Formulas use the
# intermediate "_a" (Arduino-calibration) currents: X_a = 0.074 * (X_adc - 512).
FEATURE_DOCS = {
    "Ia_original": dict(
        description="Phase A inline current (ACS712-20A), 'original' datasheet calibration.",
        unit="A", source="raw_sensor",
        formula="((Ia_adc / 1023) * 5 - 2.5) / 0.100", history=None),
    "Ib_original": dict(
        description="Phase B inline current (ACS712-20A), 'original' datasheet calibration.",
        unit="A", source="raw_sensor",
        formula="((Ib_adc / 1023) * 5 - 2.5) / 0.100", history=None),
    "VDC": dict(
        description="DC bus voltage (ACS712 in series with 100 ohm resistor).",
        unit="V", source="raw_sensor",
        formula="(((VDC_adc / 1023) * 5 - 2.5) / 0.100) * 100", history=None),
    "IDC_original": dict(
        description="DC bus current (ACS712-20A), 'original' datasheet calibration.",
        unit="A", source="raw_sensor",
        formula="((IDC_adc / 1023) * 5 - 2.5) / 0.100", history=None),
    "T1": dict(
        description="Half-bridge 1 temperature (10k NTC + 10k divider).",
        unit="degC", source="raw_sensor",
        formula="Steinhart-Hart: R = 10000 / (1023 / T1_adc - 1); "
                "1 / (1.2666e-3 + 2.3661e-4 ln R + 9.6094e-8 (ln R)^3) - 273.15",
        history=None),
    "T2": dict(
        description="Half-bridge 2 temperature (10k NTC + 10k divider).",
        unit="degC", source="raw_sensor", formula="Same as T1, applied to T2_adc", history=None),
    "T3": dict(
        description="Half-bridge 3 temperature (10k NTC + 10k divider).",
        unit="degC", source="raw_sensor", formula="Same as T1, applied to T3_adc", history=None),
    "VD": dict(
        description="Gate-driver supply voltage (ACS712 in series with 100 ohm resistor).",
        unit="V", source="raw_sensor",
        formula="(((VD_adc / 1023) * 5 - 2.5) / 0.100) * 100", history=None),
    "Power_DC": dict(
        description="DC-side electrical power proxy.",
        unit="W", source="engineered", formula="VDC * IDC_a", history=None),
    "Power_AC": dict(
        description="AC-side power proxy from driver voltage and two phase currents "
                    "(not a true three-phase power measurement).",
        unit="W", source="engineered", formula="VD * (Ia_a + Ib_a)", history=None),
    "Current_Imbalance": dict(
        description="Phase A/B current imbalance ratio.",
        unit="dimensionless", source="engineered",
        formula="abs(Ia_a - Ib_a) / ((Ia_a + Ib_a) / 2)", history=None),
    "Ia_Normalized": dict(
        description="Phase A current relative to DC bus current.",
        unit="dimensionless", source="engineered", formula="Ia_a / IDC_a", history=None),
    "Ib_Normalized": dict(
        description="Phase B current relative to DC bus current.",
        unit="dimensionless", source="engineered", formula="Ib_a / IDC_a", history=None),
    "VDC_RateOfChange": dict(
        description="First difference of DC bus voltage per second.",
        unit="V/s", source="engineered",
        formula="(VDC[t] - VDC[t-1]) / 0.1",
        history="Previous sample (t-1) from the same continuous 10 Hz stream"),
    "IDC_RateOfChange": dict(
        description="First difference of DC bus current (Arduino calibration) per second.",
        unit="A/s", source="engineered",
        formula="(IDC_a[t] - IDC_a[t-1]) / 0.1",
        history="Previous sample (t-1) from the same continuous 10 Hz stream"),
    "VDC_MovingAvg": dict(
        description="Trailing 1-second mean of DC bus voltage.",
        unit="V", source="engineered",
        formula="mean(VDC[t-9] .. VDC[t])",
        history="Current + 9 previous samples (10 samples, 1.0 s at 10 Hz), same stream"),
    "IDC_MovingAvg": dict(
        description="Trailing 1-second mean of DC bus current (Arduino calibration).",
        unit="A", source="engineered",
        formula="mean(IDC_a[t-9] .. IDC_a[t])",
        history="Current + 9 previous samples (10 samples, 1.0 s at 10 Hz), same stream"),
    "Temp_Diff_Max": dict(
        description="Spread between the hottest and coolest half-bridge.",
        unit="degC", source="engineered", formula="max(T1, T2, T3) - min(T1, T2, T3)",
        history=None),
}
NULLABLE_FEATURES = {
    "Current_Imbalance": "Ia_a + Ib_a == 0",
    "Ia_Normalized": "IDC_a == 0",
    "Ib_Normalized": "IDC_a == 0",
}


def rolling_window_split(frame, target, test_frac, n_folds, purge_gap):
    """Verbatim copy of the notebook's split (cell 4)."""
    n_blocks = n_folds + 1
    fold_train_idx = [[] for _ in range(n_folds)]
    fold_val_idx = [[] for _ in range(n_folds)]
    test_idx = []
    for label in sorted(frame[target].unique()):
        idx = frame.index[frame[target].eq(label)].to_numpy()
        idx = idx[np.argsort(frame.loc[idx, "Timestamp"].to_numpy())]
        n = len(idx)
        n_test = int(np.floor(test_frac * n))
        test_start = n - n_test
        cv_end = max(0, test_start - purge_gap)
        cv_pool = idx[:cv_end]
        m = len(cv_pool)
        block_size = m // n_blocks
        blocks = [cv_pool[i * block_size:(i + 1) * block_size] for i in range(n_blocks - 1)]
        blocks.append(cv_pool[(n_blocks - 1) * block_size:])
        for i in range(n_folds):
            train_block = blocks[i][:-purge_gap] if len(blocks[i]) > purge_gap else blocks[i][:0]
            val_block = blocks[i + 1][purge_gap:] if len(blocks[i + 1]) > purge_gap else blocks[i + 1][:0]
            fold_train_idx[i].extend(train_block)
            fold_val_idx[i].extend(val_block)
        test_idx.extend(idx[test_start:])
    folds = [
        (frame.loc[tr].copy(), frame.loc[va].copy())
        for tr, va in zip(fold_train_idx, fold_val_idx)
    ]
    return folds, frame.loc[test_idx].copy()


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def to_request(row):
    """Feature row -> JSON request body (non-finite ratio features -> null)."""
    body = {}
    for f in FEATURES:
        v = float(row[f])
        if not np.isfinite(v):
            if f not in NULLABLE_FEATURES:
                raise ValueError(f"Unexpected non-finite {f} in reference row")
            body[f] = None
        else:
            body[f] = v
    return body


def main():
    df = pd.read_csv(DATA_PATH)
    labels = sorted(df[TARGET].dropna().unique())

    folds, test_df = rolling_window_split(df, TARGET, TEST_FRAC, N_FOLDS, PURGE_GAP)
    train_df, val_df = folds[-1]

    # Preprocessing: +/-inf -> NaN, median imputer fitted on training rows only.
    X_train_raw = train_df[FEATURES].replace([np.inf, -np.inf], np.nan)
    imputer = SimpleImputer(strategy="median")
    X_train = pd.DataFrame(imputer.fit_transform(X_train_raw), columns=FEATURES, index=X_train_raw.index)

    label_encoder = LabelEncoder()
    label_encoder.fit(labels)
    y_train_encoded = label_encoder.transform(train_df[TARGET])
    train_weights = compute_sample_weight(class_weight="balanced", y=y_train_encoded)

    shuffle_idx = np.random.RandomState(RANDOM_STATE).permutation(len(X_train))
    model = XGBClassifier(
        objective="multi:softprob", num_class=len(labels), eval_metric="mlogloss",
        random_state=RANDOM_STATE, n_jobs=-1, tree_method="hist", **BEST_PARAMS,
    )
    model.fit(X_train.iloc[shuffle_idx], y_train_encoded[shuffle_idx],
              sample_weight=train_weights[shuffle_idx])

    # Held-out test evaluation, as in notebook cell 20.
    X_test_raw = test_df[FEATURES].replace([np.inf, -np.inf], np.nan)
    X_test = pd.DataFrame(imputer.transform(X_test_raw), columns=FEATURES, index=X_test_raw.index)
    y_test = test_df[TARGET]
    test_pred = label_encoder.inverse_transform(model.predict(X_test).astype(int))
    report = classification_report(y_test, test_pred, labels=labels, output_dict=True, zero_division=0)
    macro_f1 = report["macro avg"]["f1-score"]
    accuracy = accuracy_score(y_test, test_pred)
    bal_acc = balanced_accuracy_score(y_test, test_pred)

    print(f"train rows={len(train_df)}  test rows={len(test_df)}")
    print(f"test macro F1={macro_f1:.6f}  accuracy={accuracy:.4f}  balanced accuracy={bal_acc:.4f}")
    checks = {
        "train rows": len(train_df) == NOTEBOOK_TRAIN_ROWS,
        "test rows": len(test_df) == NOTEBOOK_TEST_ROWS,
        "macro F1": round(macro_f1, 6) == NOTEBOOK_TEST_MACRO_F1,
        "accuracy": round(accuracy, 4) == NOTEBOOK_TEST_ACCURACY,
        "balanced accuracy": round(bal_acc, 4) == NOTEBOOK_TEST_BALANCED_ACCURACY,
    }
    failed = [k for k, ok in checks.items() if not ok]
    if failed:
        raise SystemExit(f"Reproduction does not match notebook outputs: {failed}. Artifacts NOT written.")
    print("Reproduction matches the notebook's saved held-out test results.")

    # --- Write artifacts -----------------------------------------------------
    ARTIFACTS.mkdir(exist_ok=True)
    SAMPLES.mkdir(exist_ok=True)
    model_path = ARTIFACTS / "pmsm_xgboost_model.joblib"
    imputer_path = ARTIFACTS / "feature_imputer.joblib"
    encoder_path = ARTIFACTS / "label_encoder.joblib"
    joblib.dump(model, model_path)
    joblib.dump(imputer, imputer_path)
    joblib.dump(label_encoder, encoder_path)

    fault_definitions = {
        "F0": "Normal operation (no fault)",
        "F1": "Open-circuit fault, switch S3 (high side)",
        "F2": "Open-circuit fault, switch S6 (low side)",
        "F3": "Short-circuit fault, switch S2 (low side)",
        "F4": "Short-circuit fault, switch S3 (high side)",
        "F5": "Short-circuit fault, switch S5 (high side)",
        "F6": "Overheating, half-bridge 1",
        "F7": "Overheating, half-bridges 1 and 2",
        "F8": "Overheating, half-bridge 3",
    }

    full = df[FEATURES].replace([np.inf, -np.inf], np.nan)
    train = X_train_raw
    schema_features = []
    for i, f in enumerate(FEATURES):
        d = FEATURE_DOCS[f]
        schema_features.append({
            "index": i,
            "name": f,
            "description": d["description"],
            "unit": d["unit"],
            "dtype": "float64 (JSON number)",
            "source": d["source"],
            "formula": d["formula"],
            "history_required": d["history"],
            "nullable": f in NULLABLE_FEATURES,
            "null_when": NULLABLE_FEATURES.get(f),
            "missing_value_handling": (
                f"Send null when {NULLABLE_FEATURES[f]} (division by zero). The service replaces "
                f"null with the training median {imputer.statistics_[i]!r}, exactly as the "
                "notebook replaced +/-inf. Any other missing/NaN/inf value is rejected (HTTP 422)."
                if f in NULLABLE_FEATURES else
                "Required. Missing, null, NaN or infinite values are rejected (HTTP 422)."
            ),
            "imputer_median": float(imputer.statistics_[i]),
            "observed_range_training_window": [float(train[f].min()), float(train[f].max())],
            "observed_range_full_dataset": [float(full[f].min()), float(full[f].max())],
        })
    schema = {
        "schema_version": "1.0.0",
        "model_version": MODEL_VERSION,
        "feature_count": len(FEATURES),
        "feature_order": FEATURES,
        "input_contract": "pre-engineered: the API receives all 18 features already calculated",
        "sampling": {"frequency_hz": 1 / SAMPLE_PERIOD_S, "period_s": SAMPLE_PERIOD_S,
                     "moving_average_window_samples": MOVING_AVG_WINDOW},
        "intermediate_definitions": {
            "Ia_a": "0.074 * (Ia_adc - 512)  (Arduino-calibration phase A current, A)",
            "Ib_a": "0.074 * (Ib_adc - 512)  (Arduino-calibration phase B current, A)",
            "IDC_a": "0.074 * (IDC_adc - 512)  (Arduino-calibration DC current, A)",
            "X_adc": "raw 10-bit ADC count, 0-1023, 5 V reference",
        },
        "reference_implementation": "app/feature_engineering.py::compute_features",
        "features": schema_features,
    }
    (ARTIFACTS / "feature_schema.json").write_text(json.dumps(schema, indent=2) + "\n")

    cm = confusion_matrix(y_test, test_pred, labels=labels)
    metadata = {
        "model_name": MODEL_NAME,
        "model_version": MODEL_VERSION,
        "owner": "Rana Alabbasi (Data Science)",
        "training_date": dt.date.today().isoformat(),
        "training_notes": (
            f"Artifacts exported by training/export_artifacts.py, which reproduces {NOTEBOOK} "
            "(notebook evaluated 2026-09-28). Reproduction verified against the notebook's saved "
            "held-out test metrics before export."
        ),
        "framework": {
            "python": platform.python_version(),
            "xgboost": xgboost.__version__,
            "scikit_learn": sklearn.__version__,
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "joblib": joblib.__version__,
        },
        "artifacts": {
            p.name: {"sha256": sha256(p), "bytes": p.stat().st_size}
            for p in (model_path, imputer_path, encoder_path)
        },
        "algorithm": {
            "estimator": "xgboost.XGBClassifier",
            "objective": "multi:softprob",
            "tree_method": "hist",
            "random_state": RANDOM_STATE,
            "hyperparameters": BEST_PARAMS,
            "class_weighting": "sklearn compute_sample_weight('balanced') on training labels",
        },
        "dataset": {
            "name": "PMSM-inverter-fault-diagnosis-3.0",
            "file": "processed_data/converted_dataset.csv",
            "sha256": sha256(DATA_PATH),
            "rows": int(len(df)),
            "license": "CC BY 4.0",
            "provider": "Prof. Abdelkabir Bacha, ISEM / Hassan II University of Casablanca",
            "sampling_hz": 10,
        },
        "training_data": {
            "selection": ("Most recent of 3 sliding-window folds: per class, chronological, "
                          "latest 20% held out as test, purge gap of 10 samples at every boundary."),
            "rows": int(len(train_df)),
            "class_counts": {k: int(v) for k, v in train_df[TARGET].value_counts().sort_index().items()},
        },
        "feature_order": FEATURES,
        "feature_count": len(FEATURES),
        "preprocessing": [
            "Replace +inf/-inf with NaN (in the API: nullable ratio features sent as null)",
            "SimpleImputer(strategy='median') fitted on training rows only (feature_imputer.joblib)",
            "No scaling or other transformation",
        ],
        "target": {
            "column": TARGET,
            "classes": labels,
            "label_mapping": {str(i): c for i, c in enumerate(label_encoder.classes_)},
            "class_definitions": fault_definitions,
        },
        "evaluation": {
            "data_reference": ("Latest 20% (floor) of each FDD class in the dataset file above, "
                               "by Timestamp; never used for training or tuning"),
            "rows": int(len(test_df)),
            "macro_f1": round(macro_f1, 6),
            "accuracy": round(accuracy, 6),
            "balanced_accuracy": round(bal_acc, 6),
            "per_class": {
                c: {k: round(report[c][k], 6) for k in ("precision", "recall", "f1-score")}
                   | {"support": int(report[c]["support"])}
                for c in labels
            },
            "confusion_matrix": {"labels": labels, "rows_true_cols_pred": cm.tolist()},
            "rolling_validation_macro_f1": {
                "folds": [0.907125, 0.972162, 0.973185], "mean": 0.950824, "std": 0.037848,
                "source": f"{NOTEBOOK} cell 8 saved outputs",
            },
        },
        "limitations": [
            "Trained and evaluated on one laboratory test rig (converted DENSO alternator PMSM, "
            "IRF540N MOSFET inverter, Arduino acquisition at 10 Hz, ~10 rad/s constant speed). "
            "Performance on other motors, inverters, sensors, speeds or loads is unknown.",
            "Each fault class is a single continuous recording; the test set is the later part of "
            "the same recordings, so it does not measure generalization to new fault episodes, "
            "machines or sites.",
            "Trained on the most recent fold only (2,064 rows), not all available training data.",
            "Held-out test: F2 precision 0.755 (71 false F2 alarms, mostly true F0 rows); "
            "F0 recall 0.931; F1 recall 0.877.",
            "Closed-set classifier: always outputs one of F0-F8, including for fault types, "
            "sensor failures or operating states it has never seen. Probabilities are not "
            "calibrated.",
            "Rate-of-change and moving-average features require a continuous 10 Hz history "
            "from the same drive; wrong sampling rate or gaps silently change their meaning.",
            "Decision support only: not validated as a protection function and must not be the "
            "sole basis for shutdown, safety or maintenance actions.",
        ],
    }
    (ARTIFACTS / "model_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")

    # --- Reference cases: one held-out test row per class, plus edge cases ----
    test_sorted = test_df.sort_values("Timestamp")
    X_test_sorted = X_test.loc[test_sorted.index]
    proba = pd.DataFrame(model.predict_proba(X_test_sorted), index=test_sorted.index,
                         columns=label_encoder.classes_)
    pred = proba.idxmax(axis=1)
    chosen = []
    for c in labels:  # middle-of-segment, correctly-classified row per class
        rows = test_sorted.index[(test_sorted[TARGET] == c) & (pred == test_sorted[TARGET])]
        chosen.append((rows[len(rows) // 2], f"{c} held-out test row, correctly classified"))
    ci_null = test_sorted.index[~np.isfinite(test_sorted["Current_Imbalance"])]
    if len(ci_null):
        chosen.append((ci_null[0], "Current_Imbalance undefined (Ia_a + Ib_a == 0) -> null"))
    wrong_f2 = test_sorted.index[(test_sorted[TARGET] == "F0") & (pred == "F2")]
    if len(wrong_f2):
        chosen.append((wrong_f2[0], "Known error: true F0 predicted F2 (documented limitation)"))

    cases = []
    for idx, note in chosen:
        row = test_sorted.loc[idx]
        cases.append({
            "case_id": f"ref-{len(cases) + 1:02d}",
            "note": note,
            "source": {"dataset_row_index": int(idx), "timestamp_s": float(row["Timestamp"]),
                       "true_label": row[TARGET], "split": "held-out test"},
            "request": to_request(row),
            "expected_predicted_class": pred[idx],
            "expected_class_probabilities": {c: float(proba.loc[idx, c]) for c in labels},
        })
    (SAMPLES / "expected_predictions.json").write_text(json.dumps({
        "model_version": MODEL_VERSION,
        "model_sha256": metadata["artifacts"][model_path.name]["sha256"],
        "probability_tolerance": 1e-6,
        "cases": cases,
    }, indent=2) + "\n")
    (SAMPLES / "valid_request.json").write_text(json.dumps(cases[0]["request"], indent=2) + "\n")
    missing = dict(cases[0]["request"])
    missing.pop("T3")
    (SAMPLES / "invalid_request_missing_feature.json").write_text(json.dumps(missing, indent=2) + "\n")

    print(f"Wrote artifacts to {ARTIFACTS} and {len(cases)} reference cases to {SAMPLES}")


if __name__ == "__main__":
    main()
