"""Send the held-out test set to a RUNNING inference server and score it.

End-to-end check: every test row goes through HTTP -> validation -> imputer ->
model, exactly as a production client would. The server's predictions must
reproduce the notebook's held-out test results.

Usage (server already running, e.g. `docker run --rm -p 8000:8000 pmsm-inverter-fdd:local`):
    python training/evaluate_via_api.py
    python training/evaluate_via_api.py --url http://localhost:8000
"""

import argparse
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import pandas as pd
from sklearn.metrics import (
    accuracy_score, balanced_accuracy_score, classification_report, confusion_matrix,
)

sys.path.insert(0, str(Path(__file__).resolve().parent))
from export_artifacts import (  # noqa: E402
    DATA_PATH, N_FOLDS, NOTEBOOK_TEST_ACCURACY, NOTEBOOK_TEST_BALANCED_ACCURACY,
    NOTEBOOK_TEST_MACRO_F1, NOTEBOOK_TEST_ROWS, PURGE_GAP, TARGET, TEST_FRAC,
    rolling_window_split, to_request,
)


def call(url, path, body=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(url + path, data=data, headers={"content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.load(r)


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--url", default="http://localhost:8000")
    args = parser.parse_args()
    url = args.url.rstrip("/")

    try:
        health = call(url, "/health")
    except (urllib.error.URLError, ConnectionError) as e:
        raise SystemExit(f"Server not reachable at {url} ({e}). Start it first.")
    print(f"Server: {url}  status={health['status']}  model_version={health['model_version']}")

    df = pd.read_csv(DATA_PATH)
    _, test_df = rolling_window_split(df, TARGET, TEST_FRAC, N_FOLDS, PURGE_GAP)
    labels = sorted(df[TARGET].unique())
    print(f"Sending {len(test_df)} held-out test rows to POST /predict ...")

    preds, failures = [], 0
    started = time.perf_counter()
    for _, row in test_df.iterrows():
        try:
            preds.append(call(url, "/predict", to_request(row))["predicted_class"])
        except urllib.error.HTTPError as e:
            failures += 1
            preds.append(None)
            print(f"  HTTP {e.code} for dataset row {row.name}: {e.read().decode()[:200]}")
    elapsed = time.perf_counter() - started
    print(f"Done in {elapsed:.1f} s ({1000 * elapsed / len(test_df):.1f} ms/request), "
          f"{failures} failed requests\n")
    if failures:
        raise SystemExit("Some requests failed; metrics not computed.")

    y_true = test_df[TARGET].to_numpy()
    report = classification_report(y_true, preds, labels=labels, digits=4, zero_division=0)
    macro_f1 = classification_report(y_true, preds, labels=labels, output_dict=True,
                                     zero_division=0)["macro avg"]["f1-score"]
    acc = accuracy_score(y_true, preds)
    bal = balanced_accuracy_score(y_true, preds)
    print(report)
    print("Confusion matrix (rows = true, cols = predicted):")
    print(pd.DataFrame(confusion_matrix(y_true, preds, labels=labels), index=labels, columns=labels), "\n")

    checks = [
        ("test rows", len(test_df), NOTEBOOK_TEST_ROWS, len(test_df) == NOTEBOOK_TEST_ROWS),
        ("macro F1", f"{macro_f1:.6f}", NOTEBOOK_TEST_MACRO_F1, round(macro_f1, 6) == NOTEBOOK_TEST_MACRO_F1),
        ("accuracy", f"{acc:.4f}", NOTEBOOK_TEST_ACCURACY, round(acc, 4) == NOTEBOOK_TEST_ACCURACY),
        ("balanced accuracy", f"{bal:.4f}", NOTEBOOK_TEST_BALANCED_ACCURACY,
         round(bal, 4) == NOTEBOOK_TEST_BALANCED_ACCURACY),
    ]
    print(f"{'metric':<18} {'server':>10} {'notebook':>10}")
    for name, got, want, ok in checks:
        print(f"{name:<18} {got!s:>10} {want!s:>10}  {'MATCH' if ok else 'MISMATCH'}")
    if not all(ok for *_, ok in checks):
        raise SystemExit("\nServer does NOT reproduce the notebook's test results.")
    print("\nServer reproduces the notebook's held-out test results.")


if __name__ == "__main__":
    main()
